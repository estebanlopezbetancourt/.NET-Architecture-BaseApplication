﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;

namespace TCS.Simce.Monitoreo.SL.DTO.EmailService
{
    public class AttachmentDTO
    {
        public MemoryStream MemoryStream { get; set; }
        public string NombreAdjunto { get; set; }
    }
}