﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace TCS.Simce.Monitoreo.SL.DTO.EmailService
{
    public class EmailDTO
    {
        public string To { get; set; }
        public string Cc { get; set; }
        public string Bcc { get; set; }
        public string From { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        IList<AttachmentDTO> Attachments { get; set; }
    }
}