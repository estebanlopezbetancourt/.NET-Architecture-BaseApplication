﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class NotificarAlarmaDTO
    {
        public int IdEtapaMonitoreo { get; set; }

        public int rut { get; set; }
    }
}
