﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class PersonaDTO
    {
        public int Rut { get; set; }

        public DateTime FechaNacimiento { get; set; }

        public string Email { get; set; }
    }
}
