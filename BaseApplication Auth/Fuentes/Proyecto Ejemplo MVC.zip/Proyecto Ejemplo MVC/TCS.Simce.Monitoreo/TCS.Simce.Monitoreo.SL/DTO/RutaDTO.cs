﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class RutaDTO
    {
        public int NumRuta { get; set; }
        public IList<PuntoRutaDTO> puntosRutaCollection { get; set; }
        public int IdCO { get; set; }

        public int IdNivel { get; set; }

        public string NombreComuna { get; set; }
    }
    public class PuntoRutaDTO
    {
        public int OrdenRuta { get; set; }

        public int CantidadCursos { get; set; }
        public EstablecimientoDTO Establecimiento { get; set; }

        
    }
}
