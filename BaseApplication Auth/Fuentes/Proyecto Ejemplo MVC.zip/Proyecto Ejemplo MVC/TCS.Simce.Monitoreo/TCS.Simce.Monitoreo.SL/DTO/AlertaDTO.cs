﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class AlertaDTO
    {
        public string NombreCentroOp { get; set; }
        public string NombreEstablecimiento { get; set; }

        public string Curso { get; set; }
        public string EtapaMonitoreo { get; set; }

        public string Nombre { get; set; }

        public string Rol { get; set; }
        public string Telefono { get; set; }
        public string NombreSupervisor { get; set; }
        public string TelefonoSupervisor { get; set; }


        //identifiers
        public int IdSubCentro { get; set; }
        public int IdEtapaMonitoreo { get; set; }
        public int IdPersona { get; set; }

        public int IdCurso { get; set; }
    }
}
