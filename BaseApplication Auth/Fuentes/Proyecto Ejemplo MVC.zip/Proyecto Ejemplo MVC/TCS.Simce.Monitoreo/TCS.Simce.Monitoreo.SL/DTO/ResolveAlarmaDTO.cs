﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class ResolveAlarmaDTO
    {
        public int IdSubCentro { get; set; }
        public int IdEtapaMonitoreo { get; set; }

        public int IdPersona { get; set; }

        public string TextAlarma { get; set; }

    }
}
