﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class EtapaMonitoreoDTO
    {
        public int Id { get; set; }

        public string Descripcion { get; set; }

        public DateTime Alarma { get; set; }

        public int IdTipoPersona { get; set; }

        public string DescripcionTipoPersona { get; set; }

        public bool IsNotificado { get; set; }

        public int codigoOrden { get; set; }
    }
}
