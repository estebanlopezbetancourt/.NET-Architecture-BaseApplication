﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class PersonaCursoDTO
    {
        public string NombreCentro { get; set; }
        public string NombreEstablecimiento { get; set; }
        public string Nivel { get; set; }
        public string Curso { get; set; }
        public int Rut { get; set; }
        public string Dv { get; set; }
        public string Nombres { get; set; }
        public string ApPaterno { get; set; }
        public string ApMaterno { get; set; }
        public string Rol { get; set; }
        public int celular { get; set; }
        public int idSubCentro { get; set; }
        public int idCurso { get; set; }
        public int idTipoPersona { get; set; }
        public int idPersona { get; set; }
        public int idPersonasCurso { get; set; }

    }
}
