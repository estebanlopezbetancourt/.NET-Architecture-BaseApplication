﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class SubCentroDTO
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int IdComuna { get; set; }
        public decimal Lat { get; set; } //puntoX
        public decimal Long { get; set; } //puntoY

        public string NameJefeCO { get; set; }
        public int stockCajaCurso { get; set; }
        public int stockExaminadores { get; set; }


        public bool Selected { get; set; }
    }
}
