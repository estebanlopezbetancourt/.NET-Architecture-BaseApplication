﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.SL.DTO
{
    public class EstablecimientoDTO
    {
        public int Id { get; set; }

        public int RBD { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public int IdComuna { get; set; }
        public string NombreComuna { get; set; }

        public int IdCO { get; set; }
        public decimal Lat { get; set; } //puntoX
        public decimal Long { get; set; } //puntoY

        public int AlertCount { get; set; }
    }
}
