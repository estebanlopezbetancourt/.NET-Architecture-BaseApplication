﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.SL.DTO;

namespace TCS.Simce.Monitoreo.SL.Services
{
    public interface IBackOfficeManager
    {
        IList<PersonaDTO> GetSupervisores();

        string GetNewPassword(PersonaDTO persona);
    }
}
