﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.SL.DTO;

namespace TCS.Simce.Monitoreo.SL.Services
{
    public interface IMonitoreoSvc
    {
        IEnumerable<EstablecimientoDTO> GetEstablecimientos();

        IEnumerable<SubCentroDTO> GetCentrosOperacion();

        IEnumerable<ComunaDTO> GetComunas();

        IEnumerable<AlertaDTO> GetAlertasByEstablecimiento(int idEstablecimiento);

        void ResolverAlarma(SL.DTO.ResolveAlarmaDTO alarmaResuelta);

        void NotificarEtapa(SL.DTO.NotificarAlarmaDTO notificacionDto);

        IEnumerable<SL.DTO.EtapaMonitoreoDTO> GetEtapasMonitoreoByRut(int rut);

        IEnumerable<SL.DTO.PersonaCursoDTO> GetPersonasCurso();

        IEnumerable<SL.DTO.PersonaContingenteDTO> GetPersonasContingentes();

        void ReemplazarPersona(int idPersonaCurso, int idPersonaContingente);

        bool IsSimceToday();

        IEnumerable<RutaDTO> GetRutas();

        IEnumerable<NivelDTO> GetNiveles();

    }
}
