﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace TCS.Simce.Monitoreo.MvcWebHost.Helpers
{
    public class CheckIfTodayIsSimce : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            SL.Services.IMonitoreoSvc monitoreoSvc = BLL.ServiceAgent.GetMonitoreoSvc();
            
            if (!monitoreoSvc.IsSimceToday())
            {
                string controller = "ErrorHandler";
                string action = "NoSimceToday";
                string area = "Error";

                //prepare redirect
                var routeValueDict = new RouteValueDictionary(
                    new { controller = controller, action = action });
                routeValueDict.Add("area", area);

                //redirect to error handler
                filterContext.Result = new RedirectToRouteResult(routeValueDict);

                // CLear out anything already in the response
                filterContext.HttpContext.Response.Clear();
            }
        }
    }
}