﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(TCS.Simce.Monitoreo.MvcWebHost.Startup))]
namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public partial class Startup : TCS.Simce.Core.Security.Auth.Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
