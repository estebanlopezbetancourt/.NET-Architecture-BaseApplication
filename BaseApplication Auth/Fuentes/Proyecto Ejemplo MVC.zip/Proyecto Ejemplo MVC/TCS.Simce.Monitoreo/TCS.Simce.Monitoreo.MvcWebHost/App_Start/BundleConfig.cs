﻿using System;
using System.Web;
using System.Web.Optimization;

namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public class BundleConfig
    {
        // Para obtener más información sobre las uniones, consulte http://go.microsoft.com/fwlink/?LinkId=301862

        public static void AddDefaultIgnorePatterns(IgnoreList ignoreList)
        {
            if (ignoreList == null)
                throw new ArgumentNullException("ignoreList");
            ignoreList.Ignore("*.intellisense.js");
            ignoreList.Ignore("*-vsdoc.js");
            ignoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);
            ignoreList.Ignore("*.min.js", OptimizationMode.WhenDisabled);
            ignoreList.Ignore("*.min.css", OptimizationMode.WhenDisabled);
        }


        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.DirectoryFilter.Clear();
            AddDefaultIgnorePatterns(bundles.IgnoreList);

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            //bundles.Add(new ScriptBundle("~/bundles/jqueryRut").Include(
            //            "~/Scripts/plugins/jquery.js",
            //            "~/Scripts/plugins/jquery.Rut.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Utilice la versión de desarrollo de Modernizr para desarrollar y obtener información sobre los formularios. De este modo, estará
            // preparado para la producción y podrá utilizar la herramienta de compilación disponible en http://modernizr.com para seleccionar solo las pruebas que necesite.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/bootstrap-datepicker.js",    // ** NEW for Bootstrap Datepicker
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/themes/spacelab/bootstrap.css",
                      "~/Content/bootstrap-datepicker.css",  // ** NEW for Bootstrap Datepicker
                      "~/Content/site.css"));

            #region convocatoria
            bundles.Add(new ScriptBundle("~/bundles/Inicio").Include(
                        "~/Scripts/Convocatoria/Inicio.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                "~/Scripts/jquery-ui-1.11.0/jquery-ui.js",
                "~/Scripts/jquery-ui-1.11.0/jquery-ui.min.js",
                "~/Scripts/jquery-ui-1.11.0/jquery.ui.datepicker-es.js"
                ));

            bundles.Add(new StyleBundle("~/content/jqueryui/css").Include(
                    "~/Content/jquery-ui-1.11.0/jquery-ui.css",
                    "~/Content/jquery-ui-1.11.0/jquery-ui.min.css",
                    "~/Content/jquery-ui-1.11.0/jquery-ui.structure.css",
                    "~/Content/jquery-ui-1.11.0/jquery-ui.structure.min.css",
                    "~/Content/jquery-ui-1.11.0/themes/cupertino/jquery-ui.theme.css",
                    "~/Content/jquery-ui-1.11.0/themes/cupertino/jquery-ui.theme.min.css"
                ));

            #endregion  convocatoria
        }
    }
}
