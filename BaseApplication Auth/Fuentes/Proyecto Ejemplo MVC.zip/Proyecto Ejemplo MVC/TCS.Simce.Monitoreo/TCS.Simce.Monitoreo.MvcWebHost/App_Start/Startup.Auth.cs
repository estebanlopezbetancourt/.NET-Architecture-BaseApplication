﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Owin;

namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public partial class Startup : TCS.Simce.Core.Security.Auth.Startup
    {
        // For more information on configuring authentication, please visit http://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            base.ConfigureAuth(app);
        }
    }
}