﻿using System.Web;
using System.Web.Mvc;
using TCS.Simce.Monitoreo.MvcWebHost.Helpers;

namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new HandleErrorAttribute());
            filters.Add(new CustomHandleErrorAttribute());
        }
    }
}
