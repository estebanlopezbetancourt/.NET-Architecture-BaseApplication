﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                //url: "{controller}/{action}/{id}",
                //defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
                //  url: "{area}/{controller}/{action}/{id}",
                //defaults: new { area = "Monitoreo", controller = "Convocatoria", action = "Inicio", id = UrlParameter.Optional }
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Account", action = "Login", id = UrlParameter.Optional }
            //); 
            ).DataTokens = new RouteValueDictionary(new { area = "Auth" });

            routes.MapRoute("CaptchaRefresh", "DefaultCaptcha/Refresh", new { controller = "DefaultCaptcha", action = "Refresh" });
            routes.MapRoute("CaptchaImage", "DefaultCaptcha/Generate", new { controller = "DefaultCaptcha", action = "Generate" });
        }
    }
}
