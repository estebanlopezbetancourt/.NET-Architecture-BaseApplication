﻿using CaptchaMvc.Infrastructure;
using CaptchaMvc.Interface;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;

namespace TCS.Simce.Monitoreo.MvcWebHost
{
    public class MvcApplication : System.Web.HttpApplication
    {
        private static string RefreshUrlFactory(UrlHelper urlHelper, KeyValuePair<string, ICaptchaValue> keyValuePair)
        {
            return urlHelper.RouteUrl("CaptchaRefresh");
        }

        private static string ImageUrlFactory(DefaultCaptchaManager captchaManager, UrlHelper urlHelper,
                                        KeyValuePair<string, ICaptchaValue> keyValuePair)
        {
            return urlHelper.RouteUrl("CaptchaImage", new RouteValueDictionary { { captchaManager.TokenParameterName, keyValuePair.Key } });
        }

        protected void Application_Start()
        {          

            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);

            BundleTable.EnableOptimizations = true;
            BundleConfig.RegisterBundles(BundleTable.Bundles);
         

            var defaultCaptchaManager = (DefaultCaptchaManager)CaptchaMvc.Infrastructure.CaptchaUtils.CaptchaManager;
            defaultCaptchaManager.ImageUrlFactory = (helper, pair) => ImageUrlFactory(defaultCaptchaManager, helper, pair);
            defaultCaptchaManager.RefreshUrlFactory = RefreshUrlFactory;
        }
    }
}
