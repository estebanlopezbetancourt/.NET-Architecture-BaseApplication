﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Models
{
    public class FilterViewModel
    {
        public IEnumerable<SL.DTO.ComunaDTO> ComunaCollection { get; set; }
        public IEnumerable<SL.DTO.SubCentroDTO> CentroOperacionCollection { get; set; }

        public IEnumerable<SL.DTO.RutaDTO> RutaCollection { get; set; }

        public IEnumerable<SL.DTO.NivelDTO> NivelCollection { get; set; }

        public bool GreenEnabled { get; set; }
        public bool RedEnabled { get; set; }

    }
}