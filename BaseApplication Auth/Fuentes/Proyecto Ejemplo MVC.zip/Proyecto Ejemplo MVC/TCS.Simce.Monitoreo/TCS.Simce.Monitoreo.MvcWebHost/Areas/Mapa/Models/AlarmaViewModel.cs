﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Models
{
    public class AlarmaViewModel
    {
        public IEnumerable<SL.DTO.AlertaDTO> alertasCollection { get; set; }
    }
}