﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TCS.Simce.Monitoreo.SL.DTO;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Controllers
{
    [Authorize(Roles = "Monitoreo_Admin, Monitoreo_Notificador, Formacion_Postulante")]
    
    public class NotificacionController : Controller
    {
        SL.Services.IMonitoreoSvc monitoreoSvc;
        public NotificacionController()
        {
            this.monitoreoSvc = TCS.Simce.Monitoreo.BLL.ServiceAgent.GetMonitoreoSvc();
        }

        [Helpers.CheckIfTodayIsSimce]
        public ActionResult Notificaciones(OperationMessageId? message)
        {
            var rutUsername = int.Parse(User.Identity.Name);

            ViewBag.StatusMessage =
                message == OperationMessageId.Success ? "La notificación se ha registrado con éxito."
                : message == OperationMessageId.Invalid ? "No es posible notificar esta etapa. Aún no ha finalizado la etapa anterior."
                : message == OperationMessageId.StillPending ? "Ud. aun tiene etapas previas a ésta por notificar"
                : message == OperationMessageId.Error ? "No fue posible realizar la operación."
                : "";

            var etapas = this.monitoreoSvc.GetEtapasMonitoreoByRut(rutUsername);
            return View(etapas);
        }
        public ActionResult Index()
        {
            return View();
        }

        [Helpers.CheckIfTodayIsSimce]
        public ActionResult NotificarEtapa(int idEtapaMonitoreo)
        {
            var rutUsername = int.Parse(User.Identity.Name);

            //Validación
            var etapas = this.monitoreoSvc.GetEtapasMonitoreoByRut(rutUsername);

            var etapaNotificar = etapas.First(x => x.Id == idEtapaMonitoreo);
            //Vemos si tiene etapas pendientes
            var etapaPendiente = etapas.OrderBy(x => x.Alarma).First(x => !x.IsNotificado);
            if (etapaPendiente != null && etapaNotificar.codigoOrden > etapaPendiente.codigoOrden)
                return RedirectToAction("Notificaciones", new { Message = OperationMessageId.StillPending });


            //Vemos si hay una por caducar, y nos aseguramos que no es posterior a esta etapa la que se notifica
            var etapaPorCaducar = etapas.OrderBy(x => x.Alarma).FirstOrDefault(x => x.Alarma.TimeOfDay > DateTime.Now.TimeOfDay);
            if (etapaPorCaducar != null && idEtapaMonitoreo > etapaPorCaducar.Id) // si la etapa que envían es mayor que la que caducará es invalida
                return RedirectToAction("Notificaciones", new { Message = OperationMessageId.Invalid });


            NotificarAlarmaDTO notificacion = new NotificarAlarmaDTO() { rut = rutUsername, IdEtapaMonitoreo = idEtapaMonitoreo };
            this.monitoreoSvc.NotificarEtapa(notificacion);

            return RedirectToAction("Notificaciones", new { Message = OperationMessageId.Success });
        }
    }

    public enum OperationMessageId
    {
        Success,
        Invalid,
        StillPending,
        Error
    }
}