﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Models
{
    public class MockUpRepository
    {
        public static IEnumerable<AlarmaViewModel> GetAlarmas()
        {
            throw new NotImplementedException();

            //IList<AlarmaViewModel> collection = new List<AlarmaViewModel>();

            //int cont = 0;
            //while (cont < 10)
            //{
            //    collection.Add(new AlarmaViewModel{
            //         NombreCentroOp = "NombreCentro",
            //         NombreEstablecimiento = "NombreEstablecimiento",
            //         Nombre = "Juan Perez",
            //         Rol = "Examinador",
            //         TipoAlarma ="Constitución Centro Operacion",
            //         Curso = "8° basico A",
            //         Rut = 123456 + cont,
            //         Supervisor ="Carlos Cardenas",
            //         Telefono = "8-2223344",
            //         TelefonoSupervisor = "9-9998877",
            //         IdEstablecimiento = cont
            //    });
            //    cont++;
            //}

            //return collection;
        }

        public static IEnumerable<SelectListItem> GetComunasFilter()    
        {
            IList<SelectListItem> collection = new List<SelectListItem>();

            int cont = 1;
            while (cont <= 10)
            {
                collection.Add(new SelectListItem
                {   
                    Text = string.Format("Comuna {0}", cont),
                    Value = cont.ToString(),
                    Selected = true
                });
                cont++;
            }

            return collection;
        }

       
    }
}