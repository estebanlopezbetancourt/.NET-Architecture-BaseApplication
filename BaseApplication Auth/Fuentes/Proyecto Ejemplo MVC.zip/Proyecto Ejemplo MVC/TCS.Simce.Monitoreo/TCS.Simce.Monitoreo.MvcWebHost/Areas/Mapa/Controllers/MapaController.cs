﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Models;
using TCS.Simce.Monitoreo.SL.DTO;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Mapa.Controllers
{
    [Authorize(Roles = "Monitoreo_Admin, Monitoreo_Monitor, Monitoreo_Coordinador")]
    //[Helpers.CheckIfTodayIsSimce]
    public class MapaController : Controller
    {
        SL.Services.IMonitoreoSvc monitoreoSvc;
        public MapaController()
        {
            this.monitoreoSvc = BLL.ServiceAgent.GetMonitoreoSvc();
        }
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Rutas()
        {
            return View();
        }
        public JsonResult GetCentrosOperacion()
        {
            var centroOperacionCollection = this.monitoreoSvc.GetCentrosOperacion();
            return Json(centroOperacionCollection, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetEstablecimientos()
        {
            var establecimientoCollection = this.monitoreoSvc.GetEstablecimientos();
            return Json(establecimientoCollection, JsonRequestBehavior.AllowGet);
        }

        public PartialViewResult GetAlarmasByEstablecimiento(int idEstablecimiento)
        {
            AlarmaViewModel vm = new AlarmaViewModel();
            vm.alertasCollection = this.monitoreoSvc.GetAlertasByEstablecimiento(idEstablecimiento); // MockUpRepository.GetAlarmas();
            return PartialView("_AlertsPanel", vm);
        }

        [HttpPost]
        public JsonResult ResolveAlarma(int idSubCentro, int idEtapaMonitoreo, int idPersona, string textAlarma)
        {
            ResolveAlarmaDTO alarmSolved = new ResolveAlarmaDTO();
            alarmSolved.IdSubCentro = idSubCentro;
            alarmSolved.IdEtapaMonitoreo = idEtapaMonitoreo;
            alarmSolved.IdPersona = idPersona;
            alarmSolved.TextAlarma = textAlarma;

            this.monitoreoSvc.ResolverAlarma(alarmSolved);

            return Json(true);
        }

        public JsonResult GetFilterModel() 
        {
            FilterViewModel filterModel = new FilterViewModel();

            filterModel.ComunaCollection = this.monitoreoSvc.GetComunas();
            filterModel.CentroOperacionCollection = this.monitoreoSvc.GetCentrosOperacion();
            filterModel.GreenEnabled = true;
            filterModel.RedEnabled = true;
            return Json(filterModel, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetRutas()
        {
            var rutaCollection = this.monitoreoSvc.GetRutas();
            return Json(rutaCollection, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetRutasFilterModel()
        {
            FilterViewModel filterModel = new FilterViewModel();

            //filterModel.ComunaCollection = this.monitoreoSvc.GetComunas();
            filterModel.CentroOperacionCollection = this.monitoreoSvc.GetCentrosOperacion();
            filterModel.RutaCollection = this.monitoreoSvc.GetRutas();
            filterModel.NivelCollection = this.monitoreoSvc.GetNiveles();
            filterModel.GreenEnabled = true;
            filterModel.RedEnabled = true;
            return Json(filterModel, JsonRequestBehavior.AllowGet);
        }
	}
}
