﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using TCS.Simce.Monitoreo.SL.DTO;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Administracion.Models
{
    public class ConfirmarReemplazarPersonaViewModel
    {
        public PersonaCursoDTO PersonaCursoDto { get; set; }
        public PersonaContingenteDTO PersonaContingenteDto { get; set; }
    }
}