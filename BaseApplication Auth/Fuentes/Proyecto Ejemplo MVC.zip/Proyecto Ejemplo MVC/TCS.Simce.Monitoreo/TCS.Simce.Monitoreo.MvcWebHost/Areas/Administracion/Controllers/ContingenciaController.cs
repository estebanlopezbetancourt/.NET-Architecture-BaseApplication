﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcPaging;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Administracion.Models;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Administracion.Controllers
{
    [Authorize(Roles = "Monitoreo_Admin, Monitoreo_Monitor")]
    [Helpers.CheckIfTodayIsSimce]
    public class ContingenciaController : Controller
    {
        private const int defaultPageSize = 10;

        SL.Services.IMonitoreoSvc monitoreoSvc;
        public ContingenciaController()
        {
            this.monitoreoSvc = BLL.ServiceAgent.GetMonitoreoSvc();
        }

        public ActionResult Index(OperationMessageId? message, string rut, string nombres, string apPaterno, string apMaterno, int? page)
        {
            ViewBag.StatusMessage =
                message == OperationMessageId.UpdateSuccess ? "La persona ha sido reemplazada con éxito."
                : message == OperationMessageId.Error ? "No fue posible realizar la operación."
                : "";

            ViewBag.Rut = rut;
            int currentPageIndex = page.HasValue ? page.Value : 1;

            var personasCursoCollection = this.monitoreoSvc.GetPersonasCurso();
            IList<SL.DTO.PersonaCursoDTO> personasCursoList = personasCursoCollection.ToList();
            if (!string.IsNullOrWhiteSpace(rut) || !string.IsNullOrWhiteSpace(nombres) || !string.IsNullOrWhiteSpace(apPaterno) || !string.IsNullOrWhiteSpace(apMaterno))
            {
                personasCursoList = personasCursoCollection.Where(p => 
                    (!string.IsNullOrWhiteSpace(rut) && p.Rut == int.Parse(rut)) ||
                    (!string.IsNullOrWhiteSpace(nombres) && p.Nombres.ToLower().Contains(nombres.ToLower())) ||
                    (!string.IsNullOrWhiteSpace(apPaterno) && p.ApPaterno.ToLower().Contains(apPaterno.ToLower())) ||
                    (!string.IsNullOrWhiteSpace(apMaterno) && p.ApMaterno.ToLower().Contains(apMaterno.ToLower())) 
                    ).ToPagedList(currentPageIndex, defaultPageSize);
            }
            else
            {
                personasCursoList = personasCursoList.ToPagedList(currentPageIndex, defaultPageSize);
            }

            //var list = 
            if (Request.IsAjaxRequest())
                return PartialView("_AjaxPersonasCursoList", personasCursoList);
            else
                return View(personasCursoList);
        }

        [HttpGet]
        public ActionResult SeleccionarReemplazante(int idPersonaCurso, string rut, string nombres, string apPaterno, string apMaterno, int? page) 
        {
            ViewBag.idPersonaCurso = idPersonaCurso;
            var personaCursoDTO = this.monitoreoSvc.GetPersonasCurso().Where(x => x.idPersonasCurso == idPersonaCurso).First();
            ViewBag.PersonaCurso = personaCursoDTO;
            

            ViewBag.Rut = rut;
            int currentPageIndex = page.HasValue ? page.Value : 1;
            var personasContingentesCollection = this.monitoreoSvc.GetPersonasContingentes();
            IList<SL.DTO.PersonaContingenteDTO> personasContingentesList = personasContingentesCollection.ToList();
            if (!string.IsNullOrWhiteSpace(rut) || !string.IsNullOrWhiteSpace(nombres) || !string.IsNullOrWhiteSpace(apPaterno) || !string.IsNullOrWhiteSpace(apMaterno))
            {
                personasContingentesList = personasContingentesCollection.Where(p =>
                    (!string.IsNullOrWhiteSpace(rut) && p.Rut == int.Parse(rut)) ||
                    (!string.IsNullOrWhiteSpace(nombres) && p.Nombres.ToLower().Contains(nombres.ToLower())) ||
                    (!string.IsNullOrWhiteSpace(apPaterno) && p.ApPaterno.ToLower().Contains(apPaterno.ToLower())) ||
                    (!string.IsNullOrWhiteSpace(apMaterno) && p.ApMaterno.ToLower().Contains(apMaterno.ToLower()))
                    ).ToPagedList(currentPageIndex, defaultPageSize);
            }
            else
            {
                personasContingentesList = personasContingentesList.ToPagedList(currentPageIndex, defaultPageSize);
            }

            //var list = 
            if (Request.IsAjaxRequest())
                return PartialView("_AjaxPersonasContingentesList", personasContingentesList);
            else
                return View(personasContingentesList);
        }

        [HttpGet]
        public ActionResult ConfirmarReemplazo(int idPersonaCurso, int idPersonaContingente)
        {
            ViewBag.idPersonaCurso = idPersonaCurso;
            ViewBag.idPersonaContingente = idPersonaContingente;

            ConfirmarReemplazarPersonaViewModel vm = new ConfirmarReemplazarPersonaViewModel();

            var personaCursoDTO = this.monitoreoSvc.GetPersonasCurso().Where(x => x.idPersonasCurso == idPersonaCurso).First();
            vm.PersonaCursoDto = personaCursoDTO;

            var personaContingenteDTO = this.monitoreoSvc.GetPersonasContingentes().Where(x => x.idPersona == idPersonaContingente).First();
            vm.PersonaContingenteDto = personaContingenteDTO;

            return View(vm);
        }

        [HttpPost]
        public ActionResult ReemplazarPersona(int idPersonaCurso, int idPersonaContingente)
        {
            this.monitoreoSvc.ReemplazarPersona(idPersonaCurso, idPersonaContingente);
            return RedirectToAction("Index", new { Message = OperationMessageId.UpdateSuccess });
        }
	}

    public enum OperationMessageId
    {
        UpdateSuccess,
        Error
    }
}