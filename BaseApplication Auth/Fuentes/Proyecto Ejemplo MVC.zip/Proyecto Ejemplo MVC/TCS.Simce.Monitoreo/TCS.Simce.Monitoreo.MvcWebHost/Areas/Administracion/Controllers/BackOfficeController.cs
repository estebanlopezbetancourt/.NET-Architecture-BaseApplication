﻿using TCS.Simce.Core.Security.Auth;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Auth;
using TCS.Simce.Core.Security.Auth.Models;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Auth.Models;
using TCS.Simce.Monitoreo.SL.Services;
using TCS.Simce.Monitoreo.BLL;
using TCS.Simce.Monitoreo.SL.DTO.EmailService;
using TCS.Simce.Monitoreo.MvcWebHost.Helpers;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Administracion.Controllers
{
    [Authorize(Roles = "Formacion_Admin, Monitoreo_Admin")]
    public class BackOfficeController : Controller
    {
        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        IBackOfficeManager backOfficeMgr;
        //
        // GET: /Administracion/BackOffice/
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult CrearCuentaSupervisores()
        {
            //obtener listado de supervisores
            backOfficeMgr = ServiceAgent.GetBackOfficeManager();
            var supervisores = backOfficeMgr.GetSupervisores();
            string[] roles = new string[] { "Formacion_Postulante" };
            foreach (var personaOp in supervisores)
            {
                //Check if user exist, otherwise will be created
                var user = UserManager.FindByName(personaOp.Rut.ToString());
                try
                {
                    if (user == null)
                    {
                        user = new ApplicationUser { UserName = personaOp.Rut.ToString(), Email = personaOp.Email };
                        var result = UserManager.Create(user, backOfficeMgr.GetNewPassword(personaOp));
                        result = UserManager.SetLockoutEnabled(user.Id, false);
                        TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Usuario {0} creado", personaOp.Rut), Core.Logging.LogLevel.Trace);
                    }
                    else
                    {
                        TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Usuario {0} ya existe", personaOp.Rut), Core.Logging.LogLevel.Trace);
                    }

                    // Add user to Role if is not already added
                    var rolesForUser = UserManager.GetRoles(user.Id);
                    if (!rolesForUser.Contains("Formacion_Postulante"))
                    {
                        var result = UserManager.AddToRole(user.Id, "Formacion_Postulante");
                        TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Usuario {0} asociado a rol Formacion_Postulante", personaOp.Rut), Core.Logging.LogLevel.Trace);
                    }
                    else
                    {
                        TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Usuario {0} ya existe asociado a rol Formacion_Postulante", personaOp.Rut), Core.Logging.LogLevel.Trace);
                    }
                }
                catch (Exception ex)
                {
                    TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("ERROR al operar con Usuario {0}. MSG: {1}", personaOp.Rut, ex.Message), Core.Logging.LogLevel.Trace);
                    TCS.Simce.Core.Logging.Log.Instance.Exception(string.Format("ERROR al operar con Usuario {0}", personaOp.Rut), ex);
                }
            }
            ViewBag.StatusMessage = "Proceso Finalizado";
            return View("Index");
        }
    }
}