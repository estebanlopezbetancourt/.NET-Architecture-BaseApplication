﻿using TCS.Simce.Core.Security.Auth;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Auth;
using TCS.Simce.Core.Security.Auth.Models;
using TCS.Simce.Monitoreo.MvcWebHost.Areas.Auth.Models;
using MvcPaging;

namespace TCS.Simce.Monitoreo.MvcWebHost.Areas.Auth.Controllers
{
    [Authorize(Roles = "Monitoreo_Admin")]
    public class UsersAdminController : Controller
    {
        private const int defaultPageSize = 10;

        public UsersAdminController()
        {
        }

        public UsersAdminController(ApplicationUserManager userManager, ApplicationRoleManager roleManager)
        {
            UserManager = userManager;
            RoleManager = roleManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        private ApplicationRoleManager _roleManager;
        public ApplicationRoleManager RoleManager
        {
            get
            {
                return _roleManager ?? HttpContext.GetOwinContext().Get<ApplicationRoleManager>();
            }
            private set
            {
                _roleManager = value;
            }
        }

        //
        // GET: /Users/
        public async Task<ActionResult> Index(OperationMessageId? message, string rut, int? page)
        {
            ViewBag.StatusMessage =
                message == OperationMessageId.InsertSuccess ? "El usuario ha sido creado con éxito."
                : message == OperationMessageId.DeleteSuccess ? "El usuario ha sido eliminado con éxito."
                : message == OperationMessageId.UpdateSuccess ? "El usuario ha sido actualizado con éxito."
                : message == OperationMessageId.Error ? "No fue posible realizar la operación."
                : "";

            ViewBag.Rut = rut;
            int currentPageIndex = page.HasValue ? page.Value : 1;
            var users = await UserManager.Users.OrderBy(x => x.UserName).ToListAsync();
            IList<ApplicationUser> usersList = users.ToList();
            if (string.IsNullOrWhiteSpace(rut))
            {
                usersList = usersList.ToPagedList(currentPageIndex, defaultPageSize);
            }
            else
            {
                usersList = users.Where(p => p.UserName == rut).ToPagedList(currentPageIndex, defaultPageSize);
            }

            //var list = 
            if (Request.IsAjaxRequest())
                return PartialView("_AjaxUserList", usersList);
            else
                return View(usersList);
        }

        //
        // GET: /Users/Details/5
        public async Task<ActionResult> Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);

            ViewBag.RoleNames = await UserManager.GetRolesAsync(user.Id);

            return View(user);
        }

        //
        // GET: /Users/Create
        public async Task<ActionResult> Create()
        {
            //Get the list of Roles
            ViewBag.RoleId = new SelectList(await RoleManager.Roles.OrderBy(x => x.Name).ToListAsync(), "Name", "Name");
            return View();
        }

        //
        // POST: /Users/Create
        [HttpPost]
        public async Task<ActionResult> Create(RegisterViewModel userViewModel, params string[] selectedRoles)
        {
            if (ModelState.IsValid)
            {
                //begin - Model Rut validation
                string rut = string.Concat(userViewModel.UserName, userViewModel.VerificationDigit);
                if (userViewModel.UserName != System.Configuration.ConfigurationManager.AppSettings["Core.Security.Auth.Admin.UserName"]
                    &&
                    !TCS.Simce.Core.Security.RutHelper.IsRutOk(rut))
                {
                    ModelState.AddModelError("UserName", "Ingrese un rut válido");
                    ViewBag.RoleId = new SelectList(await RoleManager.Roles.OrderBy(x => x).ToListAsync(), "Name", "Name");
                    return View();
                }
                //end - Model Rut validation

                var user = new ApplicationUser { UserName = userViewModel.UserName, Email = userViewModel.Email };
                var adminresult = await UserManager.CreateAsync(user, userViewModel.Password);

                //Add User to the selected Roles 
                if (adminresult.Succeeded)
                {
                    if (selectedRoles != null)
                    {
                        var result = await UserManager.AddToRolesAsync(user.Id, selectedRoles);
                        if (!result.Succeeded)
                        {
                            ModelState.AddModelError("", result.Errors.First());
                            ViewBag.RoleId = new SelectList(await RoleManager.Roles.ToListAsync(), "Name", "Name");
                            return View();
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", adminresult.Errors.First());
                    ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name", "Name");
                    return View();

                }
                return RedirectToAction("Index", new { Message = OperationMessageId.InsertSuccess });
            }
            ViewBag.RoleId = new SelectList(RoleManager.Roles, "Name", "Name");
            return View();
        }

        //
        // GET: /Users/Edit/1
        public async Task<ActionResult> Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }

            var userRoles = await UserManager.GetRolesAsync(user.Id);

            return View(new EditUserViewModel()
            {
                Id = user.Id,
                UserName = user.UserName,
                VerificationDigit = TCS.Simce.Core.Security.RutHelper.GetDv(user.UserName),
                Email = user.Email,
                RolesList = RoleManager.Roles.OrderBy(x => x.Name).ToList().Select(x => new SelectListItem()
                {
                    Selected = userRoles.Contains(x.Name),
                    Text = x.Name,
                    Value = x.Name
                })
            });
        }

        //
        // POST: /Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        //public async Task<ActionResult> Edit([Bind(Include = "Email,Id")] EditUserViewModel editUser, params string[] selectedRole)
        public async Task<ActionResult> Edit(EditUserViewModel editUser, params string[] selectedRole)
        {
            if (ModelState.IsValid)
            {
                //begin - Model Rut validation
                string rut = string.Concat(editUser.UserName, editUser.VerificationDigit);
                if (editUser.UserName != System.Configuration.ConfigurationManager.AppSettings["Core.Security.Auth.Admin.UserName"]
                    &&
                    !TCS.Simce.Core.Security.RutHelper.IsRutOk(rut))
                {
                    ModelState.AddModelError("UserName", "Ingrese un rut válido");
                    return View();
                }
                //end - Model Rut validation

                var user = await UserManager.FindByIdAsync(editUser.Id);
                if (user == null)
                {
                    return HttpNotFound();
                }

                user.UserName = editUser.UserName;
                user.Email = editUser.Email;

                var userRoles = await UserManager.GetRolesAsync(user.Id);

                selectedRole = selectedRole ?? new string[] { };

                var result = await UserManager.AddToRolesAsync(user.Id, selectedRole.Except(userRoles).ToArray<string>());

                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                result = await UserManager.RemoveFromRolesAsync(user.Id, userRoles.Except(selectedRole).ToArray<string>());

                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                return RedirectToAction("Index", new { Message = OperationMessageId.UpdateSuccess });
            }
            ModelState.AddModelError("", "Ha ocurrido un problema.");
            return View();
        }

        //
        // GET: /Users/Delete/5
        public async Task<ActionResult> Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var user = await UserManager.FindByIdAsync(id);
            if (user == null)
            {
                return HttpNotFound();
            }
            return View(user);
        }

        //
        // POST: /Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DeleteConfirmed(string id)
        {
            if (ModelState.IsValid)
            {
                if (id == null)
                {
                    return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
                }

                var user = await UserManager.FindByIdAsync(id);
                if (user == null)
                {
                    return HttpNotFound();
                }
                var result = await UserManager.DeleteAsync(user);
                if (!result.Succeeded)
                {
                    ModelState.AddModelError("", result.Errors.First());
                    return View();
                }
                return RedirectToAction("Index", new { Message = OperationMessageId.DeleteSuccess });
            }
            return View();
        }
    }

    
}
