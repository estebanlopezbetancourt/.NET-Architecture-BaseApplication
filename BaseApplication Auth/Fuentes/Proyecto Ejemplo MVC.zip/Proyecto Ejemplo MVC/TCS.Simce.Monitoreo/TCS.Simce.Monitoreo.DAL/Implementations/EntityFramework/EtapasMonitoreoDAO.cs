﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class EtapasMonitoreoDAO : BaseDAO, IEtapasMonitoreoDAO
    {
        public EtapasMonitoreoDAO(Entities.SimceOperacionesEntities context) : base(context) { }
        public IEnumerable<Entities.EtapasMonitoreo> GetEtapasCaducadas(DateTime currentDate)
        {
            return this.Context.EtapasMonitoreo.Where(x => System.Data.Entity.DbFunctions.CreateTime(x.Alarma1.Value.Hour, x.Alarma1.Value.Minute, 0) < currentDate.TimeOfDay).AsEnumerable();
        }


        public IEnumerable<Entities.EtapasMonitoreo> GetEtapasByRut(int rut, DateTime currentDate)
        {

            //según date obtengo nivel (deberían ser fechas irrepetibles)
            Entities.Nivel nivelToday = this.Context.Nivel.FirstOrDefault(n =>
                        (n.fechaAplicacion1.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion1.Value) == currentDate.Date)
                        ||  
                        (n.fechaAplicacion2.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion2.Value) == currentDate.Date)
                        ||
                        (n.fechaAplicacion3.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion3.Value) == currentDate.Date)
                        );

            if (nivelToday == null)
                throw new ApplicationException("Hoy no es un día de examen Simce");

            int idTipoPersona = this.Context.PersonasCurso.First(x => x.Curso.Nivel_idNivel == nivelToday.idNivel && x.Persona.rut == rut).TipoPersona_idTipoPersona.Value;

            return this.Context.EtapasMonitoreo.Where(x => x.TipoPersona_idTipoPersona == idTipoPersona && x.estadoRegistro == 1).OrderBy(x => x.Alarma1);
        }
    }
}
