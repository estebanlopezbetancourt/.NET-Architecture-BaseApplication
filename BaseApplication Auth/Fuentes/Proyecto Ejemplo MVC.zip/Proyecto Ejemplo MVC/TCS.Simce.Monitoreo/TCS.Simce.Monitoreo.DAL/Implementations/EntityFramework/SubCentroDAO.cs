﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;
using System.Data.Entity;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class SubCentroDAO : BaseDAO, ISubCentroDAO
    {
        public SubCentroDAO(Entities.SimceOperacionesEntities context) : base(context) { }
        public IEnumerable<Entities.SubCentro> GetAll()
        {
            //return this.Context.SubCentro.Where(x => x.Establecimiento.Any()).OrderBy(x => x.nombreCentro).AsEnumerable();
            return this.Context.SubCentro.OrderBy(x => x.nombreCentro).AsEnumerable();
        }

        public int GetStockExaminadores(int idSubCentro, DateTime currentDate)
        {
            int stock = 0;
            
            //según date obtengo nivel (deberían ser fechas irrepetibles)
            Entities.Nivel nivelToday = this.Context.Nivel.FirstOrDefault(n =>
                        (n.fechaAplicacion1.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion1.Value) == currentDate.Date)
                        ||
                        (n.fechaAplicacion2.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion2.Value) == currentDate.Date)
                        ||
                        (n.fechaAplicacion3.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion3.Value) == currentDate.Date)
                        );

            //una vez que tengo el nivel, lo uso como criterio de query
            //obtener todas las Personas asociadas al SubCentro, que no figuran en la tabla PersonasCurso, con ese SubCentro y ese Nivel
            if (nivelToday != null)
            {
                var personasContingentes =
                    from p in this.Context.Persona
                    where
                        p.SubCentro_idSubCentro == idSubCentro && 
                        !this.Context.PersonasCurso.Any(pc => pc.Persona_idPersona == p.idPersona && pc.Curso.Nivel_idNivel == nivelToday.idNivel)
                    select p;

                stock = personasContingentes != null ? personasContingentes.Count() : 0;
            }
            
            return stock;
        }


        public int GetStockCajaCurso(int idSubCentro, DateTime today)
        {
            //según date obtengo nivel (deberían ser fechas irrepetibles)

            //el stock corresponde a los contenedores  con idTipoDist = 2 (Caja Curso Contingente), nivel y subCnetor correspondiente
            //  la cantidad de folios se obtiene con la resta entre los campos desde hasta
            //  luego al valor obtenido, se le resta lo que figura en tbl ContingenciaUsada, restándosele al Contenedor respectivo, según FK idContenedor
            int stock = 0;

            
            return stock;
        }
    }
}
