﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class ComunaDAO : BaseDAO, IComunaDAO
    {
        public ComunaDAO(Entities.SimceOperacionesEntities context) : base(context) { }
        public IEnumerable<Entities.Comuna> GetAll()
        {
            return this.Context.Comuna.AsEnumerable();
        }
    }
}
