﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class MovimientosMonitoreoDAO : BaseDAO, IMovimientosMonitoreoDAO
    {
        public MovimientosMonitoreoDAO(Entities.SimceOperacionesEntities context) : base(context) { }

        public void Save(Entities.MovimientosMonitoreo movimiento)
        {
            this.Context.MovimientosMonitoreo.Add(movimiento);
            this.Context.SaveChanges();
        }

        public IEnumerable<Entities.MovimientosMonitoreo> GetMovimientosByRut(int rut, DateTime currentDate)
        {
            return this.Context.MovimientosMonitoreo.Where(x => x.Persona.rut == rut &&
                x.estadoRegistro == 1 &&
                System.Data.Entity.DbFunctions.TruncateTime(x.fechaCreacionRegistro) == currentDate.Date);
        }
    }
}
