﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    /// <summary>
    /// Base class used to manage a same db context through different Data Access Objects
    /// </summary>
    public abstract class BaseDAO
    {
        public BaseDAO(TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities context)
        {
            this.Context = context;
        }

        protected TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities Context;
    }
}
