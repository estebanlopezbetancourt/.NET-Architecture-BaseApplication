﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class PersonaDAO : BaseDAO, IPersonaDAO
    {
        public PersonaDAO(Entities.SimceOperacionesEntities context) : base(context) { }

        public Entities.Persona GetPersonaByRut(int rut)
        {
            return this.Context.Persona.FirstOrDefault(x => x.rut == rut);
        }

        public IEnumerable<Entities.Persona> GetByTipoPersona(int idTipoPersona)
        {
            return this.Context.Persona.Where(x => x.TipoPersona_idTipoPersona == idTipoPersona);
        }
    }
}
