﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class NivelDAO : BaseDAO, INivelDAO
    {
        public NivelDAO(Entities.SimceOperacionesEntities context) : base(context) { }
        public Entities.Nivel GetCurrenNivel(DateTime currentDate)
        {
            return this.Context.Nivel.FirstOrDefault(n =>
                        (n.fechaAplicacion1.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion1.Value) == currentDate.Date)
                        ||
                        (n.fechaAplicacion2.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion2.Value) == currentDate.Date)
                        ||
                        (n.fechaAplicacion3.HasValue && System.Data.Entity.DbFunctions.TruncateTime(n.fechaAplicacion3.Value) == currentDate.Date)
                        );
        }

        public IEnumerable<Entities.Nivel> GetAll()
        {
            return this.Context.Nivel.AsEnumerable();
        }
    }
}
