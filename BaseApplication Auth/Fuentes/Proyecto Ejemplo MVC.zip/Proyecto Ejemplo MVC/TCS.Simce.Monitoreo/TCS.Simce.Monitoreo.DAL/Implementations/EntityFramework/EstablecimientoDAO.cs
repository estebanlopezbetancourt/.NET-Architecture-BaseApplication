﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;
using System.Data.Entity;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class EstablecimientoDAO : BaseDAO, IEstablecimientoDAO
    {
        public EstablecimientoDAO(Entities.SimceOperacionesEntities context) : base(context) { }
        public IEnumerable<Entities.Establecimiento> GetAll()
        {
            return this.Context.Establecimiento.AsEnumerable();
        }

        public int GetAlertCount(int idEstablecimiento, Entities.Nivel nivel, IEnumerable<Entities.EtapasMonitoreo> etapasCaducadasCollection)
        {
            int alertCount = 0;

            //para cada etapa caducada, debo buscar en la tabla personas, a las personas que no están en PersonasCurso, para el nivel y día correspondientes
            //var etapasCaducadasCollection = this.Context.EtapasMonitoreo.Where(x => System.Data.Entity.DbFunctions.CreateTime(x.Alarma1.Value.Hour, x.Alarma1.Value.Minute, 0) < currentDate.TimeOfDay).AsEnumerable();
            foreach (var etapa in etapasCaducadasCollection)
            {
                //una persona está asociada a un curso, el cual está asociado a un nivel (debo filtrar los idCurso, por aquellos cuyo Nivel corresponde a nivelToday)
                //debo obtener ese listado de idPersonas que están asociadas al nivel que se aplica hoy
                //los que no están en MovimientosMonitoreo, son contabilizados como alertas
                //idEstablecimiento = al que recibo como param en la firma del método

                alertCount += this.Context.PersonasCurso
                    //.Include(x => x.Curso)
                    .Where(pc =>
                            pc.Curso.Nivel_idNivel == nivel.idNivel &&
                            pc.Curso.Establecimiento_idEstablecimiento == idEstablecimiento &&
                            !this.Context.MovimientosMonitoreo.Any(m =>
                                    System.Data.Entity.DbFunctions.TruncateTime(m.fechaCreacionRegistro.Value) == System.Data.Entity.DbFunctions.TruncateTime(System.DateTime.Now) &&
                                    m.EtapasMonitoreo_idEtapaMonitoreo == etapa.idEtapaMonitoreo &&
                                    m.EtapasMonitoreo.TipoPersona_idTipoPersona == pc.TipoPersona_idTipoPersona &&
                                    m.Persona_idPersona == pc.Persona_idPersona)
                            )
                    .Count();
            }
                
            return alertCount;
        }
    }
}
