﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDao;

namespace TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework
{
    public class PersonaCursoDAO : BaseDAO, IPersonaCursoDAO
    {
        public PersonaCursoDAO(Entities.SimceOperacionesEntities context) : base(context) { }

        public IEnumerable<Entities.PersonasCurso> GetSameIdPersonaAndNivel(int idPersonaCurso)
        {
            var personaCursoEntity = this.Context.PersonasCurso.Include("Curso").First(x => x.idPersonasCurso == idPersonaCurso);

            return this.Context.PersonasCurso.Where( x => 
                x.Persona_idPersona == personaCursoEntity.Persona_idPersona &&
                x.Curso.Nivel_idNivel == personaCursoEntity.Curso.Nivel_idNivel
                );
        }


        public void Update(IEnumerable<Entities.PersonasCurso> entitiesToUpdate)
        {
            foreach (var entity in entitiesToUpdate)
            {
                var originalEntity = this.Context.PersonasCurso.FirstOrDefault(i => i.idPersonasCurso == entity.idPersonasCurso);
                this.Context.Entry(originalEntity).CurrentValues.SetValues(entity);
            }
            this.Context.SaveChanges();
        }
    }
}
