﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDataService;

namespace TCS.Simce.Monitoreo.DAL.Implementations.Services
{
    public class EmailDataService : IEmailDataService
    {
        public int SendEmail(EmailService.EmailDTO email, string key)
        { 
            
            int isValidKey = 0;

            try
            {
                using (EmailService.EmailServiceClient svc = new EmailService.EmailServiceClient())
                {
                    isValidKey = svc.SendEmail(email, key);
                }
            }
            catch (Exception ex)
            {
                TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Error al enviar email a: {0} \nError: {1}", email.To, ex.Message), Simce.Core.Logging.LogLevel.Error);
            }
            

            return isValidKey;
        }

        public async Task<int> SendEmailAsync(EmailService.EmailDTO email, string key)
        {

            int isValidKey = 0;

            try
            {
                using (EmailService.EmailServiceClient svc = new EmailService.EmailServiceClient())
                {
                    isValidKey = await svc.SendEmailAsync(email, key);
                }
            }
            catch (Exception ex)
            {
                TCS.Simce.Core.Logging.Log.Instance.Write(string.Format("Error al enviar email a: {0} \nError: {1}", email.To, ex.Message), Simce.Core.Logging.LogLevel.Error);
            }


            return isValidKey;
        }
    }
}
