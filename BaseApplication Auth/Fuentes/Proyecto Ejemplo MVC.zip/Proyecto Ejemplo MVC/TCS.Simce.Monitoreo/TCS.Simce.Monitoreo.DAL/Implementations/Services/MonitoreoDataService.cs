﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core.IDataService;
using TCS.Simce.Monitoreo.DAL.Implementations.EntityFramework;

namespace TCS.Simce.Monitoreo.DAL.Implementations.Services
{
    public class MonitoreoDataService : IMonitoreoDataService
    {
        private TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities Context;

        public MonitoreoDataService(TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities context)
        {
            this.Context = context;
        }


        public IEnumerable<Entities.GetAlertsCountEstablecimientoByDate_Result> GetAlertsPerEstablecimientoByDate(DateTime currentDate)
        {
            return this.Context.GetAlertsCountEstablecimientoByDate(currentDate).AsEnumerable();
        }

        public IEnumerable<Entities.GetAlertsDetailsByEstablecimientoAndDate_Result> GetAlertsDetailsByEstablecimiento(int idEstablecimiento, DateTime currentDate)
        {
            return this.Context.GetAlertsDetailsByEstablecimientoAndDate(currentDate, idEstablecimiento).AsEnumerable();
        }


        public IEnumerable<Entities.GetPersonasCursoByDate_Result> GetPersonasCursoByDate(DateTime currentDate)
        {
            return this.Context.GetPersonasCursoByDate(currentDate).AsEnumerable();
        }

        public IEnumerable<Entities.GetPersonasContingentesByDate_Result> GetPersonasContingentesByDate(DateTime currentDate)
        {
            return this.Context.GetPersonasContingentesByDate(currentDate).AsEnumerable();
        }


        public IEnumerable<Entities.GetNumCajaContingenciaBySubCentroByDate_Result> GetNumCajaContingenciaBySubCentroByDate(DateTime currenDate)
        {
            return this.Context.GetNumCajaContingenciaBySubCentroByDate(currenDate).AsEnumerable();
        }
    }
}
