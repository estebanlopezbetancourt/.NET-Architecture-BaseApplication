﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core.IDataService
{
    public interface IMonitoreoDataService
    {
        IEnumerable<Entities.GetAlertsCountEstablecimientoByDate_Result> GetAlertsPerEstablecimientoByDate(DateTime currentDate);

        IEnumerable<Entities.GetAlertsDetailsByEstablecimientoAndDate_Result> GetAlertsDetailsByEstablecimiento(int idEstablecimiento, DateTime currentDate);

        IEnumerable<Entities.GetPersonasCursoByDate_Result> GetPersonasCursoByDate(DateTime currentDate);

        IEnumerable<Entities.GetPersonasContingentesByDate_Result> GetPersonasContingentesByDate(DateTime currentDate);

        IEnumerable<Entities.GetNumCajaContingenciaBySubCentroByDate_Result> GetNumCajaContingenciaBySubCentroByDate(DateTime currenDate);
    }
}
