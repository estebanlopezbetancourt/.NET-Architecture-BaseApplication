﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core
{
    public class DataAccess : IDisposable
    {
        private TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities context;
        private IDao.IEstablecimientoDAO establecimientoDAO;
        private IDao.IComunaDAO comunaDAO;
        private IDao.ISubCentroDAO subCentroDAO;
        private IDao.INivelDAO nivelDAO;
        private IDao.IEtapasMonitoreoDAO etapasMonitoreoDAO;
        private IDao.IMovimientosMonitoreoDAO movimientosMonitoreoDAO;
        private IDao.IPersonaDAO personaDAO;
        private IDao.IPersonaCursoDAO personaCursoDAO;
        private IDao.IRutaDAO rutaDAO;
        private IDao.IParametrosDAO parametrosDAO;

        private IDataService.IMonitoreoDataService monitoreoDataService;
        private IDataService.IEmailDataService emailDataService;

        public DataAccess()
        {
            this.context = new TCS.Simce.Monitoreo.DAL.Entities.SimceOperacionesEntities();
        }

        private bool disposed = false;
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    //context.Dispose();
                }
            }
            this.disposed = true;
        }
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public IDataService.IEmailDataService EmailDataService
        {
            get
            {
                if (emailDataService == null)
                    emailDataService = new Implementations.Services.EmailDataService();
                return emailDataService;
            }
        }

        public IDao.IEstablecimientoDAO EstablecimientoDAO
        {
            get
            {
                if (establecimientoDAO == null)
                    establecimientoDAO = new Implementations.EntityFramework.EstablecimientoDAO(context);
                return establecimientoDAO;
            }
        }

        public IDao.IComunaDAO ComunaDAO
        {
            get
            {
                if (comunaDAO == null)
                    comunaDAO = new Implementations.EntityFramework.ComunaDAO(context);
                return comunaDAO;
            }
        }

        public IDao.ISubCentroDAO SubCentroDAO
        {
            get
            {
                if (subCentroDAO == null)
                    subCentroDAO = new Implementations.EntityFramework.SubCentroDAO(context);
                return subCentroDAO;
            }
        }

        public IDao.INivelDAO NivelDAO
        {
            get
            {
                if (nivelDAO == null)
                    nivelDAO = new Implementations.EntityFramework.NivelDAO(context);
                return nivelDAO;
            }
        }

        public IDao.IEtapasMonitoreoDAO EtapasMonitoreoDAO
        {
            get
            {
                if (etapasMonitoreoDAO == null)
                    etapasMonitoreoDAO = new Implementations.EntityFramework.EtapasMonitoreoDAO(context);
                return etapasMonitoreoDAO;
            }
        }

        public IDataService.IMonitoreoDataService MonitoreoDataService
        {
            get
            {
                if (monitoreoDataService == null)
                    monitoreoDataService = new Implementations.Services.MonitoreoDataService(context);
                return monitoreoDataService;
            }
        }

        public IDao.IMovimientosMonitoreoDAO MovimientosMonitoreoDAO
        {
            get
            {
                if (movimientosMonitoreoDAO == null)
                    movimientosMonitoreoDAO = new Implementations.EntityFramework.MovimientosMonitoreoDAO(context);
                return movimientosMonitoreoDAO;
            }
        }

        public IDao.IPersonaDAO PersonaDAO
        {
            get
            {
                if (personaDAO == null)
                    personaDAO = new Implementations.EntityFramework.PersonaDAO(context);
                return personaDAO;
            }
        }

        public IDao.IPersonaCursoDAO PersonaCursoDAO
        {
            get
            {
                if (personaCursoDAO == null)
                    personaCursoDAO = new Implementations.EntityFramework.PersonaCursoDAO(context);
                return personaCursoDAO;
            }
        }

        public IDao.IRutaDAO RutaDAO
        {
            get
            {
                if (rutaDAO == null)
                    rutaDAO = new Implementations.EntityFramework.RutaDAO(context);
                return rutaDAO;
            }
        }

        public IDao.IParametrosDAO ParametrosDAO
        {
            get
            {
                if (parametrosDAO == null)
                    parametrosDAO = new Implementations.EntityFramework.ParametrosDAO(context);
                return parametrosDAO;
            }
        }

        
    }
}
