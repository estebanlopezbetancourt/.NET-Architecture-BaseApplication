﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core.IDao
{
    public interface IAplicacionAulaDAO
    {
        Entities.AplicacionAula Add(Entities.AplicacionAula entity);
    }
}
