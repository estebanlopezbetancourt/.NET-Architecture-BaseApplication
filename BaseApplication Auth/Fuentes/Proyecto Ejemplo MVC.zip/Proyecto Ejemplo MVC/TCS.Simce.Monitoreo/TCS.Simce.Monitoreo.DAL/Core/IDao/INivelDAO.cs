﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core.IDao
{
    public interface INivelDAO
    {
        IEnumerable<Entities.Nivel> GetAll();

        Entities.Nivel GetCurrenNivel(DateTime currentDate);
    }
}
