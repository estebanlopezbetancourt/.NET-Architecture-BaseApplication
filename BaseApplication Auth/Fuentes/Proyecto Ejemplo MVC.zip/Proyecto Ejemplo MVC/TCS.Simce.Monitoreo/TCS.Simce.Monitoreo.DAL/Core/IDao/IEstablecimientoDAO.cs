﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core.IDao
{
    public interface IEstablecimientoDAO
    {
        IEnumerable<Entities.Establecimiento> GetAll();

        int GetAlertCount(int idEstablecimiento, Entities.Nivel nivel, IEnumerable<Entities.EtapasMonitoreo> etapasCaducadasCollection);
    }
}
