﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.DAL.Core.IDao
{
    public interface IEtapasMonitoreoDAO
    {
        IEnumerable<Entities.EtapasMonitoreo> GetEtapasCaducadas(DateTime currentDate);

        IEnumerable<Entities.EtapasMonitoreo> GetEtapasByRut(int rut, DateTime currentDate);
    }
}
