﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.BLL.ServiceImplementations;
using TCS.Simce.Monitoreo.SL.Services;

namespace TCS.Simce.Monitoreo.BLL
{
    public static class ServiceAgent
    {
        public static IMonitoreoSvc GetMonitoreoSvc()
        {
            return new MonitoreoSvc();
        }

        public static IBackOfficeManager GetBackOfficeManager()
        {
            return new BackOfficeManager();
        }

        
    }
}
