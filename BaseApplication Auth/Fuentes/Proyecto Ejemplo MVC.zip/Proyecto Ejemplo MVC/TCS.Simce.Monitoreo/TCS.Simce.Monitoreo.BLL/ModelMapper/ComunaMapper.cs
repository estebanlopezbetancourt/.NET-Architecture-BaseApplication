﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class ComunaMapper
    {
        public static SL.DTO.ComunaDTO ToDto(DAL.Entities.Comuna entity)
        {
            SL.DTO.ComunaDTO dto = new SL.DTO.ComunaDTO();

            dto.Id = entity.idComuna;
            dto.Nombre = entity.descripcion;

            return dto;
        }
    }
}
