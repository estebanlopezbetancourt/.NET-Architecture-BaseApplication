﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class EtapaMonitoreoMapper
    {
        public static SL.DTO.EtapaMonitoreoDTO ToDto(DAL.Entities.EtapasMonitoreo entity)
        {
            SL.DTO.EtapaMonitoreoDTO dto = new SL.DTO.EtapaMonitoreoDTO();

            dto.Id = entity.idEtapaMonitoreo;
            dto.Descripcion = entity.descripcion;
            dto.Alarma = entity.Alarma1.Value;

            dto.IdTipoPersona = entity.TipoPersona_idTipoPersona.Value;
            dto.DescripcionTipoPersona = entity.TipoPersona.descripcion;

            dto.codigoOrden = entity.codigo.GetValueOrDefault();

            return dto;
        }
    }
}
