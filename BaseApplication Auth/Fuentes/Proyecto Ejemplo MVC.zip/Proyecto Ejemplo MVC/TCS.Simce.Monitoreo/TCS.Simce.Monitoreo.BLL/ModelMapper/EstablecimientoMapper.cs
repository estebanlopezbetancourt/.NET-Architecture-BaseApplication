﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public class EstablecimientoMapper
    {
        public static SL.DTO.EstablecimientoDTO ToDto(DAL.Entities.Establecimiento entity)
        {
            SL.DTO.EstablecimientoDTO dto = new SL.DTO.EstablecimientoDTO();
 
            dto.Id = entity.idEstablecimiento;
            dto.RBD = entity.rbd.Value;

            dto.Name = entity.nombre;
            dto.Address = entity.direccion;
            dto.Long = entity.longitud.GetValueOrDefault();
            dto.Lat = entity.latitud.GetValueOrDefault();
            dto.IdCO = entity.idSubCentro.GetValueOrDefault();
            dto.IdComuna = entity.idComuna.Value;
            
            return dto;
        }
    }
}
