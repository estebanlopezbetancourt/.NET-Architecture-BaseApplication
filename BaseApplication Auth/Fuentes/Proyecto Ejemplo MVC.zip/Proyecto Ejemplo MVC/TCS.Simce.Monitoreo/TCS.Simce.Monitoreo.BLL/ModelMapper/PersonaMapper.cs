﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class PersonaMapper
    {
        public static SL.DTO.PersonaDTO ToDto(DAL.Entities.Persona entity)
        {
            SL.DTO.PersonaDTO dto = new SL.DTO.PersonaDTO();

            dto.Rut = entity.rut.GetValueOrDefault();
            dto.Email = entity.email;
            dto.FechaNacimiento = entity.fechaNacimiento.GetValueOrDefault();

            return dto;
        }
    }
}
