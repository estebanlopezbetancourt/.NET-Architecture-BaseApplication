﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class PersonaContingenteMapper
    {
        public static SL.DTO.PersonaContingenteDTO ToDto(DAL.Entities.GetPersonasContingentesByDate_Result entity)
        {
            SL.DTO.PersonaContingenteDTO dto = new SL.DTO.PersonaContingenteDTO();

            dto.NombreCentro = entity.nombreCentro;
            dto.Rut = entity.rut.GetValueOrDefault();
            dto.Dv = entity.dv;
            dto.Nombres = entity.nombres.ToLower();
            dto.ApPaterno = entity.apellidoPaterno.ToLower();
            dto.ApMaterno = entity.apellidoMaterno.ToLower();
            dto.celular = entity.celular.GetValueOrDefault();
            dto.Rol = entity.rol;

            dto.idSubCentro = entity.idSubCentro;
            dto.idTipoPersona = entity.idTipoPersona;
            dto.idPersona = entity.idPersona;

            return dto;
        }
    }
}
