﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class PersonaCursoMapper
    {
        public static SL.DTO.PersonaCursoDTO ToDto(DAL.Entities.GetPersonasCursoByDate_Result entity)
        {
            SL.DTO.PersonaCursoDTO dto = new SL.DTO.PersonaCursoDTO();

            dto.NombreCentro = entity.nombreCentro;
            dto.NombreEstablecimiento = entity.nombreEstablecimiento;
            dto.Nivel = entity.nivel;
            dto.Curso = entity.letraCurso;
            dto.Rut = entity.rut.GetValueOrDefault();
            dto.Dv = entity.dv;
            dto.Nombres = entity.nombres.ToLower();
            dto.ApPaterno = entity.apellidoPaterno.ToLower();
            dto.ApMaterno = entity.apellidoMaterno.ToLower();
            dto.celular = entity.celular.GetValueOrDefault();
            dto.Rol = entity.rol;

            dto.idSubCentro = entity.idSubCentro;
            dto.idTipoPersona = entity.idTipoPersona;
            dto.idCurso = entity.idCurso;
            dto.idPersona = entity.idPersona;
            dto.idPersonasCurso = entity.idPersonasCurso;

            return dto;
        }
    }
}
