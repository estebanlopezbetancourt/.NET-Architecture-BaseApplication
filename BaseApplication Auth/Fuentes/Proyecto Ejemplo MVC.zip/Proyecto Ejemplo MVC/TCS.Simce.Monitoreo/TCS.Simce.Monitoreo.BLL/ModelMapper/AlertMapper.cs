﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public class AlertMapper
    {
        public static SL.DTO.AlertaDTO ToDto(DAL.Entities.GetAlertsDetailsByEstablecimientoAndDate_Result entity)
        {
            SL.DTO.AlertaDTO dto = new SL.DTO.AlertaDTO();

            dto.NombreCentroOp = entity.NombreCentroOp;
            dto.NombreEstablecimiento = entity.NombreEstablecimiento;
            dto.Curso = entity.NivelCursoDescripcion;
            dto.EtapaMonitoreo = entity.EtapaMonitoreoDescripcion;
            dto.Nombre = entity.NombrePersona;
            dto.Rol = entity.TipoPersonaDescripcion;
            dto.Telefono = entity.CelularPersona.HasValue? entity.CelularPersona.Value.ToString() : string.Empty;
            dto.NombreSupervisor = entity.NombresSupervisor;
            dto.TelefonoSupervisor = entity.TelefonoSupervisor.HasValue ? entity.TelefonoSupervisor.Value.ToString() : string.Empty;

            dto.IdEtapaMonitoreo = entity.idEtapaMonitoreo;
            dto.IdPersona = entity.idPersona;
            dto.IdSubCentro = entity.idSubCentro;
            dto.IdCurso = entity.idCurso;

            return dto;
        }
    }
}
