﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public static class SubCentroMapper
    {
        public static SL.DTO.SubCentroDTO ToDto(DAL.Entities.SubCentro entity)
        {
            SL.DTO.SubCentroDTO dto = new SL.DTO.SubCentroDTO();

            dto.Id = entity.idSubCentro;
            dto.Name = entity.nombreCentro;
            dto.Address = entity.direccion;
            dto.Lat = entity.latitud.Value;
            dto.Long = entity.longitud.Value;
            dto.IdComuna = entity.idComuna.Value;

            dto.stockCajaCurso = 0; // to Calculate 
            dto.stockExaminadores = 0; // to Calculate 

            return dto;
        }
    }
}
