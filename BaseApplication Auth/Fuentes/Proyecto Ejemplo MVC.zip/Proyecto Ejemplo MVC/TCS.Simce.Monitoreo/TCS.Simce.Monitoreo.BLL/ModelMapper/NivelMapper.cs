﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Monitoreo.BLL.ModelMapper
{
    public class NivelMapper
    {
        public static SL.DTO.NivelDTO ToDto(DAL.Entities.Nivel entity)
        {
            SL.DTO.NivelDTO dto = new SL.DTO.NivelDTO();

            dto.Id = entity.idNivel;
            dto.Descripcion = entity.descripcion;

            return dto;
        }
    }
}
