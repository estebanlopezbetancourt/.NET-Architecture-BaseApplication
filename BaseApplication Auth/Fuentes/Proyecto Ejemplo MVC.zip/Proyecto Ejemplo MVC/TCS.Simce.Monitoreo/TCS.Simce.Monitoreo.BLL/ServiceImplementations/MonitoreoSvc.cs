﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.DAL.Core;
using TCS.Simce.Monitoreo.SL.Services;

namespace TCS.Simce.Monitoreo.BLL.ServiceImplementations
{
    public class MonitoreoSvc : IMonitoreoSvc
    {
        private DateTime today;
        private DataAccess dataAccess;
        public MonitoreoSvc()
        {
            this.today = DateTime.Now;
            this.dataAccess = new DataAccess();
        }
        public IEnumerable<SL.DTO.EstablecimientoDTO> GetEstablecimientos()
        {
            IList<SL.DTO.EstablecimientoDTO> establecimientoCollection = new List<SL.DTO.EstablecimientoDTO>();

            var establecimientos = this.dataAccess.EstablecimientoDAO.GetAll().ToList();
            var alertCountResult = this.dataAccess.MonitoreoDataService.GetAlertsPerEstablecimientoByDate(this.today).ToList();

            foreach (var item in establecimientos)
            {
                var establecimiento = ModelMapper.EstablecimientoMapper.ToDto(item);

                var countResult = alertCountResult.FirstOrDefault(x => x.IdEstablecimiento.Value == establecimiento.Id);
                establecimiento.AlertCount = countResult != null ? countResult.AlertCount.Value : 0; 

                establecimientoCollection.Add(establecimiento);
            }

            return establecimientoCollection;
        }

        public IEnumerable<TCS.Simce.Monitoreo.SL.DTO.SubCentroDTO> GetCentrosOperacion()
        {
            IList<SL.DTO.SubCentroDTO> subCentroCollection = new List<SL.DTO.SubCentroDTO>();

            var subCentros = this.dataAccess.SubCentroDAO.GetAll().ToList();
            var numCajasBySubCentros = this.dataAccess.MonitoreoDataService.GetNumCajaContingenciaBySubCentroByDate(this.today).ToList();
            var jefesCOCollection = this.dataAccess.PersonaDAO.GetByTipoPersona((int)BusinessHelpers.AppEnums.TipoPersona.JefeCO);

            foreach (var item in subCentros)
            {
                var subCentro = ModelMapper.SubCentroMapper.ToDto(item);

                if (numCajasBySubCentros != null && numCajasBySubCentros.Any())
                {
                    var countResult = numCajasBySubCentros.Where(x => x.idSubCentro == item.idSubCentro &&
                        (x.CantidadDocumentosPorCaja.GetValueOrDefault() - x.cantidadDocumentosUtilizados.GetValueOrDefault()) > 0).Count();
                    subCentro.stockCajaCurso = countResult;
                }

                subCentro.stockExaminadores = this.dataAccess.SubCentroDAO.GetStockExaminadores(subCentro.Id, this.today);

                var supervisor = jefesCOCollection.FirstOrDefault( x => x.SubCentro_idSubCentro == subCentro.Id);
                if (supervisor != null)
                    subCentro.NameJefeCO = supervisor.nombres + " " + supervisor.apellidoPaterno + " " + supervisor.apellidoMaterno;
                else
                    subCentro.NameJefeCO = "No Asignado";

                subCentroCollection.Add(subCentro);
            }

            return subCentroCollection;
        }

        public IEnumerable<SL.DTO.ComunaDTO> GetComunas()
        {
            IList<SL.DTO.ComunaDTO> comunasCollection = new List<SL.DTO.ComunaDTO>();

            var comunas = this.dataAccess.ComunaDAO.GetAll().OrderBy(x => x.descripcion);
            foreach (var item in comunas)
            {
                comunasCollection.Add(ModelMapper.ComunaMapper.ToDto(item));
            }

            return comunasCollection;
        }


        public IEnumerable<SL.DTO.AlertaDTO> GetAlertasByEstablecimiento(int idEstablecimiento)
        {
            IList<SL.DTO.AlertaDTO> alertasCollection = new List<SL.DTO.AlertaDTO>();

            var alertsDetailsCollection = this.dataAccess.MonitoreoDataService.GetAlertsDetailsByEstablecimiento(idEstablecimiento, this.today);
            foreach (var alert in alertsDetailsCollection)
            {
                alertasCollection.Add(ModelMapper.AlertMapper.ToDto(alert));
            }

            return alertasCollection;
        }


        public void ResolverAlarma(SL.DTO.ResolveAlarmaDTO alarmaResuelta)
        {
            DAL.Entities.MovimientosMonitoreo movimiento = new DAL.Entities.MovimientosMonitoreo();

            movimiento.Persona_idPersona = alarmaResuelta.IdPersona;
            movimiento.TipoMovimientoMonitoreo_idTipoMovimientoMonitoreo = 3; //Resolución Alerta
            movimiento.SubCentro_idSubCentro = alarmaResuelta.IdSubCentro;
            movimiento.EtapasMonitoreo_idEtapaMonitoreo = alarmaResuelta.IdEtapaMonitoreo;
            movimiento.idUsuarioCreacionRegistro = "Sistema Monitoreo";
            movimiento.fechaCreacionRegistro = DateTime.Now;
            movimiento.estadoRegistro = 1;
            //movimiento.mensajeResolucion = alarmaResuelta.TextAlarma;

            this.dataAccess.MovimientosMonitoreoDAO.Save(movimiento);

        }

        public void NotificarEtapa(SL.DTO.NotificarAlarmaDTO notificacionDto)
        {
            DAL.Entities.MovimientosMonitoreo movimiento = new DAL.Entities.MovimientosMonitoreo();

            int idPersona = this.dataAccess.PersonaDAO.GetPersonaByRut(notificacionDto.rut).idPersona;

            movimiento.Persona_idPersona = idPersona;
            movimiento.TipoMovimientoMonitoreo_idTipoMovimientoMonitoreo = 1; //Mensaje Web
            movimiento.EtapasMonitoreo_idEtapaMonitoreo = notificacionDto.IdEtapaMonitoreo;
            movimiento.idUsuarioCreacionRegistro = notificacionDto.rut.ToString();
            movimiento.fechaCreacionRegistro = DateTime.Now;
            movimiento.estadoRegistro = 1;

            this.dataAccess.MovimientosMonitoreoDAO.Save(movimiento);

        }

        public IEnumerable<SL.DTO.EtapaMonitoreoDTO> GetEtapasMonitoreoByRut(int rut)
        {
            IList<SL.DTO.EtapaMonitoreoDTO> etapasCollection = new List<SL.DTO.EtapaMonitoreoDTO>();

            var etapas = this.dataAccess.EtapasMonitoreoDAO.GetEtapasByRut(rut, this.today);
            var movimientos = this.dataAccess.MovimientosMonitoreoDAO.GetMovimientosByRut(rut, this.today);

            foreach (var etapa in etapas)
            {
                var etapaDto = ModelMapper.EtapaMonitoreoMapper.ToDto(etapa);
                etapaDto.IsNotificado = movimientos != null && movimientos.Count() > 0 && movimientos.Any(x => x.EtapasMonitoreo_idEtapaMonitoreo == etapa.idEtapaMonitoreo);

                etapasCollection.Add(etapaDto);
            }
            return etapasCollection;
        }


        public IEnumerable<SL.DTO.PersonaCursoDTO> GetPersonasCurso()
        {
            IList<SL.DTO.PersonaCursoDTO> personasCursoCollection = new List<SL.DTO.PersonaCursoDTO>();

            var result = this.dataAccess.MonitoreoDataService.GetPersonasCursoByDate(this.today);

            foreach (var item in result)
            {
                var personaCursoDto = ModelMapper.PersonaCursoMapper.ToDto(item);
                personasCursoCollection.Add(personaCursoDto);
            }

            return personasCursoCollection;
        }

        public IEnumerable<SL.DTO.PersonaContingenteDTO> GetPersonasContingentes()
        {
            IList<SL.DTO.PersonaContingenteDTO> personasContingentesCollection = new List<SL.DTO.PersonaContingenteDTO>();

            var result = this.dataAccess.MonitoreoDataService.GetPersonasContingentesByDate(this.today);

            foreach (var item in result)
            {
                var personaContingenteDto = ModelMapper.PersonaContingenteMapper.ToDto(item);
                personasContingentesCollection.Add(personaContingenteDto);
            }

            return personasContingentesCollection;
        }


        public void ReemplazarPersona(int idPersonaCurso, int idPersonaContingente)
        {
            var cursosToUpdateCollection = this.dataAccess.PersonaCursoDAO.GetSameIdPersonaAndNivel(idPersonaCurso);

            foreach (var personaCurso in cursosToUpdateCollection)
                personaCurso.Persona_idPersona = idPersonaContingente;

            this.dataAccess.PersonaCursoDAO.Update(cursosToUpdateCollection);
        }


        public bool IsSimceToday()
        {
            bool isSimceToday = false;

            var nivel = this.dataAccess.NivelDAO.GetCurrenNivel(this.today);
            if (nivel != null)
                isSimceToday = true;

            return isSimceToday;
        }


        public IEnumerable<SL.DTO.RutaDTO> GetRutas()
        {
            IList<SL.DTO.RutaDTO> rutaCollection = new List<SL.DTO.RutaDTO>();

            int codigoParametro = int.Parse(System.Configuration.ConfigurationManager.AppSettings["TCS.Simce.Monitoreo.ModuloRuta.FiltroNivel.CodigoParametro"]);
            int isForced = int.Parse(this.dataAccess.ParametrosDAO.GetAll().First(x => x.codigo == codigoParametro).valor);

            IEnumerable<DAL.Entities.Ruta> rutas = new List<DAL.Entities.Ruta>();
            if (isForced == 1) 
            {
                var currentNivel = this.dataAccess.NivelDAO.GetCurrenNivel(this.today);
                rutas = this.dataAccess.RutaDAO.GetAll().Where(x => x.idNivel == currentNivel.idNivel).OrderBy(x => x.idSubCentro).ToList();
            }
            else
            {
                rutas = this.dataAccess.RutaDAO.GetAll().OrderBy(x => x.idSubCentro).ToList();
            }
            
            
            var comunas = this.dataAccess.ComunaDAO.GetAll().ToList();
            var establecimientos = this.dataAccess.EstablecimientoDAO.GetAll().ToList();

            var keyRutas = rutas.Select(x => x.numeroRuta.GetValueOrDefault()).Distinct();
            foreach (var keyRuta in keyRutas)
            {
                SL.DTO.RutaDTO rutaDTO = new SL.DTO.RutaDTO();
                rutaDTO.NumRuta = keyRuta;
                
                rutaDTO.puntosRutaCollection = new List<SL.DTO.PuntoRutaDTO>();
                
                var groupRutaOrdered = rutas.Where(x => x.numeroRuta == keyRuta).OrderBy(x => x.ordenRuta.GetValueOrDefault());
                foreach (var ruta in groupRutaOrdered)
                {
                    SL.DTO.PuntoRutaDTO puntoRutaDTO = new SL.DTO.PuntoRutaDTO();

                    var establecimiento = establecimientos.First(x => x.rbd == ruta.rbd.GetValueOrDefault());

                    puntoRutaDTO.CantidadCursos = ruta.cantidadCursos.GetValueOrDefault();
                    puntoRutaDTO.OrdenRuta = ruta.ordenRuta.GetValueOrDefault();
                    puntoRutaDTO.Establecimiento = ModelMapper.EstablecimientoMapper.ToDto(establecimiento);
                    puntoRutaDTO.Establecimiento.NombreComuna = comunas.First(x => x.idComuna == puntoRutaDTO.Establecimiento.IdComuna).descripcion;

                    rutaDTO.puntosRutaCollection.Add(puntoRutaDTO);
                }
                rutaDTO.IdCO = groupRutaOrdered.First().idSubCentro.GetValueOrDefault();
                rutaDTO.IdNivel = groupRutaOrdered.First().idNivel.GetValueOrDefault();
                rutaDTO.NombreComuna = comunas.Find(x => x.idComuna == rutaDTO.puntosRutaCollection.First().Establecimiento.IdComuna).descripcion;
                rutaCollection.Add(rutaDTO);
            }

            return rutaCollection;
        }


        public IEnumerable<SL.DTO.NivelDTO> GetNiveles()
        {
            int codigoParametro = int.Parse(System.Configuration.ConfigurationManager.AppSettings["TCS.Simce.Monitoreo.ModuloRuta.FiltroNivel.CodigoParametro"]);
            int isForced = int.Parse(this.dataAccess.ParametrosDAO.GetAll().First(x => x.codigo == codigoParametro).valor);

            var result = this.dataAccess.NivelDAO.GetAll();

            if (isForced == 1)
            {
                var currentNivel = this.dataAccess.NivelDAO.GetCurrenNivel(this.today);
                result = result.Where(x => x.idNivel == currentNivel.idNivel);
            }

            IList<SL.DTO.NivelDTO> personasCursoCollection = new List<SL.DTO.NivelDTO>();
            foreach (var item in result)
            {
                var personaCursoDto = ModelMapper.NivelMapper.ToDto(item);
                personasCursoCollection.Add(personaCursoDto);
            }

            return personasCursoCollection;
        }
    }
}
