﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Monitoreo.SL.Services;

namespace TCS.Simce.Monitoreo.BLL.ServiceImplementations
{
    public class BackOfficeManager : IBackOfficeManager
    {
        private DAL.Core.DataAccess dataAccess;

        public BackOfficeManager()
        {
            this.dataAccess = new DAL.Core.DataAccess();
        }
        public IList<SL.DTO.PersonaDTO> GetSupervisores()
        {
            IList<SL.DTO.PersonaDTO> personasOp = new List<SL.DTO.PersonaDTO>();

            var supervisoresCollection = this.dataAccess.PersonaDAO.GetByTipoPersona((int)BusinessHelpers.AppEnums.TipoPersona.Supervisor);
            foreach (var item in supervisoresCollection)
                personasOp.Add(ModelMapper.PersonaMapper.ToDto(item));

            return personasOp;
        }

        public string GetNewPassword(SL.DTO.PersonaDTO persona)
        {
            string passwordCreated = string.Format("{0}.{1}", persona.Rut.ToString().Substring(0, 4), persona.FechaNacimiento.ToString("dd"));
            return passwordCreated;
        }
    }
}
