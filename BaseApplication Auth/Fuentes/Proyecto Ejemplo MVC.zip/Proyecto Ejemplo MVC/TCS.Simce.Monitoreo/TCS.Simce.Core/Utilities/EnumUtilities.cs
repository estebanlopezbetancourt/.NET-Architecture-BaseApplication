﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;

namespace TCS.Simce.Core.Utilities
{
    public static class EnumUtilities
    {
        public static SelectList ToSelectList<TEnum>(this TEnum enumObj)
            where TEnum : struct, IComparable, IFormattable, IConvertible
        {
            var values = from TEnum e in Enum.GetValues(typeof(TEnum))
                         select new { Value = e.GetHashCode(), Name = e.ToString() };
            return new SelectList(values, "Value", "Name", (int)enumObj.GetHashCode());
        }

        public static SelectList GetSelectListOf<T>()
            {
                Type t = typeof(T);
                if (t.IsEnum)
                {
                    var values = from Enum e in Enum.GetValues(t)
                                 select new { Value = e.GetHashCode(), Name = EnumUtilities.AddSpaceBeforeCapitalLetters(e.ToString()) };

                    return new SelectList(values, "Value", "Name");
                }
                return null;
            }

        private static string AddSpaceBeforeCapitalLetters(string value)
        {
            //value = value.Concat(value.Select(x => Char.IsUpper(x) ? " " + x : x.ToString())).TrimStart(' ');
            value = System.Text.RegularExpressions.Regex.Replace(value, "[A-Z]", " $0");
            return value;
        }
    }
}
