﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MyMVC.Startup))]
namespace MyMVC
{
    public partial class Startup : BaseApplication.Crosscutting.Security.Auth.Startup
    {
        public void Configuration(IAppBuilder app)
        {
            base.ConfigureAuth(app);
        }
    }
}
