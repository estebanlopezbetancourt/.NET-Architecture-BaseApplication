﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MyMVC.Areas.Auth.Models
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "El {0} es un campo requerido")]
        //[StringLength(8, ErrorMessage = "El {0} debe tener al menos {2} dígitos.", MinimumLength = 6)]
        //[RegularExpression("^[0-9]+$")]
        [Display(Name = "Rut")]
        public string UserName { get; set; }

        [Required(ErrorMessage="La {0} es un campo requerido")]
        [DataType(DataType.Password)]
        [Display(Name = "Contraseña")]
        public string Password { get; set; }

        [Display(Name = "Recordarme?")]
        public bool RememberMe { get; set; }
    }

    
}