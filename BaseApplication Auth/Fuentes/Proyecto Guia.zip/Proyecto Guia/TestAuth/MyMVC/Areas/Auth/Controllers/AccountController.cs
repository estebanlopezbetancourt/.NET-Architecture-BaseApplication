﻿
using MyMVC.Areas.Auth.Models;
using BaseApplication.Crosscutting.Security.Auth;
using BaseApplication.Crosscutting.Security.Auth.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using BaseApplication.Crosscutting.Security;



namespace MyMVC.Areas.Auth.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        public AccountController()
        {
        }

        public AccountController(ApplicationUserManager userManager, ApplicationSignInManager signInManager )
        {
            UserManager = userManager;
            SignInManager = signInManager;
        }

        private ApplicationUserManager _userManager;
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            if (User.Identity.IsAuthenticated)
                return RedirectToLocal(this.GetHomeRedirect(User.Identity.Name));

            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        private ApplicationSignInManager _signInManager;

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> Login(LoginViewModel model, string returnUrl = "/")
        {
            //si no es nulo, y el rut es incorrecto, gatillar error (de ser nulo, enviará error required)
            if (!string.IsNullOrEmpty(model.UserName) && !RutHelper.IsRutOk(model.UserName))
                ModelState.AddModelError("UserName", "Ingrese un rut válido"); //agregamos error al ModelState

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            /*pasada la validación de modelo, rescatamos lo que para nosotros es el username en nuestra aplicación 
            /(el cuerpo del rut (int) ) */
            var username = model.UserName.Split('-')[0].Replace(".", string.Empty);

            // This doen't count login failures towards lockout only two factor authentication
            // To enable password failures to trigger lockout, change to shouldLockout: true

            var result = await SignInManager.PasswordSignInAsync(username, model.Password, model.RememberMe, shouldLockout: false);
            switch (result)
            {
                case Microsoft.AspNet.Identity.Owin.SignInStatus.Success:
                    if (returnUrl == null || returnUrl == "/")
                        returnUrl = this.GetHomeRedirect(username);
                    return RedirectToLocal(returnUrl);

                default:
                    ModelState.AddModelError("", "Intento de acceso inválido.");
                    return View(model);
            }
        }

        private string GetHomeRedirect(string username = null)
        {
            string url = "/"; 

            if (username != null)
            {
                //Ejemplo de seteo de url para redireccionar según rol
                
                //url = "/Folder"; //si el sitio es un subfolder (como un sitio dentro de Default Website) agregamos el subfolder en el path root
                //redirection by rol definition
                //var user = UserManager.FindByName(username);
                
                //if (UserManager.IsInRole(user.Id, "Monitoreo_Notificador") || UserManager.IsInRole(user.Id, "Formacion_Postulante"))
                //    url = this.Url.Action("Index", "Notificacion", new { area = "Mapa" });
                //else if (UserManager.IsInRole(user.Id, "Monitoreo_Monitor") || UserManager.IsInRole(user.Id, "Monitoreo_Admin") || UserManager.IsInRole(user.Id, "Monitoreo_Coordinador"))
                //    url = this.Url.Action("Index", "Mapa", new { area = "Mapa" });
            }

            return url;
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            AuthenticationManager.SignOut();
            return Redirect(this.GetHomeRedirect());
            //return RedirectToAction("Index", "Home" , new { area = string.Empty });
        }



        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }


        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home", new { area = string.Empty });
        }

        #endregion
    }
}