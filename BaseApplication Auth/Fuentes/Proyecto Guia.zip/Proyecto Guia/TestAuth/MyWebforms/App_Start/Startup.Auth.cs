﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MyWebForms.Startup))]
namespace MyWebForms
{
    public partial class Startup : BaseApplication.Crosscutting.Security.Auth.Startup
    {
        public void Configuration(IAppBuilder app)
        {
            base.ConfigureAuth(app);
        }
    }
}
