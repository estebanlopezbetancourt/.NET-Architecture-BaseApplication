﻿using System;
using System.Web;
using System.Web.UI;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin.Security;
using Owin;
using BaseApplication.Crosscutting.Security.Auth;
//using Microsoft.Owin.Host.SystemWeb;
using BaseApplication.Crosscutting.Security.Auth.Models;

namespace MyWebforms.Account
{
    public partial class Login : Page
    {
        private ApplicationSignInManager _signInManager;

        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? this.Context.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set { _signInManager = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string ErrorMessage = string.Empty;


            if (Session["ErrorLogin"] != null)
            {
                ErrorMessage = Session["ErrorLogin"].ToString();

                if (!string.IsNullOrEmpty(ErrorMessage))
                {
                    Session["ErrorLogin"] = string.Empty;
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Usuario no configurado en sistema');", true);
                }
            }

            if (!Page.IsPostBack)
            {
                if (Request.IsAuthenticated && !string.IsNullOrEmpty(Request.QueryString["ReturnUrl"]))
                    // This is an unauthorized, authenticated request...
                    Response.Redirect("AccessDenied.aspx");
            }

            this.Title = "Ingreso";
            //var returnUrl = HttpUtility.UrlEncode(Request.QueryString["ReturnUrl"]);
            //if (!String.IsNullOrEmpty(returnUrl))
            //{
            //    RegisterHyperLink.NavigateUrl += "?ReturnUrl=" + returnUrl;
            //}
        }

        protected void LogIn(object sender, EventArgs e)
        {
            if (IsValid)
            {
                try
                {
                    var username = this.UserName.Text.Split('-')[0].Replace(".", string.Empty);
                    if (username != System.Configuration.ConfigurationManager.AppSettings["Core.Security.Auth.Admin.UserName"]
                        &&
                        !BaseApplication.Crosscutting.Security.RutHelper.IsRutOk(this.UserName.Text))
                    {
                        FailureText.Text = "Intento de acceso inválido";
                        ErrorMessage.Visible = true;
                        return;
                    }

                    var manager = Context.GetOwinContext().GetUserManager<ApplicationUserManager>();

                    var signinHelper = new SignInHelper(manager, Context.GetOwinContext().Authentication);
                    var result = signinHelper.PasswordSignIn(username, Password.Text, RememberMe.Checked, shouldLockout: false);
                    switch (result)
                    {
                        case BaseApplication.Crosscutting.Security.Auth.Models.SignInStatus.Success:
                            IdentityHelper.RedirectToReturnUrl(Request.QueryString["ReturnUrl"], Response);
                            break;
                        case BaseApplication.Crosscutting.Security.Auth.Models.SignInStatus.Failure:
                        default:
                            FailureText.Text = "Intento de acceso inválido";
                            ErrorMessage.Visible = true;
                            break;
                    }
                }
                catch (Exception ex)
                {
                    BaseApplication.Crosscutting.Logging.Log.Instance.Exception("ERROR AL INTENTAR LOGIN", ex);
                }
            }
        }
    }
}