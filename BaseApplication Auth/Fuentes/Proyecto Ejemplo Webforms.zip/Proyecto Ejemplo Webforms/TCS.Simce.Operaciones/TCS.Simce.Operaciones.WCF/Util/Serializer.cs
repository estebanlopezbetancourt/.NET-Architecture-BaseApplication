﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Serialization;

namespace TCS.Simce.Operaciones.WCF.Util
{
    public static class Serializer
    {
        public static string Serialize<T>(T objeto)
        {
            string dtoSerialzado = string.Empty;
            System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(T));
            System.IO.StringWriter sw = new System.IO.StringWriter();
            serializer.Serialize(sw, objeto);
            dtoSerialzado = sw.ToString();
            sw.Close();
            return dtoSerialzado;
        }


        public static T DesSerialize<T>(string xmlObject)
        {
            T dtoSerialzado;
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            StringReader sr = new StringReader(xmlObject);
            XmlTextReader xmlReader = new XmlTextReader(sr);
            dtoSerialzado = (T)serializer.Deserialize(xmlReader);
            xmlReader.Close();
            sr.Close();
            return dtoSerialzado;
        }
    }
}
