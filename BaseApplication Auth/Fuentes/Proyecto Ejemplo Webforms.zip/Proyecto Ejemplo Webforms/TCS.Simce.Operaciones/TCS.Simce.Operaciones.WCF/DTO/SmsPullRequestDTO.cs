﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace TCS.Simce.Operaciones.WCF.Model
{
    [DataContract]
    public class SmsPullRequestDTO
    {
        [DataMember]
        [Required(ErrorMessage = "El IdMobID es requerido.")]
        [StringLength(1, MinimumLength = 11, ErrorMessage = "El largo del IdMobID debe ser entre 1 y 11.")]
        public string IdMobID { get; set; }

        [DataMember]
        [Required(ErrorMessage = "El NumeroOrigen es requerido.")]
        [StringLength(8, MinimumLength = 8, ErrorMessage = "El largo del NumeroOrigen debe ser de 8.")]
        public string NumeroOrigen { get; set; }

        [DataMember]
        [Required(ErrorMessage = "El Texto es requerido.")]
        [StringLength(200, MinimumLength = 1, ErrorMessage = "El largo del Texto debe ser entre 1 y 200 caracteres.")]
        public string Texto { get; set; }

        [DataMember]
        [Required( ErrorMessage = "La FechaIngreso es requerida.")]
        public DateTime FechaIngreso { get; set; }
    }

}