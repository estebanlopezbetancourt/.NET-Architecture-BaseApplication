﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace TCS.Simce.Operaciones.WCF.Model
{
    [DataContract]
    public class SmsPullResponseDTO
    {
        [DataMember]
        [Required(ErrorMessage = "El IdMobID es requerido.")]
        [StringLength(1, MinimumLength = 11, ErrorMessage = "El largo del IdMobID debe ser entre 1 y 11.")]
        public string IdMobID { get; set; }

        [DataMember]
        [Required(ErrorMessage = "El EstadoRecepcion es requerida.")]
        public bool EstadoRecepcion { get; set; }

        [DataMember]
        [StringLength(500, MinimumLength = 0, ErrorMessage = "El largo del ErrorMessage debe ser de menor que 500.")]
        public string ErrorMessage { get; set; }
    }
}