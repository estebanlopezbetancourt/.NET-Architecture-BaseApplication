﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using TCS.Simce.Operaciones.WCF.Model;
using TCS.Simce.Operaciones.WCF.Repository;
using TCS.Simce.Operaciones.WCF.Util;
using TCS.Simce.WcfCommunicationService.Logging;

namespace TCS.Simce.Operaciones.WCF
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "Service1" en el código, en svc y en el archivo de configuración.
    // NOTE: para iniciar el Cliente de prueba WCF para probar este servicio, seleccione Service1.svc o Service1.svc.cs en el Explorador de soluciones e inicie la depuración.
    public class Service1 : ISmsService
    {
        public static void AppInitialize()
        {
            Log.Instance.Write(string.Format("El servicio ha sido iniciado a las {0} ", DateTime.Now), TCS.Simce.WcfCommunicationService.Logging.LogLevel.Info);
        }

        public SmsPullResponseDTO SmsPull(SmsPullRequestDTO request, string key)
        {
            SmsPullResponseDTO response = null;

            string KEY = System.Configuration.ConfigurationManager.AppSettings["EMAILVALIDATIONKEY"];

            if (!(key != null && key.Equals(KEY)))
            {
                Log.Instance.Write(string.Format("La key {0} es inválida", key), TCS.Simce.WcfCommunicationService.Logging.LogLevel.Error);
                response = new SmsPullResponseDTO() { EstadoRecepcion = false, ErrorMessage = string.Format("La key {0} es inválida", key) };
            }
            else
            {
                try
                {


                    using (var ctx = new Repository.SimceOperacionesEntities())
                    {
                        int celular = int.Parse(request.NumeroOrigen);

                        Repository.SmsEntrante smsEntrante = new Repository.SmsEntrante() { FechaIngreso = DateTime.Now, NumeroOrigen = celular, IdMobid = request.IdMobID, Texto = request.Texto, Procesado = false };

                        #region grabamos en tabla entrante

                        ctx.SmsEntrante.Add(smsEntrante);
                        ctx.SaveChanges();

                        #endregion grabamos en tabla entrante

                        ProcesarSms(smsEntrante, ctx);
                    }

                    response = new SmsPullResponseDTO() { IdMobID = request.IdMobID, EstadoRecepcion = true };
                }
                catch (Exception ex)
                {
                    Log.Instance.Exception("Error en servicio", ex);
                    //response = new SmsPullResponseDTO() { IdMobID = request.IdMobID, EstadoRecepcion = false, ErrorMessage = ex.ToString() };
                    response = new SmsPullResponseDTO() { IdMobID = request.IdMobID, EstadoRecepcion = false};
                }

            }
            Log.Instance.Write(string.Format("Request: {0}", Serializer.Serialize(request)), LogLevel.Info);
            Log.Instance.Write(string.Format("Response: {0}", Serializer.Serialize(response)), LogLevel.Info);

            return response;
        }

        private void ProcesarSms(Repository.SmsEntrante smsEntrante, SimceOperacionesEntities ctx)
        {
            int CODIGO_TIPOMOVIMIENTO_SMS = 2;

            #region grabamos en base de datos
            using (var dbContextTransaction = ctx.Database.BeginTransaction())
            {
                try
                {
                    //obtenemos persona por celular
                    Repository.Persona persona = ctx.Persona.First(p => p.celular == smsEntrante.NumeroOrigen);

                    List<Repository.EtapasMonitoreo> listaEtapas = ctx.EtapasMonitoreo.ToList();

                    //test
                    //Log.Instance.Write(string.Format("count Etapas: {0}", listaEtapas.Count.ToString()), LogLevel.Trace);
                    //foreach (var e in listaEtapas)
                    //{
                    //    Log.Instance.Write(string.Format("Etapa: {0}", e.ComandoSms), LogLevel.Trace);
                    //}
                    //Repository.EtapasMonitoreo etapa = listaEtapas.FirstOrDefault(p => p.ComandoSms.ToUpper().Trim() == smsEntrante.Texto.ToUpper().Trim());

                    //obtenemos etapa monitoreo                    
                    Repository.EtapasMonitoreo etapa = ctx.EtapasMonitoreo.FirstOrDefault(p => p.ComandoSms.ToUpper().Trim() == smsEntrante.Texto.ToUpper().Trim());                    

                    if (etapa == null)
                    {
                        throw new Exception(string.Format("Etapa: {0}, no encontrada", smsEntrante.Texto.ToUpper().Trim()));
                    }

                    //OBTENEMOS IDTIPOMOVIMIENTO
                    Repository.TipoMovimientoMonitoreo tipoMovimiento = ctx.TipoMovimientoMonitoreo.FirstOrDefault(p => p.codigo.HasValue && p.codigo.Value.Equals(CODIGO_TIPOMOVIMIENTO_SMS));

                    if (tipoMovimiento == null)
                    {
                        throw new Exception(string.Format("Tipo Movimiento: {0} no encontrada", CODIGO_TIPOMOVIMIENTO_SMS));
                    }

                    ctx.MovimientosMonitoreo.Add(new Repository.MovimientosMonitoreo()
                    {
                        rut = persona.rut,
                        dv = persona.dv,
                        celular = persona.celular,
                        estadoRegistro = 1,
                        idUsuarioCreacionRegistro = "SmsService",
                        fechaCreacionRegistro = DateTime.Now,
                        SubCentro_idSubCentro = persona.SubCentro_idSubCentro,
                        EtapasMonitoreo_idEtapaMonitoreo = etapa.idEtapaMonitoreo,
                        TipoMovimientoMonitoreo_idTipoMovimientoMonitoreo = tipoMovimiento.idTipoMovimientoMonitoreo,
                        Persona_idPersona = persona.idPersona
                    });

                    //actualizamos el registro en la bandeja y lo dejamos como procesado
                    smsEntrante.Procesado = true;

                    ctx.SaveChanges();
                    dbContextTransaction.Commit();
                }
                catch (Exception ex)
                {
                    dbContextTransaction.Rollback();
                    throw ex;
                }
            }
            #endregion grabamos en base de datos
        }
    }
}
