﻿using OfficeOpenXml;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;

namespace Simce_Recepcion.Util
{
    public static class ExcelHelper
    {
        public static ExcelRangeBase LoadFromCollectionWithHeaders<T>(this ExcelRange excelRange, IEnumerable<T> list)
        {
            int firstRow = excelRange.Start.Row;

            excelRange.LoadFromCollection<T>(list, true);

            int ColumnsCount = excelRange.Worksheet.Cells.Count() / list.Count();
            int Column = 1;

            PropertyInfo[] Properties = typeof(T).GetProperties();
            foreach (PropertyInfo Property in Properties)
            {
                object[] DisplayAttributes = Property.GetCustomAttributes(typeof(DisplayAttribute), true);

                if (DisplayAttributes.Length == 1)
                {
                    (((OfficeOpenXml.ExcelRangeBase)(excelRange.Worksheet.Cells[firstRow, Column]))).Value = ((DisplayAttribute)(DisplayAttributes[0])).Name;
                }
                else
                {
                    (((OfficeOpenXml.ExcelRangeBase)(excelRange.Worksheet.Cells[firstRow, Column]))).Value = " ";
                }
                Column++;
            }

            return excelRange;
        }
    }
}