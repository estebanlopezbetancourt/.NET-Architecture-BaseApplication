﻿//using Microsoft.Office.Interop.Excel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Operaciones.Reportes
{
    public partial class ReporteCuadraturaGuia : System.Web.UI.Page
    {
        private static string CLASS = "ReporteGuiaDespacho";
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;
            }
        }

        private void CargarCombos()
        {
            try
            {
                int idTipoEntidadDespachoDefault = 1;
                int idTipoEntidadRecepcionDefault = 2;

                ITipoDocumentoBLL tipoDocumento = new TipoDocumentoBLL();
                ddlTipoDocumento.DataSource = tipoDocumento.Listar();
                ddlTipoDocumento.DataTextField = "Descripcion";
                ddlTipoDocumento.DataValueField = "Id";
                ddlTipoDocumento.SelectedIndex = 0;
                ddlTipoDocumento.DataBind();

                ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();
                ddlTipoMovimiento.DataSource = tipoMovimiento.Listar();
                ddlTipoMovimiento.DataTextField = "Descripcion";
                ddlTipoMovimiento.DataValueField = "Id";
                ddlTipoMovimiento.SelectedIndex = 1;
                ddlTipoMovimiento.DataBind();
                ddlTipoMovimiento.Items.RemoveAt(0);

                ITipoEntidadDespachoBLL tipoEntidadDespacho = new TipoEntidadDespachoBLL();
                ddlTipoEntidadDespacho.DataSource = tipoEntidadDespacho.Listar();
                ddlTipoEntidadDespacho.DataTextField = "Descripcion";
                ddlTipoEntidadDespacho.DataValueField = "Id";
                ddlTipoEntidadDespacho.SelectedIndex = 0;
                ddlTipoEntidadDespacho.DataBind();


                ITipoEntidadRecepcionBLL tipoEntidadRecepcion = new TipoEntidadRecepcionBLL();
                ddlTipoEntidadRecepcion.DataSource = tipoEntidadRecepcion.Listar();
                ddlTipoEntidadRecepcion.DataTextField = "Descripcion";
                ddlTipoEntidadRecepcion.DataValueField = "Id";
                ddlTipoEntidadRecepcion.SelectedIndex = 0;
                ddlTipoEntidadRecepcion.DataBind();

                ddlEntidadDespacho.DataSource = CargarEntidadesDespacho(idTipoEntidadDespachoDefault);
                ddlEntidadDespacho.DataTextField = "Text";
                ddlEntidadDespacho.DataValueField = "Value";
                ddlEntidadDespacho.SelectedIndex = 0;
                ddlEntidadDespacho.DataBind();

                ddlEntidadRecepcion.DataSource = CargarEntidadesRecepcion(idTipoEntidadRecepcionDefault);
                ddlEntidadRecepcion.DataTextField = "Text";
                ddlEntidadRecepcion.DataValueField = "Value";
                ddlEntidadRecepcion.SelectedIndex = 0;
                ddlEntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;
                throw ex;
            }
        }

        protected void BtnGenerarCuadratura_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGenerarCuadratura_Click";

            try
            {
                #region ToGetValuesBack

                string tipoDocumento = Request.Form[ddlTipoDocumento.UniqueID];
                string tipoMovimiento = Request.Form[ddlTipoMovimiento.UniqueID];
                string tipoEntidadDepacho = Request.Form[ddlTipoEntidadDespacho.UniqueID];
                string entidadDespacho = Request.Form[ddlEntidadDespacho.UniqueID];
                string tipoEntidadRecepcion = Request.Form[ddlTipoEntidadRecepcion.UniqueID];
                string entidadRecepcion = Request.Form[ddlEntidadRecepcion.UniqueID];

                if (entidadDespacho != null || entidadRecepcion != null)
                {
                    PopulateDropDownList(CargarEntidadesDespacho(int.Parse(tipoEntidadDepacho)), ddlEntidadDespacho);
                    PopulateDropDownList(CargarEntidadesRecepcion(int.Parse(tipoEntidadRecepcion)), ddlEntidadRecepcion);
                    ddlEntidadDespacho.Items.FindByValue(entidadDespacho).Selected = true;
                    ddlEntidadRecepcion.Items.FindByValue(entidadRecepcion).Selected = true;
                }
                else
                {
                    LblMsg.Text = "Debe seleccionar los fecha desde y fecha hasta";
                    LblMsg.Visible = true;
                    return;
                }

                if (txtFechaDesde.Text.Trim() == "")
                {
                    LblMsg.Text = "Debe ingresar fecha desde";
                    LblMsg.Visible = true;
                    txtFechaDesde.Focus();
                    return;
                }

                if (txtFechaHasta.Text.Trim() == "")
                {
                    LblMsg.Text = "Debe ingresar fecha hasta";
                    LblMsg.Visible = true;
                    txtFechaHasta.Focus();
                    return;
                }

                DateTime fechaDesde = Convert.ToDateTime(txtFechaDesde.Text.Trim());
                DateTime fechaHasta = Convert.ToDateTime(txtFechaHasta.Text.Trim());
                string numeroDocumentoSeleccionada = Request.Form[ddlNumeroDocumento.UniqueID];

                if (numeroDocumentoSeleccionada != null)
                {
                    PopulateDropDownList(CargarNumerosDocumentos(int.Parse(tipoDocumento), int.Parse(tipoMovimiento),
                        int.Parse(tipoEntidadDepacho), int.Parse(entidadDespacho), int.Parse(tipoEntidadRecepcion),
                        int.Parse(entidadRecepcion), fechaDesde, fechaHasta), ddlNumeroDocumento);
                    ddlNumeroDocumento.Items.FindByValue(numeroDocumentoSeleccionada).Selected = true;
                }

                #endregion ToGetValuesBack

                this.LoadGridView();

                if (GrResumenCuadraturaGuia.Rows.Count == 0)
                {
                    LblMsg.Text = "No existen datos para búsqueda seleccionada";
                    LblMsg.Visible = true;
                }
                else
                {
                    int fila = 0;
                    foreach (GridViewRow dato in GrResumenCuadraturaGuia.Rows)
                    {

                        if (dato.Cells[9].Text == Convert.ToString('0'))
                        {
                            GrResumenCuadraturaGuia.Rows[fila].Cells[9].Text = "";
                            fila++;
                        }


                    }
                    LblMsg.Visible = false;
                }

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;
            }
        }

        protected void BtnConsultar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnConsultar_Click";

            try
            {
                ArrayList list = new ArrayList();

                #region ToGetValuesBack

                string tipoDocumentoSeleccionado = Request.Form[ddlTipoDocumento.UniqueID];
                string tipoMovimientoSeleccionado = Request.Form[ddlTipoMovimiento.UniqueID];
                string tipoEntidadDepachoSeleccionado = Request.Form[ddlTipoEntidadDespacho.UniqueID];
                string entidadDespachoSeleccionado = Request.Form[ddlEntidadDespacho.UniqueID];
                string tipoEntidadRecepcionSeleccionado = Request.Form[ddlTipoEntidadRecepcion.UniqueID];
                string entidadRecepcionSeleccionado = Request.Form[ddlEntidadRecepcion.UniqueID];

                if (entidadDespachoSeleccionado != null || entidadRecepcionSeleccionado != null)
                {
                    PopulateDropDownList(CargarEntidadesDespacho(int.Parse(tipoEntidadDepachoSeleccionado)), ddlEntidadDespacho);
                    PopulateDropDownList(CargarEntidadesRecepcion(int.Parse(tipoEntidadRecepcionSeleccionado)), ddlEntidadRecepcion);
                    ddlEntidadDespacho.Items.FindByValue(entidadDespachoSeleccionado).Selected = true;
                    ddlEntidadRecepcion.Items.FindByValue(entidadRecepcionSeleccionado).Selected = true;
                }
                else
                {
                    LblMsg.Text = "Debe seleccionar los campos fecha desde y fecha hasta";
                    LblMsg.Visible = true;
                    return;
                }

                if (txtFechaDesde.Text.Trim() == "")
                {
                    LblMsg.Text = "Debe ingresar fecha desde";
                    LblMsg.Visible = true;
                    txtFechaDesde.Focus();
                    return;
                }

                if (txtFechaHasta.Text.Trim() == "")
                {
                    LblMsg.Text = "Debe ingresar fecha hasta";
                    LblMsg.Visible = true;
                    txtFechaHasta.Focus();
                    return;
                }

                DateTime fechaDesdeSeleccionada = Convert.ToDateTime(txtFechaDesde.Text.Trim());
                DateTime fechaHastaSeleccionada = Convert.ToDateTime(txtFechaHasta.Text.Trim());
                string numeroDocumentoSeleccionada = Request.Form[ddlNumeroDocumento.UniqueID];

                if (numeroDocumentoSeleccionada != null)
                {
                    PopulateDropDownList(CargarNumerosDocumentos(int.Parse(tipoDocumentoSeleccionado), int.Parse(tipoMovimientoSeleccionado),
                        int.Parse(tipoEntidadDepachoSeleccionado), int.Parse(entidadDespachoSeleccionado), int.Parse(tipoEntidadRecepcionSeleccionado),
                        int.Parse(entidadRecepcionSeleccionado), fechaDesdeSeleccionada, fechaHastaSeleccionada), ddlNumeroDocumento);
                    ddlNumeroDocumento.Items.FindByValue(numeroDocumentoSeleccionada).Selected = true;
                }

                #endregion ToGetValuesBack


                int tipoDocumento = Convert.ToInt32(ddlTipoDocumento.Items[ddlTipoDocumento.SelectedIndex].Value);
                int tipoMovimiento = Convert.ToInt32(ddlTipoMovimiento.Items[ddlTipoMovimiento.SelectedIndex].Value);
                int tipoEntidadDespacho = Convert.ToInt32(ddlTipoEntidadDespacho.Items[ddlTipoEntidadDespacho.SelectedIndex].Value);
                int tipoEntidadRecepcion = Convert.ToInt32(ddlTipoEntidadRecepcion.Items[ddlTipoEntidadRecepcion.SelectedIndex].Value);

                int entidadDespacho = Convert.ToInt32(ddlEntidadDespacho.Items[ddlEntidadDespacho.SelectedIndex].Value);
                int entidadRecepcion = Convert.ToInt32(ddlEntidadRecepcion.Items[ddlEntidadRecepcion.SelectedIndex].Value);

                string fechaDesde = Convert.ToDateTime(txtFechaDesde.Text).ToString("yyyyMMdd");
                string fechaHasta = Convert.ToDateTime(txtFechaHasta.Text).ToString("yyyyMMdd");

                ddlNumeroDocumento.Items.Clear();
                ddlNumeroDocumento.Items.Add(new ListItem("--Seleccionar Número Documento--", ""));
                ddlNumeroDocumento.AppendDataBoundItems = true;

                IResumenCuadraturaGuiaBLL Cuadratura = new ResumenCuadraturaGuiaBLL();
                ddlNumeroDocumento.DataSource = Cuadratura.ListarDocumentos(tipoDocumento, tipoMovimiento, tipoEntidadDespacho,
                    entidadDespacho, tipoEntidadRecepcion, entidadRecepcion, fechaDesde, fechaHasta);

                ddlNumeroDocumento.DataTextField = "Text";
                ddlNumeroDocumento.DataValueField = "Value";
                ddlNumeroDocumento.DataBind();

                if (ddlNumeroDocumento.Items.Count > 1)
                {
                    ddlNumeroDocumento.Enabled = true;
                }


                else
                {
                    ddlNumeroDocumento.Enabled = false;
                    LblMsg.Text = "No se encontraron Documentos";
                    LblMsg.Visible = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;
            }
        }

        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnExportar_Click";

            try
            {
                this.DumpExcel();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }


        private void DumpExcel()
        {


            List<ResumenCuadraturaGuiaEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Consultar Resumen de Cuadratura de Guías de Despacho" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Documento", Valor = this.ddlTipoDocumento.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Movimiento", Valor = this.ddlTipoMovimiento.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Entidad Despacho", Valor = this.ddlTipoEntidadDespacho.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Entidad Despacho", Valor = this.ddlEntidadDespacho.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Entidad Recepcion", Valor = this.ddlTipoEntidadRecepcion.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Entidad Recepcion", Valor = this.ddlEntidadRecepcion.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Fecha Movimiento Desde", Valor = this.txtFechaDesde.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Fecha Movimiento Hasta", Valor = this.txtFechaHasta.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Numero Documento Despacho", Valor = this.ddlNumeroDocumento.SelectedItem.Text });



            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ResumenCuadraturaGuia_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A13"].LoadFromCollection(lista.ToArray(), true);
                    ExcelHelper.LoadFromCollectionWithHeaders<ResumenCuadraturaGuiaEN>(ws.Cells["A13"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:K1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ResumenCuadraturaGuia_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }

        /// <summary>
        /// Get Headers fron dataAnnotations.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="excelRange"></param>
        /// <param name="list"></param>
        /// <returns></returns>


        public List<ResumenCuadraturaGuiaEN> LoadLista()
        {
            List<ResumenCuadraturaGuiaEN> lista = new List<ResumenCuadraturaGuiaEN>();
            IResumenCuadraturaGuiaBLL consulta = new ResumenCuadraturaGuiaBLL();

            var tipoDocumento = Convert.ToInt32(ddlTipoDocumento.Items[ddlTipoDocumento.SelectedIndex].Value);
            var tipoMovimiento = Convert.ToInt32(ddlTipoMovimiento.Items[ddlTipoMovimiento.SelectedIndex].Value);
            var tipoEntidadDespacho = Convert.ToInt32(ddlTipoEntidadDespacho.Items[ddlTipoEntidadDespacho.SelectedIndex].Value);
            var tipoEntidadRecepcion = Convert.ToInt32(ddlTipoEntidadRecepcion.Items[ddlTipoEntidadRecepcion.SelectedIndex].Value);

            var entidadDespacho = Convert.ToInt32(ddlEntidadDespacho.Items[ddlEntidadDespacho.SelectedIndex].Value);
            var entidadRecepcion = Convert.ToInt32(ddlEntidadRecepcion.Items[ddlEntidadRecepcion.SelectedIndex].Value);

            var fechaDesde = Convert.ToDateTime(txtFechaDesde.Text).ToString("yyyyMMdd");
            var fechaHasta = Convert.ToDateTime(txtFechaHasta.Text).ToString("yyyyMMdd");

            //ddlNumeroDocumento.Items.Clear();
            //ddlNumeroDocumento.Items.Add(new ListItem("--Seleccionar Número Documento--", ""));
            //ddlNumeroDocumento.AppendDataBoundItems = true;

            int idpallet = Convert.ToInt32(ddlNumeroDocumento.Items[ddlNumeroDocumento.SelectedIndex].Value);
            int codigoPallet = Convert.ToInt32(ddlNumeroDocumento.Items[ddlNumeroDocumento.SelectedIndex].Text);

            IResumenCuadraturaGuiaBLL Cuadratura = new ResumenCuadraturaGuiaBLL();
            lista = consulta.Listar(idpallet, codigoPallet);

            return lista;
        }



        [System.Web.Services.WebMethod]
        //[System.Web.Script.Services.ScriptMethod()]
        public static ArrayList CargarEntidadesDespacho(int idTipoEntidad)
        {
            ArrayList list = new ArrayList();
            IEntidadDespachoBLL entidadDespacho = new EntidadDespachoBLL();
            list = entidadDespacho.Listado(idTipoEntidad);
            return list;
        }

        [System.Web.Services.WebMethod]
        //[System.Web.Script.Services.ScriptMethod()]
        public static ArrayList CargarEntidadesRecepcion(int idTipoEntidad)
        {
            ArrayList list = new ArrayList();
            IEntidadRecepcionBLL entidadRecepcion = new EntidadRecepcionBLL();
            list = entidadRecepcion.Listado(idTipoEntidad);
            return list;
        }

        [System.Web.Services.WebMethod]
        //[System.Web.Script.Services.ScriptMethod()]
        public static ArrayList CargarNumerosDocumentos(int tipoDocumento, int tipoMovimiento, int tipoEntidadDespacho,
                    int entidadDespacho, int tipoEntidadRecepcion, int entidadRecepcion, DateTime fechaDesde, DateTime fechaHasta)
        {
            string fechaDesdeSeleccionada;
            string fechaHastaSeleccionada;

            ArrayList list = new ArrayList();
            IResumenCuadraturaGuiaBLL Cuadratura = new ResumenCuadraturaGuiaBLL();

            fechaDesdeSeleccionada = fechaDesde.ToString("yyyyMMdd");
            fechaHastaSeleccionada = fechaHasta.ToString("yyyyMMdd");

            list = Cuadratura.ListarDocumentos(tipoDocumento, tipoMovimiento, tipoEntidadDespacho,
                entidadDespacho, tipoEntidadRecepcion, entidadRecepcion, fechaDesdeSeleccionada, fechaHastaSeleccionada);

            return list;
        }

        private void PopulateDropDownList(ArrayList list, DropDownList ddl)
        {
            ddl.DataSource = list;
            ddl.DataTextField = "Text";
            ddl.DataValueField = "Value";
            ddl.DataBind();
        }

        protected void ddlTipoEntidadRecepcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "ddlTipoEntidadRecepcion_SelectedIndexChanged";

            try
            {
                int idTipoEntidadRecepcion = Convert.ToInt32(ddlTipoEntidadRecepcion.SelectedItem.Value);
                ddlEntidadRecepcion.Items.Clear();
                //ddlEntidadRecepcion.Items.Add(new ListItem("--Seleccionar Entidad Recepción--", ""));
                ddlEntidadRecepcion.AppendDataBoundItems = true;

                IEntidadRecepcionBLL entidadRecepcion = new EntidadRecepcionBLL();

                ddlEntidadRecepcion.DataSource = entidadRecepcion.Listar(idTipoEntidadRecepcion).OrderBy(entidad => entidad.Descripcion).ToList();
                ddlEntidadRecepcion.DataTextField = "Descripcion";
                ddlEntidadRecepcion.DataValueField = "Codigo";
                ddlEntidadRecepcion.DataBind();

                if (ddlEntidadRecepcion.Items.Count > 1)
                {
                    ddlEntidadRecepcion.Enabled = true;
                }
                else
                {
                    ddlEntidadRecepcion.Enabled = false;
                    LblMsg.Text = "No se encontraron Entidades de Recepción";
                    LblMsg.Visible = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void ddlTipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "ddlTipoEntidadDespacho_SelectedIndexChanged";

            try
            {
                int idTipoEntidadDespacho = Convert.ToInt32(ddlTipoEntidadDespacho.SelectedItem.Value);
                ddlEntidadDespacho.Items.Clear();
                //ddlEntidadDespacho.Items.Add(new ListItem("--Seleccionar Entidad Recepción--", ""));
                ddlEntidadDespacho.AppendDataBoundItems = true;

                IEntidadDespachoBLL entidadDespacho = new EntidadDespachoBLL();

                ddlEntidadDespacho.DataSource = entidadDespacho.Listar(idTipoEntidadDespacho).OrderBy(entidad => entidad.Descripcion).ToList();
                ddlEntidadDespacho.DataTextField = "Descripcion";
                ddlEntidadDespacho.DataValueField = "Codigo";
                ddlEntidadDespacho.DataBind();

                if (ddlEntidadDespacho.Items.Count > 1)
                {
                    ddlEntidadDespacho.Enabled = true;
                }
                else
                {
                    ddlEntidadDespacho.Enabled = false;
                    LblMsg.Text = "No se encontraron Entidades de Despacho";
                    LblMsg.Visible = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void GrResumenCuadraturaGuia_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "GrResumenCuadraturaGuia_PageIndexChanging";

            try
            {
                this.GrResumenCuadraturaGuia.PageIndex = e.NewPageIndex;
                this.LoadGridView();

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void LoadGridView()
        {
            if (ddlNumeroDocumento.Items.Count < 1)
            {
                LblMsg.Text = "No se han encontrado Documentos de Despacho";
                LblMsg.Visible = true;
                return;
            }

            int idPallet = Convert.ToInt32(ddlNumeroDocumento.Items[ddlNumeroDocumento.SelectedIndex].Value);
            int codigoPallet = Convert.ToInt32(ddlNumeroDocumento.Items[ddlNumeroDocumento.SelectedIndex].Text);

            if (idPallet == 0)
            {
                LblMsg.Text = "Debe seleccionar Número Documento Despacho";
                LblMsg.Visible = true;
                return;
            }

            IResumenCuadraturaGuiaBLL Cuadratura = new ResumenCuadraturaGuiaBLL();
            GrResumenCuadraturaGuia.DataSource = Cuadratura.Listar(idPallet, codigoPallet);
            GrResumenCuadraturaGuia.DataBind();
        }
    }
}