﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;


namespace Simce_Recepcion.Reportes.RecepcionDespacho
{
    public partial class ReporteDespachoRecepcionSupervisor : System.Web.UI.Page 
    {
        private static string CLASS = "ReporteDespachoSupervisores";
        protected void Page_Load(object sender, EventArgs e)
        {

            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }

        }

        private void CargarCombos()
        {
            string METHOD = "CargarCombos";

            try
            {

                IEntidadImprentaBLL EntidadImprentaBLL = new EntidadImprentaBLL();

              
                ITipoPruebaBLL TipoPruebaBLL = new TipoPruebaBLL();
                DP_TipoPrueba.DataSource = TipoPruebaBLL.Listar();
                DP_TipoPrueba.DataTextField = "descripcion";
                DP_TipoPrueba.DataValueField = "Id";
                DP_TipoPrueba.DataBind();

                INivelBLL NivelBLL = new NivelBLL();
                DP_Nivel.DataSource = NivelBLL.Listar();
                DP_Nivel.DataTextField = "descripcion";
                DP_Nivel.DataValueField = "Id";
                DP_Nivel.DataBind();

                ISubCentroBLL SubCentroBLL = new SubCentroBLL();

                DP_SubCentro.DataSource = SubCentroBLL.Listar();
                DP_SubCentro.DataTextField = "descripcion";
                DP_SubCentro.DataValueField = "Id";
                DP_SubCentro.DataBind();

                //ISupervisorBLL SupervisorBLL = new SupervisorBLL();
                //DP_Supervisor.DataSource = SupervisorBLL.Listar(Convert.ToInt16(DP_SubCentro.SelectedItem.Value));
                //DP_Supervisor.DataTextField = "nombre";
                //DP_Supervisor.DataValueField = "Id";
                //DP_Supervisor.DataBind();

                ITipoInformeBLL TipoInformeBLL = new TipoInformeBLL();

                DP_tipoInforme.DataSource = TipoInformeBLL.Listar();
                DP_tipoInforme.DataTextField = "descripcion";
                DP_tipoInforme.DataValueField = "Id";
                DP_tipoInforme.DataBind();

            }
            catch (Exception ex)
            {


                Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;

                throw ex;
            }
        }

    

        protected void BtnGenerarCuadratura_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGenerarCuadratura";

            try
            {
                int tipoInforme = Convert.ToInt16(DP_tipoInforme.Items[DP_tipoInforme.SelectedIndex].Value);
                
                if (tipoInforme == 1)
                {
                    this.LoadGridView();

                    if (GrInformeDespachoSupervisores.Rows.Count == 0)
                    {

                        LblMsg.Text = "No existen datos para búsqueda seleccionada";
                        LblMsg.Visible = true;
                    }
                    else
                    {
                        LblMsg.Visible = false;
                    }
                }
                else 
                {
                    this.LoadGridViewDetalle();

                    if (GrInformeDespachoSupervisoresDetalle.Rows.Count == 0)
                    {

                        LblMsg.Text = "No existen datos para búsqueda seleccionada";
                        LblMsg.Visible = true;
                    }
                    else
                    {
                        LblMsg.Visible = false;
                    }
                
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }      
           
        }

        private void LoadGridView()
        {
            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int SubCentro = Convert.ToInt16(DP_SubCentro.Items[DP_SubCentro.SelectedIndex].Value);

            GrInformeDespachoSupervisoresDetalle.DataBind();
            
            IReporteRecepcionDespachoSupervisoresBLL ReporteRecepcionDespachoSupervisores = new ReporteRecepcionDespachoSupervisoresBLL();
            GrInformeDespachoSupervisores.DataSource = ReporteRecepcionDespachoSupervisores.ReporteDespachoSupervisores(Nivel, TipoPrueba, SubCentro);
            GrInformeDespachoSupervisores.DataBind();
        }

        protected void GrInformeDespachoSupervisores_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "GrInformeDespachoSupervisores_PageIndexChanging";

            try
            {

                this.GrInformeDespachoSupervisores.PageIndex = e.NewPageIndex;
                this.LoadGridView();
            }

            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }

/**********************DETALLE**********/

        private void LoadGridViewDetalle()
        {
            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int SubCentro = Convert.ToInt16(DP_SubCentro.Items[DP_SubCentro.SelectedIndex].Value);
            
            GrInformeDespachoSupervisores.DataBind();
           
            IReporteRecepcionDespachoSupervisoresDetalleBLL ReporteRecepcionDespachoSupervisoresDetalle = new ReporteRecepcionDespachoSupervisoresDetalleBLL();
            GrInformeDespachoSupervisoresDetalle.DataSource = ReporteRecepcionDespachoSupervisoresDetalle.ReporteDespachoSupervisoresDetalle(Nivel, TipoPrueba, SubCentro);
            GrInformeDespachoSupervisoresDetalle.DataBind();
            
        }

        protected void GrInformeDespachoSupervisoresDetalle_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "LoadGridViewDetalle";

            try
            {

                this.GrInformeDespachoSupervisoresDetalle.PageIndex = e.NewPageIndex;
                this.LoadGridViewDetalle();
            }

            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }

      
        /******************* EXCEL *************************************/
        
        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            int tipoInforme = Convert.ToInt16(DP_tipoInforme.Items[DP_tipoInforme.SelectedIndex].Value);

            if (tipoInforme == 1)
            {
                DumpExcel();
            }
            else 
            {
                DumpExcelDetalle();
            }
        }

        private void DumpExcel()
        {
            List<ReporteRecepcionDespachoSupervisoresEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Informe Cuadratura Entre Sub Centro Hacia Supervisores" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.DP_Nivel.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Sub Centro", Valor = this.DP_SubCentro.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Prueba", Valor = this.DP_TipoPrueba.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Informe", Valor = this.DP_tipoInforme.SelectedItem.Text });


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ReporteRecepcionDespachoSupervisores_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A8"].LoadFromCollection(lista, true);
                    ExcelHelper.LoadFromCollectionWithHeaders<ReporteRecepcionDespachoSupervisoresEN>(ws.Cells["A8"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:K1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ReporteRecepcionDespachoSupervisores_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }

        private List<ReporteRecepcionDespachoSupervisoresEN> LoadLista()
        {
            List<ReporteRecepcionDespachoSupervisoresEN> lista = new List<ReporteRecepcionDespachoSupervisoresEN>();
            IReporteRecepcionDespachoSupervisoresBLL consulta = new ReporteRecepcionDespachoSupervisoresBLL();



            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int SubCentro = Convert.ToInt16(DP_SubCentro.Items[DP_SubCentro.SelectedIndex].Value);

            IReporteRecepcionDespachoSupervisoresBLL ReporteRecepcionDespachoSupervisores = new ReporteRecepcionDespachoSupervisoresBLL();
            lista = consulta.ReporteDespachoSupervisores(Nivel, TipoPrueba, SubCentro);            
            return lista;
        }


        private void DumpExcelDetalle()
        {
            List<ReporteRecepcionDespachoSupervisoresDetalleEN> lista = LoadListaDetalle();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Informe Cuadratura Entre Sub Centro Hacia Supervisores Detalle" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.DP_Nivel.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Sub Centro", Valor = this.DP_SubCentro.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Prueba", Valor = this.DP_TipoPrueba.SelectedItem.Text });            
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Informe", Valor = this.DP_tipoInforme.SelectedItem.Text });


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ReporteDespachoSupervisoresDetalle_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A8"].LoadFromCollection(lista, true);
                    ExcelHelper.LoadFromCollectionWithHeaders<ReporteRecepcionDespachoSupervisoresDetalleEN>(ws.Cells["A8"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:K1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ReporteDespachoSupervisoresDetalle_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }


        private List<ReporteRecepcionDespachoSupervisoresDetalleEN> LoadListaDetalle()
        {
            List<ReporteRecepcionDespachoSupervisoresDetalleEN> lista = new List<ReporteRecepcionDespachoSupervisoresDetalleEN>();
            IReporteRecepcionDespachoSupervisoresDetalleBLL consulta = new ReporteRecepcionDespachoSupervisoresDetalleBLL();



            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int SubCentro = Convert.ToInt16(DP_SubCentro.Items[DP_SubCentro.SelectedIndex].Value);

            IReporteRecepcionDespachoSupervisoresDetalleBLL ReporteRecepcionDespachoSupervisores = new ReporteRecepcionDespachoSupervisoresDetalleBLL();
            lista = consulta.ReporteDespachoSupervisoresDetalle(Nivel, TipoPrueba, SubCentro);
            return lista;
        }
    }

}