﻿//PARA EXPORTACION A EXCEL
//using Microsoft.Office.Interop.Excel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;


namespace Simce_Operaciones.Reportes
{

    public partial class RecepcionInformeCuadraturaCajasImprenta : System.Web.UI.Page
    {
        private static string CLASS = "ReporteImprenta";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";           

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }

        }

        private void CargarCombos()
        {
            string METHOD = "CargarCombos";

            try
            {

                IEntidadImprentaBLL EntidadImprentaBLL = new EntidadImprentaBLL();

                DP_EntidadImprenta.DataSource = EntidadImprentaBLL.Listar();
                DP_EntidadImprenta.DataTextField = "descripcion";
                DP_EntidadImprenta.DataValueField = "Id";
                DP_EntidadImprenta.DataBind();

                ITipoMaterialBLL TipoMaterialBLL = new TipoMaterialBLL();
                DP_tipoMaterial.DataSource = TipoMaterialBLL.Listar();
                DP_tipoMaterial.DataTextField = "descripcion";
                DP_tipoMaterial.DataValueField = "Id";
                DP_tipoMaterial.DataBind();


                ITipoPruebaBLL TipoPruebaBLL = new TipoPruebaBLL();
                DP_TipoPrueba.DataSource = TipoPruebaBLL.Listar();
                DP_TipoPrueba.DataTextField = "descripcion";
                DP_TipoPrueba.DataValueField = "Id";
                DP_TipoPrueba.DataBind();

                INivelBLL NivelBLL = new NivelBLL();
                DP_Nivel.DataSource = NivelBLL.Listar();
                DP_Nivel.DataTextField = "descripcion";
                DP_Nivel.DataValueField = "Id";
                DP_Nivel.DataBind();
            }
            catch (Exception ex)
            {

                
                Log.Instance.Write(ex.Message, LogLevel.Error);
                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;

                throw ex;
            }
        }

        protected void BtnGenerarCuadratura_Click(object sender, EventArgs e)
        {

            string METHOD = "BtnGenerarCuadratura";

            try
            {
                this.LoadGridView();

                if (GrInformeCuadraturaCajasImprenta.Rows.Count == 0)
                {
                    LblMsg.Text = "No existen datos para búsqueda seleccionada";
                    LblMsg.Visible = true;
                }
                else
                {
                    LblMsg.Visible = false;
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }

        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            DumpExcel();
        }

        private void DumpExcel()
        {
            List<InformeCuadraturaCajasImprentaEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Consultar Resumen de Cuadratura de Cajas de Imprenta" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Entidad Imprenta", Valor = this.DP_EntidadImprenta.SelectedItem.Text});
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Material", Valor = this.DP_tipoMaterial.SelectedItem.Text});
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.DP_Nivel.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Prueba", Valor = this.DP_TipoPrueba.SelectedItem.Text });


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ResumenCuadraturaImprenta_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A8"].LoadFromCollection(lista, true);
                    ExcelHelper.LoadFromCollectionWithHeaders<InformeCuadraturaCajasImprentaEN>(ws.Cells["A8"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:K1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ResumenCuadraturaImprenta_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }       

        private List<InformeCuadraturaCajasImprentaEN> LoadLista()
        {
            List<InformeCuadraturaCajasImprentaEN> lista = new List<InformeCuadraturaCajasImprentaEN>();
            IInformeCuadraturaCajasImprentaBLL consulta = new InformeCuadraturaCajasImprentaBLL();


            int Imprenta = 0;
            int TipoMaterial = 0;
            int TipoPrueba = 0;
            int Nivel = 0;

            Imprenta = Convert.ToInt16(DP_EntidadImprenta.Items[DP_EntidadImprenta.SelectedIndex].Value);
            TipoMaterial = Convert.ToInt16(DP_tipoMaterial.Items[DP_tipoMaterial.SelectedIndex].Value);
            Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            

            
            lista = consulta.informeCuadraturaCajasImprentaLista(Imprenta, TipoMaterial, TipoPrueba, Nivel);
            return lista;
        }


        protected void DP_tipoMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            int TipoMaterialSel = Convert.ToInt16(DP_tipoMaterial.Items[DP_tipoMaterial.SelectedIndex].Value);

            if (TipoMaterialSel == 3 || TipoMaterialSel == 2)
            {
                DP_TipoPrueba.Enabled = true;
            }
            else
            {
                DP_TipoPrueba.Enabled = false;
                DP_TipoPrueba.ClearSelection();
            }
        }

        protected void GrInformeCuadraturaCajasImprenta_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "GrInformeCuadraturaCajasImprenta";

            try
            {

                this.GrInformeCuadraturaCajasImprenta.PageIndex = e.NewPageIndex;
                this.LoadGridView();
            }

            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }
        private void LoadGridView()
        {
            int Imprenta = Convert.ToInt16(DP_EntidadImprenta.Items[DP_EntidadImprenta.SelectedIndex].Value);
            int TipoMaterial = Convert.ToInt16(DP_tipoMaterial.Items[DP_tipoMaterial.SelectedIndex].Value);

            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);

            IInformeCuadraturaCajasImprentaBLL InformeCuadraturaCajasImprentaBLL = new InformeCuadraturaCajasImprentaBLL();
            GrInformeCuadraturaCajasImprenta.DataSource = InformeCuadraturaCajasImprentaBLL.informeCuadraturaCajasImprentaLista(Imprenta, TipoMaterial, TipoPrueba, Nivel);
            GrInformeCuadraturaCajasImprenta.DataBind();
        }
    }
}