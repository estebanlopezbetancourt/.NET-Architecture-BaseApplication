﻿//PARA EXPORTACION A EXCEL
//using Microsoft.Office.Interop.Excel;
using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;


namespace Simce_Operaciones.Reportes
{

    public partial class InformeCudraturaEntreSubCentroYCOPrincipal : System.Web.UI.Page
    {
        private static string CLASS = "InformeCudraturaEntreCOPrincipalYSubCentro";
        
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";           

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }

        }

        private void CargarCombos()
        {
            string METHOD = "CargarCombos";

            try
            {

                ITipoPruebaBLL TipoPruebaBLL = new TipoPruebaBLL();
                DP_TipoPrueba.DataSource = TipoPruebaBLL.Listar();
                DP_TipoPrueba.DataTextField = "descripcion";
                DP_TipoPrueba.DataValueField = "Id";
                DP_TipoPrueba.DataBind();

                INivelBLL NivelBLL = new NivelBLL();
                DP_Nivel.DataSource = NivelBLL.Listar();
                DP_Nivel.DataTextField = "descripcion";
                DP_Nivel.DataValueField = "Id";
                DP_Nivel.DataBind();

                ITipoInformeBLL tipoInformeBLL = new TipoInformeBLL();
                DP_TipoInforme.DataSource = tipoInformeBLL.Listar();
                DP_TipoInforme.DataTextField = "Descripcion";
                DP_TipoInforme.DataValueField = "Id";
                DP_TipoInforme.DataBind();

                ISubCentroBLL SubCentroBLL = new SubCentroBLL();

                DP_SubCentro.DataSource = SubCentroBLL.Listar();
                DP_SubCentro.DataTextField = "descripcion";
                DP_SubCentro.DataValueField = "Id";
                DP_SubCentro.DataBind();

            }
            catch (Exception ex)
            {


                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;

                throw ex;
            }
        }

        protected void BtnGenerarCuadratura_Click(object sender, EventArgs e)
        {

            string METHOD = "BtnGenerarCuadratura";

            try
            {
                this.LoadGridView();

                if (GrInformeCuadraturaEntreCOPrincipalYSubCentroResumen.Rows.Count == 0)
                {
                    LblMsg.Text = "No existen datos para búsqueda seleccionada";
                    LblMsg.Visible = true;
                }
                else
                {
                    LblMsg.Visible = false;
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            DumpExcel();
        }

        private void DumpExcel()
        {
            List<ReporteRecepcionDespachoResumenEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Informe Cudratura Entre CO Principal y Sub Centro" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.DP_Nivel.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Prueba", Valor = this.DP_TipoPrueba.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Sub Centro", Valor = this.DP_SubCentro.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Informe", Valor = this.DP_TipoInforme.SelectedItem.Text });


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ResumenCuadraturaImprenta_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A8"].LoadFromCollection(lista, true);
                    ExcelHelper.LoadFromCollectionWithHeaders<ReporteRecepcionDespachoResumenEN>(ws.Cells["A8"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:F1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ResumenCuadraturaImprenta_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }

        private List<ReporteRecepcionDespachoResumenEN> LoadLista()
        {
            List<ReporteRecepcionDespachoResumenEN> lista = new List<ReporteRecepcionDespachoResumenEN>();

            int TipoPrueba = 0;
            int Nivel = 0;
            int SubCentro = 0;
            int TipoInforme = 0;

            TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            SubCentro = Convert.ToInt16(DP_SubCentro.SelectedItem.Value);
            TipoInforme = Convert.ToInt16(DP_TipoInforme.SelectedItem.Value);

            IReporteRecepcionBLL reporteRecepcion = new ReporteRecepcionBLL();

            if (TipoInforme == 1)
            {
                lista = reporteRecepcion.ReporteRecepcionDespachoCOPrincipalSubcentroResumen(Nivel, TipoPrueba, 3, SubCentro, 2, 1);
            }
            
            return lista;
        }

        protected void GrInformeCuadraturaEntreCOPrincipalYSubCentroResumen_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "GrInformeCuadraturaCajasImprenta";

            try
            {

                this.GrInformeCuadraturaEntreCOPrincipalYSubCentroResumen.PageIndex = e.NewPageIndex;
                this.LoadGridView();
            }

            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }
        private void LoadGridView()
        {
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);
            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int SubCentro = Convert.ToInt16(DP_SubCentro.SelectedItem.Value);
            int TipoInforme = Convert.ToInt16(DP_TipoInforme.SelectedItem.Value);

            IReporteRecepcionBLL reporteRecepcion = new ReporteRecepcionBLL();

            if (TipoInforme == 1)
            {
                GrInformeCuadraturaEntreCOPrincipalYSubCentroResumen.DataSource = reporteRecepcion.ReporteRecepcionDespachoCOPrincipalSubcentroResumen(Nivel, TipoPrueba, 3, SubCentro, 2, 1);
            }
            
            GrInformeCuadraturaEntreCOPrincipalYSubCentroResumen.DataBind();
        }
    }
}