﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.Aplicacion;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Aplicacion;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Recepcion.Modulos.Aplicacion
{
    public partial class RegistroVisitaPrevia : System.Web.UI.Page
    {
        private static string CLASS = "RegistroVisitaPrevia";
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";
            try
            {
                if (!IsPostBack)
                {
                    LimpiarControles();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnConsultar_Click";
            try
            {
                LimpiarControlesConsulta();
                if (txtRbd.Value.Trim() == "")
                {
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Rbd');", true);
                    lblMsgConsulta.InnerText = "Debe ingresar Rbd";
                    lblMsgConsulta.Visible = true;
                    txtRbd.Focus();
                    return;
                }

                //if (txtDbrbd.Value.Trim() == "")
                //{
                //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar el Digito Verificador del RBD');", true);
                //    txtRbd.Focus();
                //    return;
                //}

                if (txtLetraCurso.Value.Trim() == "")
                {
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Letra Curso');", true);
                    lblMsgConsulta.InnerText = "Debe ingresar Letra Curso";
                    lblMsgConsulta.Visible = true;
                    txtLetraCurso.Focus();
                    return;
                }

                bool existeCurso = BuscarCurso();
                if(!existeCurso)
                {
                    lblMsgConsulta.InnerText = "Curso No Existe";
                    lblMsgConsulta.Visible = true;
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Curso No Existe');", true);
                    return;                
                }

                bool cargo = CargarControlesVisitaPrevia();
                //if (!cargo)
                //{
                //    lblMsgConsulta.InnerText = "Ingrese los datos";
                //    lblMsgConsulta.Visible = true;
                //    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Ingrese los datos');", true);
                //    return;
                //}

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private bool BuscarCurso()
        {
            bool existeCurso = false;
            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            CursoContenedoresEN curso = new CursoContenedoresEN();
            CursoContenedoresEN cursoEncontrado = new CursoContenedoresEN();

            curso.IdNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            curso.Rbd = Convert.ToInt32(txtRbd.Value.Trim());
            curso.DvRbd = txtDbrbd.Value.Trim();
            curso.LetraCurso = txtLetraCurso.Value.Trim();

            if (txtSerieCajaCurso.Value.Trim() != "")
            {
                curso.SerieCajaCurso = Convert.ToInt32(txtSerieCajaCurso.Value.Trim());
            }

            cursoEncontrado = aplicacionAulaBLL.BuscarCurso(curso);
            if (cursoEncontrado.IdCurso > 0)
            {
                hdIdCurso.Value = cursoEncontrado.IdCurso.ToString();
                if (curso.SerieCajaCurso == 0)
                {
                    txtSerieCajaCurso.Value = cursoEncontrado.SerieCajaCurso.ToString();                
                }
                if (curso.DvRbd == "")
                {
                    txtDbrbd.Value = cursoEncontrado.DvRbd;                
                }

                existeCurso = true;
            }

            return existeCurso;
        }


        private bool CargarControlesVisitaPrevia()
        {
            bool cargo = false;
            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            RegistroVisitaPreviaEN registro = new RegistroVisitaPreviaEN();
            int idNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            int rbd = Convert.ToInt32(txtRbd.Value.Trim());
            string letraCurso = txtLetraCurso.Value.Trim();

            registro = aplicacionAulaBLL.BuscarDatosVisitaPrevia(idNivel, rbd, letraCurso);

            if (registro != null && registro.idAplicacionAula >= 1)
            {
                hdIdAplicacionAula.Value = registro.idAplicacionAula.ToString();
                hdIdCurso.Value = registro.idCurso.ToString();
                hdIdNivel.Value = registro.idNivel.ToString();
                if (registro.FechaRealizacion >= Convert.ToDateTime("01-01-2014"))
                {
                    txtFechaRealizacion.Value = registro.FechaRealizacion.ToString("dd-MM-yyyy");                
                }

                txtObservacion.Value = registro.Observacion;

                ddlAplicoVisita.Items.Clear();
                CargarComboAplicoVisita();
                ddlAplicoVisita.Items.FindByValue(registro.AplicoVisitaPrevia.ToString()).Selected = true;

                cargo = true;
            }

            btnGuardar.Disabled = false;
            btnLimpiar.Disabled = false;
            return cargo;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnGuardar_Click";
            bool guardo = false;
            try
            {
                LimpiarControlesMensaje();
                IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();

                if (txtFechaRealizacion.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe seleccionar la fecha');", true);
                    return;
                }

                RegistroVisitaPreviaEN registro = CargarDatosVisitaPrevia();

                if (registro.idCurso < 1)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No se encontro datos correspondientes en la tabla Curso');", true);
                    return;
                }

                guardo = aplicacionAulaBLL.RegistrarVisitaPrevia(registro);

                if (!guardo)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No se guardaron los datos');", true);
                    return;
                }
                else
                {
                    LimpiarControles();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private RegistroVisitaPreviaEN CargarDatosVisitaPrevia()
        {
            RegistroVisitaPreviaEN registro = new RegistroVisitaPreviaEN();

            if (hdIdAplicacionAula.Value != "")
            {
                registro.idAplicacionAula = Convert.ToInt32(hdIdAplicacionAula.Value.Trim());
            }
            if (hdIdCurso.Value != "")
            {
                registro.idCurso = Convert.ToInt32(hdIdCurso.Value.Trim());
            }
            registro.idNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            registro.Nivel = ddlNivel.Items[ddlNivel.SelectedIndex].Text;

            registro.Rbd = Convert.ToInt32(txtRbd.Value.Trim());
            registro.DvRbd = txtDbrbd.Value.Trim();

            registro.LetraCurso = txtLetraCurso.Value.Trim().ToUpper();

            if (txtSerieCajaCurso.Value != "")
            {
                registro.SerieCajaCurso = Convert.ToInt32(txtSerieCajaCurso.Value.Trim());
            }

            registro.FechaRealizacion = Convert.ToDateTime(txtFechaRealizacion.Value);
            registro.AplicoVisitaPrevia = Convert.ToInt32(ddlAplicoVisita.Items[ddlAplicoVisita.SelectedIndex].Value);
            registro.Observacion = txtObservacion.Value;

            return registro;
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnLimpiar_Click";
            try
            {
                LimpiarControles();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void CargarCombos()
        {
            ddlNivel.DataSource = null;
            ddlNivel.DataBind();

            INivelBLL nivelBLL = new NivelBLL();
            List<NivelEN> listado = new List<NivelEN>();
            listado = nivelBLL.Listar();
            var item = listado.Single(x => x.Id == 0);
            listado.Remove(item);

            ddlNivel.DataSource = listado;
            ddlNivel.DataTextField = "Descripcion";
            ddlNivel.DataValueField = "Id";
            ddlNivel.DataBind();
        }

        private void CargarComboAplicoVisita()
        {
            ddlAplicoVisita.DataSource = null;
            ddlAplicoVisita.DataBind();

            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            ddlAplicoVisita.DataSource = aplicacionAulaBLL.ListarAplicoExp();
            ddlAplicoVisita.DataTextField = "Descripcion";
            ddlAplicoVisita.DataValueField = "Id";
            ddlAplicoVisita.DataBind();

        }

        private void LimpiarControles()
        {
            txtRbd.Value = "";
            txtDbrbd.Value = "";
            txtLetraCurso.Value = "";
            txtSerieCajaCurso.Value = "";
            LimpiarControlesConsulta();
            CargarCombos();
        }

        private void LimpiarControlesConsulta()
        {
            LimpiarControlesMensaje();
            txtFechaRealizacion.Value = "";
            txtObservacion.Value = "";
            hdIdCurso.Value = "";
            hdIdAplicacionAula.Value = "";
            hdIdNivel.Value = "";
            CargarComboAplicoVisita();
            btnGuardar.Disabled = true;
            btnLimpiar.Disabled = true;
        }

        private void LimpiarControlesMensaje()
        {
            lblMsgConsulta.InnerText = "";
            lblMsgConsulta.Visible = false;        
        }
    }
}