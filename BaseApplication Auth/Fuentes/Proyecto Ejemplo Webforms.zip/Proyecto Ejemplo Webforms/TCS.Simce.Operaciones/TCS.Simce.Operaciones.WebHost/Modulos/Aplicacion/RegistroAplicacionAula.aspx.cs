﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.Aplicacion;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.BLL.Usuario;
using Simce_Recepcion.Util;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.Aplicacion;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Recepcion.Modulos.Aplicacion
{
    public partial class RegistroAplicacionAula : System.Web.UI.Page
    {
        private static string CLASS = "RegistroAplicacionAula";
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";
            try
            {
                if(!IsPostBack)
                {
                    LimpiarControles();
                }            
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnConsultar_Click";
            try
            {
                LimpiarControlesConsulta();

                if (txtRbd.Value.Trim() == "")
                {
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Rbd');", true);
                    lblMsgConsulta.InnerText = "Debe ingresar Rbd";
                    lblMsgConsulta.Visible = true;
                    txtRbd.Focus();
                    return;
                }

                //if (txtDbrbd.Value.Trim() == "")
                //{
                //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar el Digito Verificador del RBD');", true);
                //    txtRbd.Focus();
                //    return;
                //}

                if (txtLetraCurso.Value.Trim() == "")
                {
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Letra Curso');", true);
                    lblMsgConsulta.InnerText = "Debe ingresar Letra Curso";
                    lblMsgConsulta.Visible = true;
                    txtLetraCurso.Focus();
                    return;
                }

                bool existeCurso = BuscarCurso();
                if (!existeCurso)
                {
                    lblMsgConsulta.InnerText = "Curso No Existe";
                    lblMsgConsulta.Visible = true;
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Curso No Existe');", true);
                    return;
                }

                bool cargo = CargarControlesAplicacionAula();
                //if(!cargo)
                //{
                //    lblMsgConsulta.InnerText = "Ingrese los datos";
                //    lblMsgConsulta.Visible = true;
                //    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Ingrese los datos');", true);
                //    return;                
                //}
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private bool BuscarCurso()
        {
            bool existeCurso = false;
            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            CursoContenedoresEN curso = new CursoContenedoresEN();
            CursoContenedoresEN cursoEncontrado = new CursoContenedoresEN();

            curso.IdNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            curso.Rbd = Convert.ToInt32(txtRbd.Value.Trim());
            curso.DvRbd = txtDbrbd.Value.Trim();
            curso.LetraCurso = txtLetraCurso.Value.Trim();

            if (txtSerieCajaCurso.Value.Trim() != "")
            {
                curso.SerieCajaCurso = Convert.ToInt32(txtSerieCajaCurso.Value.Trim());
            }

            cursoEncontrado = aplicacionAulaBLL.BuscarCurso(curso);
            if (cursoEncontrado.IdCurso > 0)
            {
                hdIdCurso.Value = cursoEncontrado.IdCurso.ToString();
                if (curso.SerieCajaCurso == 0)
                {
                    txtSerieCajaCurso.Value = cursoEncontrado.SerieCajaCurso.ToString();
                }
                if (curso.DvRbd == "")
                {
                    txtDbrbd.Value = cursoEncontrado.DvRbd;
                }
                existeCurso = true;
            }

            return existeCurso;
        }

        private bool CargarControlesAplicacionAula()
        {
            bool cargo = false;
            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            RegistroAplicacionAulaEN registro = new RegistroAplicacionAulaEN();
            int idNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            int rbd = Convert.ToInt32(txtRbd.Value.Trim());
            string letraCurso = txtLetraCurso.Value.Trim();

            registro = aplicacionAulaBLL.BuscarDatosAplicacionAula(idNivel, rbd, letraCurso);

            if (registro != null && registro.idAplicacionAula >= 1)
            {
                hdIdAplicacionAula.Value = registro.idAplicacionAula.ToString();
                hdIdCurso.Value = registro.idCurso.ToString();
                hdIdNivel.Value = registro.idNivel.ToString();
                if (registro.CantidadCuestionariosPAEntregados > 0)
                {
                    txtCPEntregados.Value = registro.CantidadCuestionariosPAEntregados.ToString(); 
                }

                if (registro.CantidadCuestionariosPARecibidos > 0)
                {
                    txtCPDevueltos.Value = registro.CantidadCuestionariosPARecibidos.ToString();
                }
                
                if (registro.CantidadCuestionariosDocenteEntregados > 0)
                {
                    txtCDEntregados.Value = registro.CantidadCuestionariosDocenteEntregados.ToString(); 
                }
                
                if (registro.CantidadCuestionariosDocenteRecibidos > 0)
                {
                    txtCDDevueltos.Value = registro.CantidadCuestionariosDocenteRecibidos.ToString();
                }
                
                if (registro.SerieCajaCursoDia1Contingencia > 0)
                {
                    txtSerieCajaCursoDia1.Value = registro.SerieCajaCursoDia1Contingencia.ToString();
                }
                
                if (registro.SerieDocumentoDesdeDia1Contingencia > 0)
                {
                    txtSerieDesdeDia1.Value = registro.SerieDocumentoDesdeDia1Contingencia.ToString();
                }
                
                if (registro.SerieDocumentoHastaDia1Contingencia > 0)
                {
                    txtSerieHastaDia1.Value = registro.SerieDocumentoHastaDia1Contingencia.ToString();
                }
                
                if (registro.SerieCajaCursoDia1Retorno > 0)
                {
                    txtSerieCajaCursoRetornoDia1.Value = registro.SerieCajaCursoDia1Retorno.ToString();
                }
                
                if (registro.SerieCajaCursoDia2Contingencia > 0)
                {
                    txtSerieCajaCursoDia2.Value = registro.SerieCajaCursoDia2Contingencia.ToString();
                }
                
                if (registro.SerieDocumentoDesdeDia2Contingencia > 0)
                {
                    txtSerieDesdeDia2.Value = registro.SerieDocumentoDesdeDia2Contingencia.ToString(); 
                }
                
                if (registro.SerieDocumentoHastaDia2Contingencia > 0)
                {
                    txtSerieHastaDia2.Value = registro.SerieDocumentoHastaDia2Contingencia.ToString();
                }
                
                if (registro.SerieCajaCursoDia2Retorno > 0)
                {
                    txtSerieCajaCursoRetornoDia2.Value = registro.SerieCajaCursoDia2Retorno.ToString();
                }
                
                if (registro.idContenedorDia1 > 0)
                {
                    hdIdContenedorDia1.Value = registro.idContenedorDia1.ToString();
                }
                if (registro.idContenedorDia2 > 0)
                {
                    hdIdContenedorDia2.Value = registro.idContenedorDia2.ToString();
                }

                ddlAplicoCensal.Items.Clear();
                ddlAplicoExp.Items.Clear();
                ddlSesionComplementaria.Items.Clear();
                CargarCombosAplicacion();
                if (registro.AplicoCensal == 0)
                {
                    ddlAplicoCensal.Items.FindByValue(registro.AplicoCensal.ToString()).Selected = true;
                }

                ddlAplicoExp.Items.FindByValue(registro.AplicoExperimental.ToString()).Selected = true;
                ddlSesionComplementaria.Items.FindByValue(registro.AplicoSesionComplementaria.ToString()).Selected = true;

                txtObservacion.Value = registro.Observacion;
                cargo = true;
            }

            btnGuardar.Disabled = false;
            btnLimpiar.Disabled = false;
            return cargo;
        }

        protected void btnGuardar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnGuardar_Click";
            bool guardo = false;
            try
            {
                IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
                int dia;
                int serieCajaCursoBusqueda;
                int serieDesde;
                int serieHasta;

                LimpiarControlesMensaje();
                if ((txtSerieCajaCursoDia1.Value == "0" && (txtSerieDesdeDia1.Value != "0" || txtSerieHastaDia1.Value != "0")) ||
                    (txtSerieCajaCursoDia1.Value == "" && (txtSerieDesdeDia1.Value != "" || txtSerieHastaDia1.Value != "")))
                {
                    lblMsgConsulta.InnerText = "La Serie Caja Curso para Día 1 No Corresponde";
                    lblMsgConsulta.Visible = true;
                    return;                
                }

                if ((txtSerieCajaCursoDia2.Value == "0" && (txtSerieDesdeDia2.Value != "0" || txtSerieHastaDia2.Value != "0")) ||
                    (txtSerieCajaCursoDia2.Value == "" && (txtSerieDesdeDia2.Value != "" || txtSerieHastaDia2.Value != "")))
                {
                    lblMsgConsulta.InnerText = "La Serie Caja Curso para Día 2 No Corresponde";
                    lblMsgConsulta.Visible = true;
                    return;
                }
                
                if (txtSerieCajaCursoDia1.Value != "" && txtSerieCajaCursoDia1.Value != "0")
                {
                    dia = 1;
                    serieCajaCursoBusqueda = Convert.ToInt32(txtSerieCajaCursoDia1.Value);
                    serieDesde = Convert.ToInt32(txtSerieDesdeDia1.Value);
                    serieHasta = Convert.ToInt32(txtSerieHastaDia1.Value);
                    DatosContenedorEN contenedor = BuscarDatosContenedor(dia, serieCajaCursoBusqueda);
                    if (contenedor.IdContenedor < 1)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe datos de cajas de contingencia para el día 1');", true);
                        lblMsgConsulta.InnerText = "La Serie Caja Curso para Día 1 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;                    
                    }
                    if (serieDesde < contenedor.SerieDocumentoDesde || serieDesde > contenedor.SerieDocumentoHasta)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('La serie desde para el día 1 no se encuentra en la caja');", true);
                        lblMsgConsulta.InnerText = "La Serie Desde para Día 1 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;                    
                    }
                    if (serieHasta > contenedor.SerieDocumentoHasta || serieHasta < contenedor.SerieDocumentoDesde || serieHasta < serieDesde)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('La serie hasta para el día 1 no se encuentra en la caja');", true);
                        lblMsgConsulta.InnerText = "La Serie Hasta para Día 1 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;                    
                    }                
                }
              
                if (txtSerieCajaCursoDia2.Value != "" && txtSerieCajaCursoDia2.Value != "0")
                {
                    dia = 2;
                    serieCajaCursoBusqueda = Convert.ToInt32(txtSerieCajaCursoDia2.Value);
                    serieDesde = Convert.ToInt32(txtSerieDesdeDia2.Value);
                    serieHasta = Convert.ToInt32(txtSerieHastaDia2.Value);
                    DatosContenedorEN contenedor = BuscarDatosContenedor(dia, serieCajaCursoBusqueda);
                    if (contenedor.IdContenedor < 1)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe datos de cajas de contingencia para el día 2');", true);
                        lblMsgConsulta.InnerText = "La Serie Caja Curso para Día 2 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;
                    }
                    if (serieDesde < contenedor.SerieDocumentoDesde || serieDesde > contenedor.SerieDocumentoHasta)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('La serie desde para el día 2 no se encuentra en la caja');", true);
                        lblMsgConsulta.InnerText = "La Serie Desde para Día 2 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;
                    }
                    if (serieHasta > contenedor.SerieDocumentoHasta || serieHasta < contenedor.SerieDocumentoDesde || serieHasta < serieDesde)
                    {
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('La serie hasta para el día 2 no se encuentra en la caja');", true);
                        lblMsgConsulta.InnerText = "La Serie Hasta para Día 2 No Corresponde";
                        lblMsgConsulta.Visible = true;
                        return;
                    }
                }

                RegistroAplicacionAulaEN registro = CargarDatosAplicacionAula();

                guardo = aplicacionAulaBLL.RegistrarAplicacionAula(registro);

                if (!guardo)
                {
                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No se guardaron los datos');", true);
                    lblMsgConsulta.InnerText = "No se guardaron los datos";
                    lblMsgConsulta.Visible = true;
                    return;
                }
                else
                {
                    LimpiarControles();                
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private DatosContenedorEN BuscarDatosContenedor(int dia, int serieCajaCurso)
        {
            DatosContenedorEN contenedor = new DatosContenedorEN();
            DatosContenedorEN contenedorEncontrado = new DatosContenedorEN();

            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();

            contenedor.IdNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            contenedor.IdTipoDistribucion = 2;
            contenedor.IdTipoMaterial = 3;
            contenedor.Dia = dia;
            contenedor.SerieCajaCurso = serieCajaCurso;

            contenedorEncontrado = aplicacionAulaBLL.BuscarDatosContenedor(contenedor);
            return contenedorEncontrado;        
        }

        private RegistroAplicacionAulaEN CargarDatosAplicacionAula()
        {
            RegistroAplicacionAulaEN registro = new RegistroAplicacionAulaEN();

            lblMsgConsulta.InnerText = "";
            lblMsgConsulta.Visible = false;

            if (hdIdAplicacionAula.Value != "")
            {
                registro.idAplicacionAula = Convert.ToInt32(hdIdAplicacionAula.Value.Trim());            
            }
            if (hdIdCurso.Value != "")
            {
                registro.idCurso = Convert.ToInt32(hdIdCurso.Value.Trim());            
            }

            registro.idNivel = Convert.ToInt32(ddlNivel.Items[ddlNivel.SelectedIndex].Value);
            registro.Nivel = ddlNivel.Items[ddlNivel.SelectedIndex].Text;

            registro.Rbd = Convert.ToInt32(txtRbd.Value.Trim());
            registro.DvRbd = txtDbrbd.Value.Trim();

            registro.LetraCurso = txtLetraCurso.Value.Trim().ToUpper();

            if (txtSerieCajaCurso.Value != "" && txtSerieCajaCurso.Value != "0")
            {
                registro.SerieCajaCurso = Convert.ToInt32(txtSerieCajaCurso.Value.Trim());            
            }

            if (txtCPEntregados.Value != "" && txtCPEntregados.Value != "0")
            {
                registro.CantidadCuestionariosPAEntregados = Convert.ToInt32(txtCPEntregados.Value.Trim());            
            }

            if (txtCPDevueltos.Value != "" && txtCPDevueltos.Value != "0")
            {
                registro.CantidadCuestionariosPARecibidos = Convert.ToInt32(txtCPDevueltos.Value.Trim());            
            }

            if (txtCDEntregados.Value != "" && txtCDEntregados.Value != "0")
            {
                registro.CantidadCuestionariosDocenteEntregados = Convert.ToInt32(txtCDEntregados.Value.Trim());            
            }

            if (txtCDDevueltos.Value != "" && txtCDDevueltos.Value != "0")
            {
                registro.CantidadCuestionariosDocenteRecibidos = Convert.ToInt32(txtCDDevueltos.Value.Trim());            
            }

            if (txtSerieCajaCursoDia1.Value != "" && txtSerieCajaCursoDia1.Value != "0")
            {
                registro.SerieCajaCursoDia1Contingencia = Convert.ToInt32(txtSerieCajaCursoDia1.Value.Trim());            
            }

            if (txtSerieDesdeDia1.Value != "" && txtSerieDesdeDia1.Value != "0")
            {
                registro.SerieDocumentoDesdeDia1Contingencia = Convert.ToInt32(txtSerieDesdeDia1.Value.Trim());            
            }

            if (txtSerieHastaDia1.Value != "" && txtSerieHastaDia1.Value != "0")
            {
                registro.SerieDocumentoHastaDia1Contingencia = Convert.ToInt32(txtSerieHastaDia1.Value.Trim());            
            }

            if (txtSerieCajaCursoRetornoDia1.Value != "" && txtSerieCajaCursoRetornoDia1.Value != "0")
            {
                registro.SerieCajaCursoDia1Retorno = Convert.ToInt32(txtSerieCajaCursoRetornoDia1.Value.Trim());            
            }

            if (txtSerieCajaCursoDia1.Value != "" && txtSerieCajaCursoDia1.Value != "0" && hdIdContenedorDia1.Value != "")
            {
                registro.idContenedorDia1 = Convert.ToInt32(hdIdContenedorDia1.Value.Trim());
            }

            if (txtSerieCajaCursoDia2.Value != "" && txtSerieCajaCursoDia2.Value != "0")
            {
                registro.SerieCajaCursoDia2Contingencia = Convert.ToInt32(txtSerieCajaCursoDia2.Value.Trim());            
            }

            if (txtSerieDesdeDia2.Value != "" && txtSerieDesdeDia2.Value != "0")
            {
                registro.SerieDocumentoDesdeDia2Contingencia = Convert.ToInt32(txtSerieDesdeDia2.Value.Trim());            
            }

            if (txtSerieHastaDia2.Value != "" && txtSerieHastaDia2.Value != "0")
            {
                registro.SerieDocumentoHastaDia2Contingencia = Convert.ToInt32(txtSerieHastaDia2.Value.Trim());            
            }

            if (txtSerieCajaCursoRetornoDia2.Value != "" && txtSerieCajaCursoRetornoDia2.Value != "0")
            {
                registro.SerieCajaCursoDia2Retorno = Convert.ToInt32(txtSerieCajaCursoRetornoDia2.Value.Trim());            
            }

            if (txtSerieCajaCursoDia2.Value != "" && txtSerieCajaCursoDia2.Value != "0" && hdIdContenedorDia2.Value != "")
            {
                registro.idContenedorDia2 = Convert.ToInt32(hdIdContenedorDia2.Value.Trim());
            }

            registro.AplicoExperimental = Convert.ToInt32(ddlAplicoExp.Items[ddlAplicoExp.SelectedIndex].Value);
            registro.AplicoCensal = Convert.ToInt32(ddlAplicoCensal.Items[ddlAplicoCensal.SelectedIndex].Value);
            registro.AplicoSesionComplementaria = Convert.ToInt32(ddlSesionComplementaria.Items[ddlSesionComplementaria.SelectedIndex].Value);
            registro.Observacion = txtObservacion.Value;
            return registro;
        }

        protected void btnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnLimpiar_Click";
            try
            {
                LimpiarControles();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void CargarCombos()
        {
            INivelBLL nivelBLL = new NivelBLL();
            List<NivelEN> listado = new List<NivelEN>();
            listado = nivelBLL.Listar();
            var item = listado.Single(x => x.Id == 0);
            listado.Remove(item);

            ddlNivel.DataSource = listado;
            ddlNivel.DataTextField = "Descripcion";
            ddlNivel.DataValueField = "Id";
            ddlNivel.DataBind();
        }

        private void CargarCombosAplicacion()
        {
            ddlAplicoExp.DataSource = null;
            ddlAplicoExp.DataBind();
            ddlAplicoCensal.DataSource = null;
            ddlAplicoCensal.DataBind();
            ddlSesionComplementaria.DataSource = null;
            ddlSesionComplementaria.DataBind();

            IAplicacionAulaBLL aplicacionAulaBLL = new AplicacionAulaBLL();
            ddlAplicoExp.DataSource = aplicacionAulaBLL.ListarAplicoExp();
            ddlAplicoExp.DataTextField = "Descripcion";
            ddlAplicoExp.DataValueField = "Id";
            ddlAplicoExp.DataBind();

            ddlAplicoCensal.DataSource = aplicacionAulaBLL.ListarAplicoCensal();
            ddlAplicoCensal.DataTextField = "Descripcion";
            ddlAplicoCensal.DataValueField = "Id";
            ddlAplicoCensal.DataBind();

            ddlSesionComplementaria.DataSource = aplicacionAulaBLL.ListarAplicoComplementaria();
            ddlSesionComplementaria.DataTextField = "Descripcion";
            ddlSesionComplementaria.DataValueField = "Id";
            ddlSesionComplementaria.DataBind();
        }

        private void LimpiarControles()
        {
            txtRbd.Value = "";
            txtDbrbd.Value = "";
            txtLetraCurso.Value = "";
            txtSerieCajaCurso.Value = "";
            LimpiarControlesConsulta();
            CargarCombos();
        }

        private void LimpiarControlesConsulta()
        {
            LimpiarControlesMensaje();
            hdIdCurso.Value = "";
            hdIdAplicacionAula.Value = "";
            hdIdNivel.Value = "";
            hdIdContenedorDia1.Value = "";
            hdIdContenedorDia2.Value = "";
            txtCPEntregados.Value = "";
            txtCPDevueltos.Value = "";
            txtCDEntregados.Value = "";
            txtCDDevueltos.Value = "";
            txtSerieCajaCursoDia1.Value = "";
            txtSerieDesdeDia1.Value = "";
            txtSerieHastaDia1.Value = "";
            txtSerieCajaCursoRetornoDia1.Value = "";
            txtSerieCajaCursoDia2.Value = "";
            txtSerieDesdeDia2.Value = "";
            txtSerieHastaDia2.Value = "";
            txtSerieCajaCursoRetornoDia2.Value = "";
            txtObservacion.Value = "";
            CargarCombosAplicacion();
            btnGuardar.Disabled = true;
            btnLimpiar.Disabled = true;
        }

        private void LimpiarControlesMensaje()
        {
            lblMsgConsulta.InnerText = "";
            lblMsgConsulta.Visible = false;
        }
    }
}