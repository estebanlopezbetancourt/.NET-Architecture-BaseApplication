﻿using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using TCS.Simce.Operaciones.EN.Logging;
using System.IO;
using System.Configuration;
using TCS.Simce.Operaciones.BLL.Almacenaje;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace Simce_Operaciones.Almacenaje
{
    public partial class _Default : Page
    {
        private static string CLASS = "ConsultarCaja";
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();

                    HD_PistoleoOManual.Value = RetornaFormaIngresoCodigos();

                    HD_PasoPorPalletTCS.Value = "false";
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnAsiganar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnAsiganar_Click";

            try
            {

                if (HD_PasoPorPalletTCS.Value == "false")
                {
                    if (HD_PistoleoOManual.Value == "1") //2=Ingreso Por Pistoleo, debe ingresar una vez el codigo - 1=Ingreso Manual, debe ingresar dos veces el codigo
                    {

                        if (HD_NumeroPallet.Value.Trim() == "")
                        {
                            HD_NumeroPallet.Value = TxtIdentificacionPalletsTCS.Text;
                            TxtIdentificacionPalletsTCS.Text = "";
                            TxtIdentificacionPalletsTCS.Focus();
                            return;
                        }
                        if (Convert.ToInt64(HD_NumeroPallet.Value) != long.Parse(TxtIdentificacionPalletsTCS.Text))
                        {
                            HD_NumeroPallet.Value = TxtIdentificacionPalletsTCS.Text;
                            TxtIdentificacionPalletsTCS.Text = "";
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto, favor intentelo nuevamente');", true);
                            TxtIdentificacionPalletsTCS.Focus();
                            return;
                        }
                    }
                    HD_PasoPorPalletTCS.Value = "true";
                    TxtUbicacionFisica.Focus();
                    return;
                }
                else
                {
                    //if (HD_PasoPorPalletTCS.Value == "true")
                    //{
                    //    TxtUbicacionFisica.Focus();
                    //    return;
                    //}
                    if (TxtUbicacionFisica.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Número de Guía de Despacho');", true);
                        TxtUbicacionFisica.Focus();
                        return;
                    }

                    if (HD_PistoleoOManual.Value == "1") //2=Ingreso Por Pistoleo, debe ingresar una vez el codigo - 1=Ingreso Manual, debe ingresar dos veces el codigo
                    {

                        if (HD_NumeroPallet.Value.Trim() == "")
                        {
                            HD_NumeroPallet.Value = TxtIdentificacionPalletsTCS.Text;
                            TxtIdentificacionPalletsTCS.Text = "";
                            TxtIdentificacionPalletsTCS.Focus();
                            return;
                        }
                        if (Convert.ToInt64(HD_NumeroPallet.Value) != long.Parse(TxtIdentificacionPalletsTCS.Text))
                        {
                            HD_NumeroPallet.Value = TxtIdentificacionPalletsTCS.Text;
                            TxtIdentificacionPalletsTCS.Text = "";
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto, favor intentelo nuevamente');", true);
                            TxtIdentificacionPalletsTCS.Focus();
                            return;
                        }
                    }
                }


                AlmacenajeEN almacenajeEN = new AlmacenajeEN();

                almacenajeEN.TipoAccion = Convert.ToInt16(DP_TipoAccion.Items[DP_TipoAccion.SelectedIndex].Value);
                almacenajeEN.NumeroPalletTCS = Convert.ToInt64(TxtIdentificacionPalletsTCS.Text);
                almacenajeEN.codigoUbicacion = TxtUbicacionFisica.Text;

                IAlmacenajeBLL almacenajeBLL = new AlmacenajeBLL();

                if (!almacenajeBLL.PalletBuscarSiExiste(almacenajeEN.NumeroPalletTCS))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Pallet no existe');", true);
                    return;
                }

                if (!almacenajeBLL.UbicacionBuscarSiExiste(almacenajeEN.codigoUbicacion))
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Ubicación no existe');", true);
                    return;
                }

                if (almacenajeEN.TipoAccion == 1)
                {
                    if (almacenajeBLL.UbicacionOcupada(almacenajeEN.codigoUbicacion))
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Ubicación ya esta ocupada');", true);
                        return;
                    }
                    LblDescripcion.Visible = false;
                }
                else
                {
                    LblDescripcion.Visible = true;
                    LblDescripcion.Text = "";
                }

                string descripcion = almacenajeBLL.Ingresar(almacenajeEN, User.Identity.Name);
                LblDescripcion.Text = descripcion;

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Ubicación asignada correctamente');", true);
                Limpiar();
                TxtIdentificacionPalletsTCS.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnLimpiar_Click";

            try
            {
                Limpiar();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void CargarCombos()
        {
            IAlmacenajeBLL almacenajeBLL = new AlmacenajeBLL();

            DP_TipoAccion.DataSource = almacenajeBLL.Listar();
            DP_TipoAccion.DataTextField = "descripcion";
            DP_TipoAccion.DataValueField = "codigo";
            DP_TipoAccion.DataBind();
        }

        private void Limpiar()
        {
            TxtIdentificacionPalletsTCS.Text = "";
            TxtUbicacionFisica.Text = "";
            HD_NumeroPallet.Value = "";
            HD_UbicacionFisica.Value = "";
            HD_PasoPorPalletTCS.Value = "false";
            LblDescripcion.Text = "";
        }

        protected string RetornaFormaIngresoCodigos()
        {
            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;
        }
    }
}