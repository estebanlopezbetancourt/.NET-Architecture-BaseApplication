﻿using System;
using System.Web.UI;
using TCS.Simce.Core.Logging;
using TCS.Simce.Operaciones.BLL.Almacenaje;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace Simce_Recepcion.Modulos.Almacenaje
{
    public partial class ConsultarCaja : System.Web.UI.Page
    {
        private static string CLASS = "ConsultarCaja";
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnConsultar_Click";

            try
            {

                long gs1 = Convert.ToInt64(txtGs1.Text);

                IConsultarCajaBLL ConsultarCajaBLL = new ConsultarCajaBLL();
                ConsultarCajaEN caja = ConsultarCajaBLL.ConsultarCajaLista(gs1);

                if (caja == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('GS1 No existe en Base Datos Simce');", true);

                    txtNivel.Text = "";
                    txtTipoPrueba.Text = "";
                    txtTipoEntidad.Text = "";
                    txtEntidad.Text = "";
                    txtEstado.Text = "";
                    txtPalletTcs.Text = "";
                    txtUbicacionFisica.Text = "";
                    txtRbd.Text = "";
                    txtEstablecimiento.Text = "";
                }
                else
                {

                    txtNivel.Text = caja.nivel;
                    txtTipoPrueba.Text = caja.tipoPrueba;
                    txtTipoEntidad.Text = caja.tipoEntidad;
                    txtEntidad.Text = caja.entidad;
                    txtEstado.Text = caja.estadoCaja;
                    txtPalletTcs.Text = caja.palletTcs;
                    txtUbicacionFisica.Text = caja.ubicacionFisica;
                    txtRbd.Text = caja.rbd;
                    txtEstablecimiento.Text = caja.establecimiento;
                }
            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }
    }
}