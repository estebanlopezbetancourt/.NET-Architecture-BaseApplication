﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;
using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.Almacenaje;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Recepcion.Modulos.Almacenaje
{
    public partial class ConsultarUbicacion : System.Web.UI.Page
    {
        private static string CLASS = "ConsultarUbicacion";
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }
        private void CargarCombos()
        {
            try
            {
                INivelBLL NivelBLL = new NivelBLL();
                DP_Nivel.DataSource = NivelBLL.Listar();
                DP_Nivel.DataTextField = "descripcion";
                DP_Nivel.DataValueField = "Id";
                DP_Nivel.DataBind();

                DP_Nivel.Items.RemoveAt(0);

                ITipoPruebaBLL TipoPruebaBLL = new TipoPruebaBLL();
                DP_TipoPrueba.DataSource = TipoPruebaBLL.Listar();
                DP_TipoPrueba.DataTextField = "descripcion";
                DP_TipoPrueba.DataValueField = "Id";
                DP_TipoPrueba.DataBind();

                DP_TipoPrueba.Items.RemoveAt(0);
            }
            catch (Exception ex)
            {
                LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                LblMsg.Visible = true;

                throw ex;
            }
        }

        //CARGAR GRILLA CON PAGINACION
        protected void BtnConsultaUbicacion_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnConsultaUbicacion_Click";

            try
            {
                this.LoadGridView();

                if (GrConsultarUbicacion.Rows.Count == 0)
                {
                    LblMsg.Text = "No existen datos para búsqueda seleccionada";
                    LblMsg.Visible = true;
                }
                else
                {
                    LblMsg.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void LoadGridView()
        {
            int Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            int TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);

            IConsultarUbicacionBLL ConsultarUbicacionBLL = new ConsultarUbicacionBLL();
            GrConsultarUbicacion.DataSource = ConsultarUbicacionBLL.ConsultarUbicacionLista(Nivel, TipoPrueba);
            GrConsultarUbicacion.DataBind();
        }

        protected void GrConsultarUbicacion_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            string METHOD = "GrConsultarUbicacion_PageIndexChanging";

            try
            {

                this.GrConsultarUbicacion.PageIndex = e.NewPageIndex;
                this.LoadGridView();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        //EXPORTACION A EXCEL
        protected void BtnExportar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnExportar_Click";

            try
            {
                DumpExcel();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void DumpExcel()
        {
            List<ConsultarUbicacionEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Consultar Almacenamiento" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.DP_Nivel.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Prueba", Valor = this.DP_TipoPrueba.SelectedItem.Text });


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("ConsultarAlmacenamiento_" + DateTime.Now.ToString("dd-MM-yyyy"));

                ws.Cells["A1"].LoadFromCollection(cabecera, false);
                //ws.Cells["A8"].LoadFromCollection(lista, true);
                ExcelHelper.LoadFromCollectionWithHeaders<ConsultarUbicacionEN>(ws.Cells["A6"], lista);

                //adding styles
                using (ExcelRange rng = ws.Cells["A1:K1"])
                {
                    rng.Merge = true;
                    rng.Style.Font.Bold = true;
                    rng.Style.Font.Size = 12;
                    rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=ConsultarAlmacenamiento_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }
        private List<ConsultarUbicacionEN> LoadLista()
        {
            List<ConsultarUbicacionEN> lista = new List<ConsultarUbicacionEN>();
            IConsultarUbicacionBLL consulta = new ConsultarUbicacionBLL();

            int TipoPrueba = 0;
            int Nivel = 0;

            Nivel = Convert.ToInt16(DP_Nivel.Items[DP_Nivel.SelectedIndex].Value);
            TipoPrueba = Convert.ToInt16(DP_TipoPrueba.Items[DP_TipoPrueba.SelectedIndex].Value);

            lista = consulta.ConsultarUbicacionLista(Nivel, TipoPrueba);
            return lista;
        }
    }
}