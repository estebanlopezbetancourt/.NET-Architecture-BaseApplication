﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Operaciones
{
    public partial class MovimientoCajasEnSubCentro : System.Web.UI.Page
    {
        private static string CLASS = "MovimientoCajas";

        int tipoMovimiento = 1;
        string CodigosPorPistoleoOManuales = string.Empty; //1=Pistoleo, 2=Manual
        
        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                
                if (!IsPostBack)
                {
                    CargarCombos();
                    Contexto_Visualizar("Buscar");
                    Contexto_Botones(1);

                    if (tipoMovimiento == 1)
                    {
                        DP_TipoMovimiento.SelectedIndex = 1;
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Origen";
                        LblEntidadOrigen.Text = "Entidad Origen";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Recepción";
                        LblEntidadDestino.Text = "Entidad Recepción";
                    }
                    if (tipoMovimiento == 2)
                    {
                        DP_TipoMovimiento.SelectedIndex = 2;
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Despacho";
                        LblEntidadOrigen.Text = "Entidad Despacho";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Destino";
                        LblEntidadDestino.Text = "Entidad Destino";
                    }
                }
                CodigosPorPistoleoOManuales = RetornaFormaIngresoCodigos();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadDespacho_SelectedIndexChanged";

            try
            {

                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void DP_TipoEntidadRecepcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadRecepcion_SelectedIndexChanged";

            try
            {
                IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

                DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
                DP_EntidadRecepcion.DataTextField = "descripcion";
                DP_EntidadRecepcion.DataValueField = "codigo";
                DP_EntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscarDocumentoDespacho_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscarDocumentoDespacho_Click";
            int origenGuiaDespacho = 0;

            try
            {
                
                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtNumGuiaDespacho.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de guia');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroGuiaDespacho.Value.Trim() == "")
                    {
                        HDNumeroGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroGuiaDespacho.Value) != long.Parse(TxtNumGuiaDespacho.Text))
                    {
                        HDNumeroGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }

                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();
                //Busca Guia generada en CO Principal
                //guiaDespachoEN = guiaDespachoBLL.Buscar(Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value), 2, Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));
                
                //if (guiaDespachoEN == null)
                //{
                    //Busca Guia generada en Sub Centro
                    guiaDespachoEN = guiaDespachoBLL.Buscar(Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value), Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value), Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));
                
                    if (guiaDespachoEN == null)
                    {
                        Contexto_Visualizar("Ingresar");
                        TxtTotalPalletsEsperado.Text = "";
                        TxtTotalCajasCapacitacionEsperado.Text = "";
                        TxtTotalCajasComplementarioEsperado.Text = "";
                        TxtTotalCajasCursoEsperado.Text = "";
                        TxtTotalCajasPetosEsperado.Text = "";
                        TxtTotalCajasEsperado.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe Guía de Despacho');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                    else
                    {
                        origenGuiaDespacho = 1; //1: Guia desde Sub Centro
                    }
                //}
                //else
                //{
                //    origenGuiaDespacho = 2; //2: Guia desde CO Principal
                //}
                
                HDIdGuiaDespacho.Value = guiaDespachoEN.idMCR.ToString();
                TxtTotalPalletsEsperado.Text = guiaDespachoEN.totalPallets.ToString();
                TxtTotalCajasCapacitacionEsperado.Text = guiaDespachoEN.totalContenedorCapacitacion.ToString();
                TxtTotalCajasComplementarioEsperado.Text = guiaDespachoEN.totalContenedorComplementario.ToString();
                TxtTotalCajasCursoEsperado.Text = guiaDespachoEN.totalContenedorCajasCurso.ToString();
                TxtTotalCajasPetosEsperado.Text = guiaDespachoEN.totalContenedorPetos.ToString();
                TxtTotalCajasEsperado.Text = guiaDespachoEN.totalContenedor.ToString();

                LblEstadoGuiaDespacho.Text = guiaDespachoEN.desripcionEstadoGuiaDespacho;
                HDEstadoGuiaDespacho.Value = guiaDespachoEN.estadoGuiaDespacho.ToString();

                CalcularTotales();

                if (origenGuiaDespacho == 1) //Guia desde Sub Centro, ingresada de forma manual, debe validar si esta cuadrada
                {
                    if (guiaDespachoEN.estadoGuiaDespacho == 2) //Si el documento esta descuadrado (estado = 2) no se puede modificar
                    {
                        Contexto_Botones(6);
                        TxtIdentificadorCaja.Enabled = false;
                        DP_TipoMaterial.Enabled = false;
                    }
                    else
                    {
                        Contexto_Botones(2);
                        TxtIdentificadorCaja.Enabled = true;
                        DP_TipoMaterial.Enabled = true;
                        CalcularTotales();
                    }
                }
                else if (origenGuiaDespacho == 2) //Guia desde CO Principal, no importa si esta cuadrada
                {
                    Contexto_Botones(2);
                    TxtIdentificadorCaja.Enabled = true;
                    DP_TipoMaterial.Enabled = true;
                    CalcularTotales();
                }
                TxtIdentificadorPallet.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscarPallet_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscarPallet_Click";

            try
            {

                if (HDIdGuiaDespacho.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar numero de Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorPallet.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de pallet');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroPallet.Value.Trim() == "")
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroPallet.Value) != long.Parse(TxtIdentificadorPallet.Text))
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet incorrecto');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }

                int tipoEntidadCustodia = Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value);
                int entidadCustodia = Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value);

                PalletEN palletEN = new PalletEN();

                IPalletBLL palletBLL = new PalletBLL();

                //Pallet generado en CO Principal
                palletEN = palletBLL.BuscarParaDespacho(Convert.ToInt64(TxtIdentificadorPallet.Text), Convert.ToInt16(HDIdGuiaDespacho.Value));
                if (palletEN == null)
                {
                    palletEN = palletBLL.Buscar(Convert.ToInt64(TxtIdentificadorPallet.Text), Convert.ToInt16(HDIdGuiaDespacho.Value), tipoEntidadCustodia, entidadCustodia, User.Identity.Name, 1, 1);
                }
                
                if (palletEN == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet no existe para esta guía de despacho');", true);
                    TxtIdentificadorPallet.Focus();
                    return;
                }

                HDIdPallet.Value = palletEN.idPallet.ToString();

                CargarMovimientosContenedoresDetalle();
                DP_TipoMaterial.Enabled = true;
                DP_TipoMaterial.Focus();

                CalcularTotales();
                Contexto_Botones(3);
                
                TxtIdentificadorCaja.Enabled = true;                

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnGuardarCaja_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGuardarCaja_Click";

            try
            {
                if (HDIdPallet.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar numero de Pallet');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (TxtIdentificadorCaja.Text.Length < 9)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no debe ser menor a 9 dígitos');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorCaja.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de caja');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroCaja.Value.Trim() == "")
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroCaja.Value) != long.Parse(TxtIdentificadorCaja.Text))
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja incorrecto');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }

                int tipoMaterial = Convert.ToInt32(DP_TipoMaterial.SelectedItem.Value);
                int codTipoMaterial = Convert.ToInt32(TxtIdentificadorCaja.Text.Substring(0, 1));

                switch (tipoMaterial){
                    case 2: //Complementario
                        if (codTipoMaterial != 3 && codTipoMaterial != 4)
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no corresponde al tipo de material seleccionado');", true);
                            TxtIdentificadorCaja.Focus();
                            return;
                        }
                        break;
                    case 3: //Caja curso
                        if (codTipoMaterial != 1 && codTipoMaterial != 2)
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no corresponde al tipo de material seleccionado');", true);
                            TxtIdentificadorCaja.Focus();
                            return;
                        }
                        break;
                }
                    
                GuardarCaja();

                CalcularTotales();
                HabilitaBotonesPorTipoMaterial(Convert.ToInt16(DP_TipoMaterial.Items[DP_TipoMaterial.SelectedIndex].Value));
                TxtIdentificadorCaja.Text = "";
                HDNumeroCaja.Value = "";
                HDNumeroPallet.Value = "";
                TxtIdentificadorCaja.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnFinalizarPallet_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnFinalizarPallet_Click";

            try
            {
                IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
                movimientoContenedorDetalleBLL.FinalizarPallet(Convert.ToInt16(HDIdPallet.Value), User.Identity.Name);

                TxtIdentificadorPallet.Text = "";
                TxtContadorCajasPorPallet.Text = "";
                TxtIdentificadorCaja.Text = "";
                HDNumeroGuiaDespacho.Value = "";
                HDNumeroCaja.Value = "";
                HDNumeroPallet.Value = "";
                HDIdPallet.Value = "";

                DP_TipoMaterial.ClearSelection();
                GrMovimientoCajas.DataBind();
                Contexto_Botones(2);
                CalcularTotales();
                TxtIdentificadorPallet.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnFinalizarMovimientoCajas_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnFinalizarMovimientoCajas_Click";

            try
            {
                if (Convert.ToInt16(HDTotalDiferenciasCuadratura.Value) > 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Documento de despacho no está cuadrado, imposible finalizar movimiento de cajas');", true);
                    return;
                }

                int idGuiaDespacho = Convert.ToInt16(HDIdGuiaDespacho.Value);
                IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
                movimientoContenedorDetalleBLL.FinalizarGuiaDespacho(idGuiaDespacho, User.Identity.Name);

                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();

                //Busca Guia generada en CO Principal
                guiaDespachoEN = guiaDespachoBLL.Buscar(Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value), 2, Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));

                if (guiaDespachoEN == null)
                {
                    //Busca Guia generada en Sub Centro
                    guiaDespachoEN = guiaDespachoBLL.Buscar(Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value), Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value), Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));
                }

                LblEstadoGuiaDespacho.Text = guiaDespachoEN.desripcionEstadoGuiaDespacho;

                if (guiaDespachoEN.estadoGuiaDespacho == 2) //Si el documento esta descuadrado (estado = 2) no se puede modificar
                {
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    TxtIdentificadorCaja.Enabled = false;
                    DP_TipoMaterial.Enabled = false;
                }
                else
                {
                    BtnGuardarCaja.Enabled = true;
                    BtnFinalizarPallet.Enabled = true;
                    BtnFinalizarMovimientoCajas.Enabled = true;
                    TxtIdentificadorCaja.Enabled = true;
                    DP_TipoMaterial.Enabled = true;
                }


                TxtNumGuiaDespacho.Text = "";
                TxtIdentificadorPallet.Text = "";
                TxtContadorCajasPorPallet.Text = "";
                TxtIdentificadorCaja.Text = "";
                DP_TipoMaterial.ClearSelection();
                GrMovimientoCajas.DataBind();
                HDNumeroGuiaDespacho.Value = "";
                LimpiarCuadratura();

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void GrMovimientoCajas_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            string METHOD = "GrMovimientoCajas_RowDeleting";

            try
            {

                if (Convert.ToInt16(HDEstadoGuiaDespacho.Value) == 2) //Guia cuadrada, no se pueden eliminar cajas
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Guía de Despacho cuadrada, no se puede eliminar cajas');", true);
                    return;
                }

                GridView gv = (GridView)sender;
                int filaSeleccionada = e.RowIndex;
                string id = gv.Rows[filaSeleccionada].Cells[0].Text.ToString();

                IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
                movimientoContenedorDetalleBLL.QuitarCajaDePallet(Convert.ToInt16(id), User.Identity.Name);
                CargarMovimientosContenedoresDetalle();
                CalcularTotales();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoMaterial_SelectedIndexChanged";

            try
            {
                TxtIdentificadorCaja.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void GuardarCaja()
        {
            try
            {
                int idTipoMaterial = Convert.ToInt16(DP_TipoMaterial.Items[DP_TipoMaterial.SelectedIndex].Value);
                int idTipoEntidadCustodio = Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value);
                int idEntidadCustodio = Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value);

                ContenedorEN contenedorEN = new ContenedorEN();

                IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();

                contenedorEN = movimientoContenedorDetalleBLL.ContenedorActualizaRecepcionCaja(TxtIdentificadorCaja.Text, Convert.ToInt16(idTipoMaterial), Convert.ToInt16(HDIdPallet.Value), User.Identity.Name, idTipoEntidadCustodio, idEntidadCustodio);

                movimientoContenedorDetalleBLL.MovimientoContenedorActualizaRecepcionCajaSubCentro(Convert.ToInt16(HDIdGuiaDespacho.Value), contenedorEN.idContenedor, TxtIdentificadorCaja.Text, idTipoMaterial, Convert.ToInt16(HDIdPallet.Value), contenedorEN.estadoBDSimce, User.Identity.Name);

                CargarMovimientosContenedoresDetalle();

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void CargarCombos()
        {
            try
            {
                ITipoDocumentoBLL tipoDocumento = new TipoDocumentoBLL();

                DP_TipoDocumento.DataSource = tipoDocumento.Listar();
                DP_TipoDocumento.DataTextField = "Descripcion";
                DP_TipoDocumento.DataValueField = "Id";
                DP_TipoDocumento.DataBind();

                ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();

                DP_TipoMovimiento.DataSource = tipoMovimiento.Listar();
                DP_TipoMovimiento.DataTextField = "descripcion";
                DP_TipoMovimiento.DataValueField = "id";
                DP_TipoMovimiento.DataBind();
                //DP_TipoMovimiento

                ITipoEntidadDespachoBLL tipoDespacho = new TipoEntidadDespachoBLL();

                DP_TipoEntidadDespacho.DataSource = tipoDespacho.Listar();
                DP_TipoEntidadDespacho.DataTextField = "descripcion";
                DP_TipoEntidadDespacho.DataValueField = "id";
                DP_TipoEntidadDespacho.DataBind();
                DP_TipoEntidadDespacho.SelectedIndex = 1;
                
                ITipoEntidadRecepcionBLL tipoRecepcion = new TipoEntidadRecepcionBLL();

                DP_TipoEntidadRecepcion.DataSource = tipoRecepcion.Listar();
                DP_TipoEntidadRecepcion.DataTextField = "descripcion";
                DP_TipoEntidadRecepcion.DataValueField = "id";
                DP_TipoEntidadRecepcion.DataBind();
                DP_TipoEntidadRecepcion.SelectedIndex = 1;

                ITipoMaterialBLL tipoMaterial = new TipoMaterialBLL();

                DP_TipoMaterial.DataSource = tipoMaterial.Listar();
                DP_TipoMaterial.DataTextField = "descripcion";
                DP_TipoMaterial.DataValueField = "id";
                DP_TipoMaterial.DataBind();

                CargaComboDespacho();
                CargaComboRecepcion();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargaComboDespacho()
        {
            try
            {
                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargaComboRecepcion()
        {
            try
            {
                IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

                DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
                DP_EntidadRecepcion.DataTextField = "descripcion";
                DP_EntidadRecepcion.DataValueField = "codigo";
                DP_EntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void CargarMovimientosContenedoresDetalle()
        {
            try
            {
                IMovimientoContenedorDetalleBLL MovimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();

                GrMovimientoCajas.DataSource = MovimientoContenedorDetalleBLL.ListarPorIdPallet(Convert.ToInt16(HDIdPallet.Value));
                GrMovimientoCajas.DataBind();
                int cantidadFilas = GrMovimientoCajas.Rows.Count;
                TxtContadorCajasPorPallet.Text = cantidadFilas.ToString();

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void Contexto_Visualizar(string tipo_accion)
        {
            switch (tipo_accion)
            {
                case ContextoVisual.ACCION_BUSCAR: //Buscar, se carga al inicio de la página
                    //BtnBuscar.Enabled = true;
                    //BtnGuardar.Enabled = false;
                    //BtnModificar.Enabled = false;
                    //BtnLimpiar.Enabled = true;
                    HDAccion.Value = "buscar";
                    break;
                case ContextoVisual.ACCION_INGRESAR: //Si el registro no existe habilita opcion de guardar
                    //BtnBuscar.Enabled = true;
                    //BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = false;
                    //BtnLimpiar.Enabled = true;
                    HDAccion.Value = "guardar";
                    break;
                case ContextoVisual.ACCION_MODIFICAR: //Si el registro existe habilita opciones de guardar o eliminar
                    //BtnBuscar.Enabled = true;
                    //BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = true;
                    //BtnLimpiar.Enabled = true;
                    HDAccion.Value = "modificar";
                    break;
                default:                            // se pone en caso de que ningun case cumpla la evaluación
                    break;
            }
        }

        private void CalcularTotales()
        {
            long TotalCapacitacion = 0;
            long DiferenciaCapacitacion = 0;
            long TotalComplementario = 0;
            long DiferenciaComplementario = 0;
            long TotalCajasCurso = 0;
            long DiferenciaCajasCurso = 0;
            long TotalCajasPetos = 0;
            long DiferenciaCajasPetos = 0;
            long TotalPallet = 0;
            long DiferenciaPallet = 0;
            long DiferenciaTotalCajas = 0;

            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();

            List<TotalCuadratura> TotalCuadratura = movimientoContenedorDetalleBLL.RetornaTotalCuadratura(Convert.ToInt16(HDIdGuiaDespacho.Value));

            foreach (TotalCuadratura elemento in TotalCuadratura)
            {
                switch (elemento.idTipoMaterial)
                {
                    case 1:
                        TotalCapacitacion = elemento.Total;
                        break;

                    case 2:
                        TotalComplementario = elemento.Total;
                        break;

                    case 3:
                        TotalCajasCurso = elemento.Total;
                        break;

                    case 4:
                        TotalCajasPetos = elemento.Total;
                        break;
                }
            }

            //Total Pallet
            TotalPallet = movimientoContenedorDetalleBLL.RetornaCantidadPalletRecepcionados(Convert.ToInt16(HDIdGuiaDespacho.Value));
            TxtTotalPalletsRecepcionado.Text = TotalPallet.ToString();
            DiferenciaPallet = Convert.ToInt16(TxtTotalPalletsEsperado.Text) - TotalPallet;
            //TxtTotalPalletsDiferencia.Text = DiferenciaPallet.ToString();

            //Total Capacitacion
            TxtTotalCajasCapacitacionRecepcionado.Text = TotalCapacitacion.ToString();
            DiferenciaCapacitacion = Convert.ToInt16(TxtTotalCajasCapacitacionEsperado.Text) - TotalCapacitacion;
            TxtTotalCajasCapacitacionDiferencia.Text = DiferenciaCapacitacion.ToString();

            //Total Complementario
            TxtTotalCajasComplementarioRecepcionado.Text = TotalComplementario.ToString();
            DiferenciaComplementario = Convert.ToInt16(TxtTotalCajasComplementarioEsperado.Text) - TotalComplementario;
            TxtTotalCajasComplementarioDiferencia.Text = DiferenciaComplementario.ToString();

            //Total Cajas Curso
            TxtTotalCajasCursoRecepcionado.Text = TotalCajasCurso.ToString();
            DiferenciaCajasCurso = Convert.ToInt16(TxtTotalCajasCursoEsperado.Text) - TotalCajasCurso;
            TxtTotalCajasCursoDiferencia.Text = DiferenciaCajasCurso.ToString();

            //Total Petos
            TxtTotalCajasPetosRecepcionado.Text = TotalCajasPetos.ToString();
            DiferenciaCajasPetos = Convert.ToInt16(TxtTotalCajasPetosEsperado.Text) - TotalCajasPetos;
            TxtTotalCajasPetosDiferencia.Text = DiferenciaCajasPetos.ToString();

            HDTotalDiferenciasCuadratura.Value = Convert.ToString(DiferenciaCapacitacion + DiferenciaComplementario + DiferenciaCajasCurso + DiferenciaCajasPetos);

            //Total Cajas
            TxtTotalCajasRecepcionado.Text = Convert.ToString(TotalCapacitacion + TotalComplementario + TotalCajasCurso + TotalCajasPetos);
            DiferenciaTotalCajas = Convert.ToInt16(TxtTotalCajasEsperado.Text) - Convert.ToInt16(TxtTotalCajasRecepcionado.Text);
            TxtTotalCajasDiferencia.Text = DiferenciaTotalCajas.ToString();

            if (Convert.ToInt16(TxtTotalCajasDiferencia.Text) == 0)
            {
                Contexto_Botones(5);
            }
        }

        protected string RetornaFormaIngresoCodigos()
        {

            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;

        }

        private void LimpiarCuadratura()
        {
            //Total Pallet
            TxtTotalPalletsEsperado.Text = "";
            TxtTotalPalletsRecepcionado.Text = "";
            //TxtTotalPalletsDiferencia.Text = "";

            //Total Capacitacion
            TxtTotalCajasCapacitacionEsperado.Text = "";
            TxtTotalCajasCapacitacionRecepcionado.Text = "";
            TxtTotalCajasCapacitacionDiferencia.Text = "";

            //Total Complementario
            TxtTotalCajasComplementarioEsperado.Text = "";
            TxtTotalCajasComplementarioRecepcionado.Text = "";
            TxtTotalCajasComplementarioDiferencia.Text = "";

            //Total Cajas Curso
            TxtTotalCajasCursoEsperado.Text = "";
            TxtTotalCajasCursoRecepcionado.Text = "";
            TxtTotalCajasCursoDiferencia.Text = "";

            //Total Petos
            TxtTotalCajasPetosEsperado.Text = "";
            TxtTotalCajasPetosRecepcionado.Text = "";
            TxtTotalCajasPetosDiferencia.Text = "";

            //Total Cajas
            TxtTotalCajasEsperado.Text = "";
            TxtTotalCajasRecepcionado.Text = "";
            TxtTotalCajasDiferencia.Text = "";
        }

        private void Contexto_Botones(int caso)
        {
            switch (caso)
            {
                case 1: //Al inicio de la pagina
                    BtnBuscarDocumentoDespacho.Enabled = true;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    break;

                case 2: //Al buscar Pallet
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    break;

                case 3: //Al guardar caja
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = true;
                    BtnFinalizarPallet.Enabled = true;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    break;

                case 4:  //Al finalizar pallet
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = true;
                    BtnFinalizarPallet.Enabled = true;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    break;
                case 5:  //Al finalizar guia despacho
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarMovimientoCajas.Enabled = true;
                    break;
                case 6:  //Solo consulta pallet
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarMovimientoCajas.Enabled = false;
                    break;
            }
        }

        private void HabilitaBotonesPorTipoMaterial(int tipoMaterial)
        {
            switch (tipoMaterial)
            {
                case 2: //Complementario
                    if (Convert.ToInt16(TxtTotalCajasComplementarioDiferencia.Text) == 0)
                    {
                        Contexto_Botones(3);
                    }
                    break;

                case 3: //Caja curso
                    if (Convert.ToInt16(TxtTotalCajasCursoDiferencia.Text) == 0)
                    {
                        Contexto_Botones(3);
                    }
                    break;

                case 4:  //Petos
                    if (Convert.ToInt16(TxtTotalCajasPetosDiferencia.Text) == 0)
                    {
                        Contexto_Botones(3);
                    }
                    break;
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnLimpiar_Click";

            try
            {
                Contexto_Botones(1);
                TxtNumGuiaDespacho.Text = "";
                TxtIdentificadorPallet.Text = "";
                TxtIdentificadorCaja.Text = "";
                GrMovimientoCajas.DataBind();
                LimpiarCuadratura();
                HDEstadoGuiaDespacho.Value = "";
                HDIdGuiaDespacho.Value = "";
                HDIdPallet.Value = "";
                HDNumeroCaja.Value = "";
                HDNumeroGuiaDespacho.Value = "";
                HDNumeroPallet.Value = "";
                HDTotalDiferenciasCuadratura.Value = "";
                DP_TipoMaterial.Enabled = true;
                TxtIdentificadorCaja.Enabled = true;
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }
    }
}