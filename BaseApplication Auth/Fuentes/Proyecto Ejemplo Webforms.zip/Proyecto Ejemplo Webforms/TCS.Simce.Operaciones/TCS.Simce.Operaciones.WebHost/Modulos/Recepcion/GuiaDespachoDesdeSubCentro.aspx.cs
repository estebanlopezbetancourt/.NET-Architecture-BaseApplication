﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web;
using System.Web.UI;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.BLL.Usuario;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Usuario;

namespace Simce_Operaciones.Recepcion
{
    public partial class GuiaDespachoDesdeSubCentro : Page
    {
        private static string CLASS = "GuiaDespacho";

        int tipoMovimiento = 2;
        string CodigosPorPistoleoOManuales = string.Empty; //1=Pistoleo, 2=Manual

        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    Limpiar();

                    CargarCombos();
                    Contexto_Visualizar("Buscar");
                    if (!CargarUsuario())
                    {
                        Context.GetOwinContext().Authentication.SignOut();
                        Response.Redirect("~\\Account\\Login.aspx");
                    }

                    if (tipoMovimiento == 1)
                    {
                        //DP_TipoMovimiento.SelectedValue = "1";
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Origen";
                        LblEntidadOrigen.Text = "Entidad Origen";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Recepción";
                        LblEntidadDestino.Text = "Entidad Recepción";
                    }
                    if (tipoMovimiento == 2)
                    {
                        //DP_TipoMovimiento.SelectedValue = "2";
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Despacho";
                        LblEntidadOrigen.Text = "Entidad Despacho";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Destino";
                        LblEntidadDestino.Text = "Entidad Destino";
                    }
                }
                CodigosPorPistoleoOManuales = RetornaFormaIngresoCodigos();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoMovimiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoMovimiento_SelectedIndexChanged";

            try
            {
                EntornoTipoMovimiento(Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value));
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadDespacho_SelectedIndexChanged";

            try
            {
                CargaComboDespacho();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoEntidadRecepcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadRecepcion_SelectedIndexChanged";

            try
            {
                CargaComboRecepcion();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGuardar_Click";

            try
            {

                if (TxtNumGuiaDespacho.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Número de Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (TxtTotalPallets.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Pallets');", true);
                    TxtTotalPallets.Focus();
                    return;
                }

                if (TxtTotalContenedorComplementario.Text.Trim() == "" && TxtTotalContenedorCajasCurso.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Contenedor Complementario o Total Contenedor CajasCurso');", true);
                    TxtTotalContenedorComplementario.Focus();
                    return;
                }
                                
                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                guiaDespachoEN.fechaMovimientoMCR = DateTime.Now;
                
                guiaDespachoEN.tipoDocumentoDespacho = Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value);
                guiaDespachoEN.numeroGuiaDespacho = Convert.ToInt64(TxtNumGuiaDespacho.Text);
                guiaDespachoEN.totalPallets = Convert.ToInt16(TxtTotalPallets.Text);
                guiaDespachoEN.totalContenedorCapacitacion = Convert.ToInt16(TxtTotalContenedorCapacitacion.Text);
                if (TxtTotalContenedorComplementario.Text.Trim() == "")
                {
                    guiaDespachoEN.totalContenedorComplementario = 0;
                    TxtTotalContenedorComplementario.Text = "0";
                }
                else
                {
                    guiaDespachoEN.totalContenedorComplementario = Convert.ToInt16(TxtTotalContenedorComplementario.Text);
                }
                
                if (TxtTotalContenedorCajasCurso.Text.Trim() == "")
                {
                    guiaDespachoEN.totalContenedorCajasCurso = 0;
                    TxtTotalContenedorCajasCurso.Text = "0";
                }
                else
                {
                    guiaDespachoEN.totalContenedorCajasCurso = Convert.ToInt16(TxtTotalContenedorCajasCurso.Text);
                }
                
                guiaDespachoEN.totalContenedorPetos = Convert.ToInt16(TxtTotalContenedorPetos.Text);
                guiaDespachoEN.tipoMovimiento = Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value);
                guiaDespachoEN.totalContenedor = CalculaTotalCajas();
                guiaDespachoEN.RutUsuarioMovimiento = Convert.ToInt64(TxtRutRecepcionista_Despachador.Text.Trim());
                guiaDespachoEN.dvRutUsuarioMovimiento = TxtDvRecepcionista_Despachador.Text;
                guiaDespachoEN.NombreUsuarioMovimiento = TxtNombreRecepcionista_Despachador.Text.Trim();
                guiaDespachoEN.tipoEntidadOrigen = Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value);
                guiaDespachoEN.idEntidadOrigen = Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value);
                guiaDespachoEN.tipoEntidadDestino = Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value);
                guiaDespachoEN.IdEntidadDestino = Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value);
                guiaDespachoEN.estadoGuiaDespacho = 0;
                guiaDespachoEN.idUsuarioCreacionRegistro = User.Identity.Name;

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();

                if (HDAccion.Value == "guardar")
                {
                    guiaDespachoBLL.Ingresar(guiaDespachoEN);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Guía de despacho ingresada correctamente');", true);
                }
                if (HDAccion.Value == "modificar")
                {
                    guiaDespachoEN.idMCR = Convert.ToInt64(HDIdGuiaDespacho.Value);
                    guiaDespachoBLL.Modificar(guiaDespachoEN);
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Guía de despacho modificada correctamente');", true);
                }
                
                Limpiar();
                TxtNumGuiaDespacho.Text = "";
                TxtNumGuiaDespacho.Focus();

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscar_Click";

            try
            {
                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtNumGuiaDespacho.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe adigitar numero de guia');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNGuiaDespacho.Value.Trim() == "")
                    {
                        HDNGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNGuiaDespacho.Value) != long.Parse(TxtNumGuiaDespacho.Text))
                    {
                        HDNGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto, favor intentelo nuevamente');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }

                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();
                
                guiaDespachoEN = guiaDespachoBLL.Buscar(Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value), Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value), Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));
                

                if (guiaDespachoEN == null)
                {
                    Limpiar();
                    Contexto_Visualizar("Ingresar");
                    CargarUsuario();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe Guía de Despacho');", true);
                    return;
                }

                HDIdGuiaDespacho.Value = guiaDespachoEN.idMCR.ToString();
                TxtTotalPallets.Text = guiaDespachoEN.totalPallets.ToString();
                TxtTotalContenedorCapacitacion.Text = guiaDespachoEN.totalContenedorCapacitacion.ToString();
                TxtTotalContenedorComplementario.Text = guiaDespachoEN.totalContenedorComplementario.ToString();
                TxtTotalContenedorCajasCurso.Text = guiaDespachoEN.totalContenedorCajasCurso.ToString();
                TxtTotalContenedorPetos.Text = guiaDespachoEN.totalContenedorPetos.ToString();

                TxtTotalContenedor.Text = guiaDespachoEN.totalContenedor.ToString();
                TxtRutRecepcionista_Despachador.Text = guiaDespachoEN.RutUsuarioMovimiento.ToString();
                TxtDvRecepcionista_Despachador.Text = guiaDespachoEN.dvRutUsuarioMovimiento;
                TxtNombreRecepcionista_Despachador.Text = guiaDespachoEN.NombreUsuarioMovimiento;

                LblEstadoGuiaDespacho.Text = guiaDespachoEN.desripcionEstadoGuiaDespacho;

                //if (guiaDespachoEN.estadoGuiaDespacho == 2) //Si el documento esta descuadrado (estado = 2) no se puede modificar
                //{
                //    Contexto_Visualizar("Buscar");
                //}
                //else
                //{
                    Contexto_Visualizar("Modificar");
                //}
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnLimpiar_Click";

            try
            {
                Limpiar();
                TxtNumGuiaDespacho.Text = "";
                TxtNumGuiaDespacho.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void CargarCombos()
        {
            ITipoDocumentoBLL tipoDocumento = new TipoDocumentoBLL();

            DP_TipoDocumento.DataSource = tipoDocumento.Listar();
            DP_TipoDocumento.DataTextField = "Descripcion";
            DP_TipoDocumento.DataValueField = "Id";
            DP_TipoDocumento.DataBind();

            ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();

            DP_TipoMovimiento.DataSource = tipoMovimiento.Listar();
            DP_TipoMovimiento.DataTextField = "descripcion";
            DP_TipoMovimiento.DataValueField = "id";
            DP_TipoMovimiento.DataBind();
            DP_TipoMovimiento.SelectedValue = "1";

            ITipoEntidadDespachoBLL tipoDespacho = new TipoEntidadDespachoBLL();

            DP_TipoEntidadDespacho.DataSource = tipoDespacho.Listar();
            DP_TipoEntidadDespacho.DataTextField = "descripcion";
            DP_TipoEntidadDespacho.DataValueField = "id";
            DP_TipoEntidadDespacho.DataBind();
            DP_TipoEntidadDespacho.SelectedValue = "3";

            ITipoEntidadRecepcionBLL tipoRecepcion = new TipoEntidadRecepcionBLL();

            DP_TipoEntidadRecepcion.DataSource = tipoRecepcion.Listar();
            DP_TipoEntidadRecepcion.DataTextField = "descripcion";
            DP_TipoEntidadRecepcion.DataValueField = "id";
            DP_TipoEntidadRecepcion.DataBind();
            DP_TipoEntidadRecepcion.SelectedValue = "2";

            CargaComboDespacho();
            CargaComboRecepcion();
        }

        private void CargaComboDespacho()
        {
            IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

            DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
            DP_EntidadDespacho.DataTextField = "descripcion";
            DP_EntidadDespacho.DataValueField = "codigo";
            DP_EntidadDespacho.DataBind();
        }

        private void CargaComboRecepcion()
        {
            IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

            DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
            DP_EntidadRecepcion.DataTextField = "descripcion";
            DP_EntidadRecepcion.DataValueField = "codigo";
            DP_EntidadRecepcion.DataBind();
           
        }

        private void EntornoTipoMovimiento(int tipo)
        {
            switch (tipo)
            {
                case 1: //Recepcion
                    DP_TipoEntidadDespacho.Enabled = true;
                    DP_EntidadDespacho.Enabled = true;
                    DP_TipoEntidadRecepcion.Enabled = false;
                    DP_EntidadRecepcion.Enabled = false;
                    break;
                case 2: //Despacho
                    DP_TipoEntidadDespacho.Enabled = false;
                    DP_EntidadDespacho.Enabled = false;
                    DP_TipoEntidadRecepcion.Enabled = true;
                    DP_EntidadRecepcion.Enabled = true;
                    break;
                default:
                    DP_TipoEntidadDespacho.Enabled = true;
                    DP_EntidadDespacho.Enabled = true;
                    DP_TipoEntidadRecepcion.Enabled = true;
                    DP_EntidadRecepcion.Enabled = true;

                    DP_TipoEntidadRecepcion.ClearSelection();
                    DP_EntidadRecepcion.ClearSelection();
                    DP_TipoEntidadDespacho.ClearSelection();
                    DP_EntidadDespacho.ClearSelection();
                    break;
            }
        }

        private void Contexto_Visualizar(string tipo_accion)
        {
            switch (tipo_accion)
            {
                case ContextoVisual.ACCION_BUSCAR: //Buscar, se carga al inicio de la página
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = false;
                    //BtnModificar.Enabled = false;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "buscar";
                    break;
                case ContextoVisual.ACCION_INGRESAR: //Si el registro no existe habilita opcion de guardar
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = false;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "guardar";
                    break;
                case ContextoVisual.ACCION_MODIFICAR: //Si el registro existe habilita opciones de guardar o eliminar
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = true;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "modificar";
                    break;
                default:                            // se pone en caso de que ningun case cumpla la evaluación
                    break;
            }
        }

        private int CalculaTotalCajas()
        {
            int TotalCajas = 0;

            TotalCajas = Convert.ToInt16(TxtTotalContenedorCajasCurso.Text) + Convert.ToInt16(TxtTotalContenedorCapacitacion.Text) + Convert.ToInt16(TxtTotalContenedorComplementario.Text) + Convert.ToInt16(TxtTotalContenedorPetos.Text);

            return TotalCajas;
        }

        private void Limpiar()
        {
            TxtTotalPallets.Text = "";
            TxtTotalContenedorCapacitacion.Text = "0";
            TxtTotalContenedorComplementario.Text = "";
            TxtTotalContenedorCajasCurso.Text = "";
            TxtTotalContenedorPetos.Text = "0";
            TxtTotalContenedorCapacitacion.Enabled = false;
            TxtTotalContenedorPetos.Enabled = false;

            TxtTotalContenedor.Text = "";
            LblEstadoGuiaDespacho.Text = "";
            HDAccion.Value = "";
            HDIdGuiaDespacho.Value = "";
            HDNGuiaDespacho.Value = "";
            Contexto_Visualizar("Buscar");
        }

        private Boolean CargarUsuario()
        {
            UsuarioEN usuarioEN = new UsuarioEN();
            IUsuarioBLL usuarioBLL = new UsuarioBLL();

            usuarioEN = usuarioBLL.Buscar(User.Identity.Name);

            if (usuarioEN == null)
            {
                Session["ErrorLogin"] = "Usuario no configurado en sistema";
                return false;
            }

            TxtRutRecepcionista_Despachador.Text = usuarioEN.RutUsuario;
            TxtDvRecepcionista_Despachador.Text = usuarioEN.DvUsuario;
            TxtNombreRecepcionista_Despachador.Text = usuarioEN.NombreUsuario;

            return true;
        }

        protected string RetornaFormaIngresoCodigos()
        {
            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;
        }

        protected string RetornaRutaArchivo()
        {
            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(2);
            return FormaIngresoCodigos;
        }
    }
}