﻿
namespace Simce_Operaciones
{
    public class ContextoVisual
    {
        public const string ACCION_BUSCAR = "Buscar";
        public const string ACCION_LEER = "Leer";
        public const string ACCION_INGRESAR = "Ingresar";
        public const string ACCION_MODIFICAR = "Modificar";
        public const string ACCION_ELIMINAR = "Eliminar";
        public const string ACCION_LIMPIAR = "Limpiar";
        public const string ACCION_EDITAR_GRILLA = "Editar Grilla";
    }
}