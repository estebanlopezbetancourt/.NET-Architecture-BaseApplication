﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
using Simce_Recepcion.Util;
using System;
using System.Collections.Generic;
using System.Linq;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Recepcion.Modulos.Picking
{
    public partial class OrdenPreparado : System.Web.UI.Page
    {
        private static string CLASS = "OrdenPreparado";
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                InicializarControles(false);
                CargarCombos();
            }
        }

        private void CargarCombos()
        {
            ISubCentroBLL SubCentroBLL = new SubCentroBLL();

            ddlSubCentroDestino.DataSource = SubCentroBLL.Listar();
            ddlSubCentroDestino.DataTextField = "descripcion";
            ddlSubCentroDestino.DataValueField = "Id";
            ddlSubCentroDestino.DataBind();

            ITipoMaterialBLL TipoMaterialBLL = new TipoMaterialBLL();
            ddlTipoMaterial.DataSource = TipoMaterialBLL.Listar();
            ddlTipoMaterial.DataTextField = "descripcion";
            ddlTipoMaterial.DataValueField = "Id";
            ddlTipoMaterial.DataBind();

            INivelBLL NivelBLL = new NivelBLL();
            ddlNivel.DataSource = NivelBLL.Listar();
            ddlNivel.DataTextField = "Descripcion";
            ddlNivel.DataValueField = "Id";
            ddlNivel.DataBind();
        }

        protected void btnConsultar_Click(object sender, EventArgs e)
        {
            string METHOD = "btnConsultar_Click";

            try
            {

                hdnMessage.Value = string.Empty;
                IList<ContenedorEN> listaContenedor = this.LoadLista();

                gvContenedor.DataSource = listaContenedor;
                gvContenedor.DataBind();

                InicializarControles(listaContenedor != null);
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnEnviarAPreparar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnEnviarAPreparar_Click";

            try
            {
                hdnMessage.Value = string.Empty;
                string strMessage = string.Empty;
                int NumeroOrden = -1;

                int IdSubCentroDestino = Convert.ToInt32(ddlSubCentroDestino.Text);
                int IdTipoMaterial = Convert.ToInt32(ddlTipoMaterial.Text);
                string RutUsuario = User.Identity.Name;
                int IdNivel = Convert.ToInt32(ddlNivel.SelectedItem.Value);

                NumeroOrden = new OrdenPreparadoBLL().EnviarAPreparar(IdSubCentroDestino, IdTipoMaterial, RutUsuario, IdNivel);

                if (NumeroOrden.Equals(-1))
                {
                    strMessage = "Error al generar Orden de Preparado.";
                }
                //else if (NumeroCorrelativo.Equals(-2))
                //{
                //    strMessage = "El Número Orden de Preparado ya existe en el sistema, por favor ingrese un Número Orden de Preparado distinto.";
                //}
                else
                {
                    txtNumeroOrdenPreparado.Text = NumeroOrden.ToString();

                    InicializarControles(false);
                    CargarCombos();

                    strMessage = "La Orden de Preparado ha sido generada exitosamente con el número " + NumeroOrden.ToString();
                }

                hdnMessage.Value = strMessage;

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }


        protected void btnExportarExcel_Click(object sender, EventArgs e)
        {
            string METHOD = "btnExportarExcel_Click";

            try
            {
                hdnMessage.Value = string.Empty;
                DumpExcel();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void DumpExcel()
        {
            IList<ContenedorEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            //creamos una lista solo con los campos que deben ir en el excel.
            IList<ContenedorENForExcel> lista_ = lista.Select(p => new ContenedorENForExcel()
            {
                identificacionContenedorGs1 = p.identificacionContenedorGs1,
                NivelDescripcion = p.NivelDescripcion,
                SubcentroDescripcion = p.SubcentroDescripcion,
                TipoMaterialDescripcion = p.TipoMaterialDescripcion,
                TipoPruebaDescripcion = p.TipoPruebaDescripcion,
                UbicacionDescripcion = p.UbicacionDescripcion
            }).ToList();

            cabecera.Add(new CabeceraEN() { Titulo = "Informe Orden de Preparado" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Número Orden de Preparado", Valor = this.txtNumeroOrdenPreparado.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Sub Centro Destino", Valor = this.ddlSubCentroDestino.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Tipo Material", Valor = this.ddlTipoMaterial.SelectedItem.Text });
            cabecera.Add(new CabeceraEN() { Titulo = "Nivel", Valor = this.ddlNivel.SelectedItem.Text });

            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("InformeOrdendePreparado_" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    ExcelHelper.LoadFromCollectionWithHeaders<ContenedorENForExcel>(ws.Cells["A8"], lista_);



                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:K1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 12;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=InformeOrdendePreparado_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }

        private IList<ContenedorEN> LoadLista()
        {
            int IdTipoMaterial = 0;
            int IdSubCentro = 0;
            int IdNivel = 0;

            IdTipoMaterial = Convert.ToInt32(ddlTipoMaterial.SelectedItem.Value);
            IdSubCentro = Convert.ToInt32(ddlSubCentroDestino.SelectedItem.Value);
            IdNivel = Convert.ToInt32(ddlNivel.SelectedItem.Value);

            return new OrdenPreparadoBLL().BuscarContenedor(IdTipoMaterial, IdSubCentro, IdNivel);
        }

        protected void ddlSubCentroDestino_SelectedIndexChanged(object sender, EventArgs e)
        {
            InicializarControles(false);
        }

        protected void ddlTipoMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            InicializarControles(false);
        }

        protected void ddlNivel_SelectedIndexChanged(object sender, EventArgs e)
        {
            InicializarControles(false);
        }

        protected void InicializarControles(bool enabled)
        {
            if (enabled)
            {
                txtNumeroOrdenPreparado.Enabled = true;
                btnEnviarAPreparar.Enabled = true;
                btnExportarExcel.Enabled = true;
            }
            else
            {
                btnEnviarAPreparar.Enabled = false;
                btnExportarExcel.Enabled = false;
                txtNumeroOrdenPreparado.Text = string.Empty;
                txtNumeroOrdenPreparado.Enabled = false;


                //inicializamos grilla para que se muestre vacia
                gvContenedor.DataSource = new List<string>();
                gvContenedor.DataBind();
            }
        }
    }
}