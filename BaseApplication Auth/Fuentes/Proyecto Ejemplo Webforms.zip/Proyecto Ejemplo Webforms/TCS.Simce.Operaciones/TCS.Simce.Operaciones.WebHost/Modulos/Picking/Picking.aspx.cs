﻿using System;
using System.Web.UI;
using TCS.Simce.Operaciones.BLL.Picking;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.Picking;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Operaciones.Picking
{
    public partial class Picking : System.Web.UI.Page
    {

        private static string CLASS = "Picking";
        
        string CodigosPorPistoleoOManuales = string.Empty; //1=Pistoleo, 2=Manual
        int totalPallet = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
             string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    Contexto_Botones(1);
                    HDTotalPallet.Value = "0";
                }
                CodigosPorPistoleoOManuales = RetornaFormaIngresoCodigos();
            }

            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                //Log.Instance.Write(ex.Message, LogLevel.Error);
                //LblMsg.Text = "Se ha producido un problema en la aplicación, favor contactarse con soporte TCS";
                //LblMsg.Visible = true;
            }
        }

        protected void BtnBuscarOrdenPreparado_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscarOrdenPreparado_Click";

            try
            {
                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtNumeroOrdenPreparado.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe adigitar numero de orden de preparado');", true);
                        TxtNumeroOrdenPreparado.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroOrdenPreparado.Value.Trim() == "")
                    {
                        HDNumeroOrdenPreparado.Value = TxtNumeroOrdenPreparado.Text;
                        TxtNumeroOrdenPreparado.Text = "";
                        TxtNumeroOrdenPreparado.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroOrdenPreparado.Value) != long.Parse(TxtNumeroOrdenPreparado.Text))
                    {
                        HDNumeroOrdenPreparado.Value = TxtNumeroOrdenPreparado.Text;
                        TxtNumeroOrdenPreparado.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de orden incorrecto, intentelo nuevamente');", true);
                        TxtNumeroOrdenPreparado.Focus();
                        return;
                    }
                }

                IPickingBLL pickingBLL = new PickingBLL();

                OrdenPreparadoEN ordenPreparadoEN = new OrdenPreparadoEN();

                ordenPreparadoEN = pickingBLL.OrdenPreparadoBuscar(Convert.ToInt64(TxtNumeroOrdenPreparado.Text));

                if (ordenPreparadoEN == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Orden de Preparado no existe');", true);
                    return;
                }
                HDIdOrdenPreparado.Value = ordenPreparadoEN.idMCR.ToString();

                CargarCajasOrdenProparado();

                TCS.Simce.Operaciones.EN.Picking.SubCentroEN SubCentro = new TCS.Simce.Operaciones.EN.Picking.SubCentroEN();
                SubCentro = pickingBLL.RetornaSubCentro(Convert.ToInt64(TxtNumeroOrdenPreparado.Text));

                TxtEntidadDestino.Text = SubCentro.SubCentro;
                HDIdSubCentro.Value = SubCentro.IdSubCentro.ToString();
                if (ordenPreparadoEN.estadoGuiaDespacho == 1)
                {
                    Contexto_Botones(2);
                }
                else
                {
                    Contexto_Botones(4);
                }

                TxtIdentificadorPallet.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscarPallet_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscarPallet_Click";

            try
            {
                if (HDIdOrdenPreparado.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar número de Orden de Preparado');", true);
                    Contexto_Botones(1);
                    TxtNumeroOrdenPreparado.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Por Pistoleo, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorPallet.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe adigitar numero de pallet');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }
                else //1=Ingreso Manual, debe ingresar dos veces el codigo
                {
                    if (HDNumeroPallet.Value.Trim() == "")
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroPallet.Value) != long.Parse(TxtIdentificadorPallet.Text))
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet incorrecto');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }

                int tipoEntidadCustodia = 2; //CO Principal
                int entidadCustodia = 1; //CO Pudahuel

                PalletEN palletEN = new PalletEN();

                IPalletBLL palletBLL = new PalletBLL();
                palletEN = palletBLL.Buscar(Convert.ToInt64(TxtIdentificadorPallet.Text), Convert.ToInt16(HDIdOrdenPreparado.Value), tipoEntidadCustodia, entidadCustodia, User.Identity.Name, 3, 4);

                if (palletEN == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe Pallet para esta Guía de Despacho');", true);
                    TxtIdentificadorPallet.Focus();
                }

                HDIdPallet.Value = palletEN.idPallet.ToString();
                
                Contexto_Botones(3);

                TxtIdentificadorCaja.Focus();

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnGuardarCaja_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGuardarCaja_Click";

            try
            {
                if (HDIdPallet.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar número de Pallet');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }

                if (TxtIdentificadorCaja.Text.Length < 9)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no debe ser menor a 9 dígitos');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorCaja.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de caja');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroCaja.Value.Trim() == "")
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroCaja.Value) != long.Parse(TxtIdentificadorCaja.Text))
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja incorrecto');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }

                IPickingBLL pickingBLL = new PickingBLL();
                
                Int64 idEstadoRecepcion = pickingBLL.PickingValidarCajasEnOrdenPreparado(Convert.ToInt64(HDIdOrdenPreparado.Value), Convert.ToInt64(TxtIdentificadorCaja.Text));

                if (idEstadoRecepcion == 0)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no corresponde a esta Orden de Preparado');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }
                else if (idEstadoRecepcion == 5)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Caja ya fue pistoleada');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }

                pickingBLL.AsignarPalletACaja(Convert.ToInt16(HDIdOrdenPreparado.Value), Convert.ToInt16(HDIdPallet.Value), Convert.ToInt64(TxtIdentificadorCaja.Text), User.Identity.Name);
            
                PickearCaja();
                CargarCajasOrdenProparado();

                TxtIdentificadorCaja.Text = "";
                HDNumeroCaja.Value = "";
                HDNumeroPallet.Value = "";
                TxtIdentificadorCaja.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
               
            }
        }

        protected void BtnFinalizarPallet_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnFinalizarPallet_Click";

            try
            {
                TxtIdentificadorPallet.Text = "";
                Contexto_Botones(5);
                TxtIdentificadorPallet.Focus();
            

                totalPallet = Convert.ToInt16(HDTotalPallet.Value);
            
                totalPallet++;

                HDTotalPallet.Value = totalPallet.ToString();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
               
            }
        }

        protected void BtnFinalizarOrden_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnFinalizarOrden_Click";

            try
            {

            if(GrCajasOrdenProparado.Rows.Count > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Imposible finalizar Orden, aún contiene cajas pendientes');", true);
                return;
            }
            
            IPickingBLL pickingBLL = new PickingBLL();
            pickingBLL.CerrarOrdenPreparado(Convert.ToInt16(HDIdOrdenPreparado.Value), Convert.ToInt16(HDTotalPallet.Value), User.Identity.Name);

            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Orden finalizada correctamente');", true);

            TxtIdentificadorPallet.Text = "";
            TxtIdentificadorCaja.Text = "";
            HDNumeroOrdenPreparado.Value = "";

            HDNumeroCaja.Value = "";
            HDNumeroPallet.Value = "";
            HDIdPallet.Value = "";
            GrCajasOrdenProparado.DataBind();
            Contexto_Botones(1);

            HDTotalPallet.Value = "0";
            TxtIdentificadorPallet.Focus();
         }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void PickearCaja()
        {
            try
            {
                IPickingBLL pickingBLL = new PickingBLL();
                pickingBLL.PickearCaja(Convert.ToInt16(HDIdOrdenPreparado.Value), Convert.ToInt64(TxtIdentificadorCaja.Text), User.Identity.Name);
                
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargarCajasOrdenProparado()
        {
            string METHOD = "CargarCajasOrdenProparado";

            try
            {
                IPickingBLL pickingBLL = new PickingBLL();

                GrCajasOrdenProparado.DataSource = pickingBLL.ListarOrdenPreparado(Convert.ToInt16(TxtNumeroOrdenPreparado.Text));
                GrCajasOrdenProparado.DataBind();
                int cantidadFilas = GrCajasOrdenProparado.Rows.Count;
                TxtTotalCajas.Text = cantidadFilas.ToString();

                if (cantidadFilas == 0)
                {
                    Contexto_Botones(4);
                }

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected string RetornaFormaIngresoCodigos()
        {

            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;

        }

        private void Contexto_Botones(int caso)
        {
            switch (caso)
            {
                case 1: //Al inicio de la pagina
                    BtnBuscarOrdenPreparado.Enabled = true;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarOrden.Enabled = false;
                    break;

                case 2: //Al buscar Pallet
                    BtnBuscarOrdenPreparado.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarOrden.Enabled = false;
                    break;

                case 3: //Al guardar caja
                    BtnBuscarOrdenPreparado.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = true;
                    BtnFinalizarPallet.Enabled = true;
                    BtnFinalizarOrden.Enabled = true;
                    break;

                case 4:  //Al finalizar orden
                    BtnBuscarOrdenPreparado.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = true;
                    BtnFinalizarOrden.Enabled = true;
                    break;
                case 5:  //Al finalizar pallet
                    BtnBuscarOrdenPreparado.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnFinalizarOrden.Enabled = true;
                    break;
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Contexto_Botones(1);
            TxtNumeroOrdenPreparado.Text = "";
            TxtIdentificadorPallet.Text = "";
            TxtIdentificadorCaja.Text = "";
            GrCajasOrdenProparado.DataBind();
            HDEstadoOrdenPreparado.Value = "";
            HDIdOrdenPreparado.Value = "";
            HDIdPallet.Value = "";
            HDNumeroCaja.Value = "";
            HDNumeroOrdenPreparado.Value = "";
            HDNumeroPallet.Value = "";
            TxtIdentificadorCaja.Enabled = true;
        }

    }
}