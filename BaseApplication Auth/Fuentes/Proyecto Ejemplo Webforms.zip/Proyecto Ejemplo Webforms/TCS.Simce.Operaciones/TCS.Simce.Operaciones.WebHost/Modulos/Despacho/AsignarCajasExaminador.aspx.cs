﻿using OfficeOpenXml;
using OfficeOpenXml.Style;
//
using Simce_Recepcion.Util;
using System;
using System.Collections.Generic;
using System.Web.UI;
//
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Recepcion.Modulos.Despacho
{
    public partial class AsignarCajasExaminador : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            if (!IsPostBack)
            {
                CargarCombos();
                CargarComboxSubCentros();
                
            }
        }

        private void CargarCombos()
        {
            try
            {
                ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();

                DP_TipoMovimiento.DataSource = tipoMovimiento.ListarSupervisores();
                DP_TipoMovimiento.DataTextField = "descripcion";
                DP_TipoMovimiento.DataValueField = "id";
                DP_TipoMovimiento.DataBind();
                //DP_TipoMovimiento.SelectedIndex = 2;
                //DP_TipoMovimiento

                ITipoDocumentoBLL tipoDocumento = new TipoDocumentoBLL();

                DP_TipoDocumento.DataSource = tipoDocumento.Listar();
                DP_TipoDocumento.DataTextField = "Descripcion";
                DP_TipoDocumento.DataValueField = "Id";
                DP_TipoDocumento.DataBind();
                DP_TipoDocumento.SelectedIndex = 2;

                ITipoEntidadDespachoBLL tipoDespacho = new TipoEntidadDespachoBLL();

                DP_TipoEntidadDespacho.DataSource = tipoDespacho.Listar();
                DP_TipoEntidadDespacho.DataTextField = "descripcion";
                DP_TipoEntidadDespacho.DataValueField = "id";
                DP_TipoEntidadDespacho.DataBind();
                DP_TipoEntidadDespacho.SelectedIndex = 2;
                
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void DP_TipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            CargarComboxSubCentros();
        }

        private void CargarComboxSubCentros()
        {
            try
            {
                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscarExaminador_Click(object sender, EventArgs e)
        {

         
            if (Convert.ToInt16(DP_TipoMovimiento.SelectedItem.Value) == 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe seleccionar tipo de movimiento');", true);
                TxtRutExaminador.Focus();
                return;

            }

            int tipoMovimiento = Convert.ToInt32(DP_TipoMovimiento.SelectedItem.Value);
            
            if (tipoMovimiento == 2)
            {
                if (TxtRutExaminador.Text == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Rut examinador');", true);
                    TxtRutExaminador.Focus();
                    return;
                }
                if (TxtDv.Text=="")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe Ingresar digito verificador');", true);
                    TxtRutExaminador.Focus();
                    return;
                }

                HDRutSupervisor.Value = TxtRutExaminador.Text + TxtDv.Text;
                
                AsignarCajasEN Asignarcajas = new AsignarCajasEN();

                Asignarcajas.fechaMPR = DateTime.Now;
                Asignarcajas.idTipoMovimiento = Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value);
                Asignarcajas.idTipoDocumento = Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value);
                Asignarcajas.idTipoEntidadDespacho = Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value);
                Asignarcajas.idEntidadDespacho = Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value);
                //Asignarcajas.numeroDocumento = Convert.ToInt64(TxtNumDocumento.Text);
                Asignarcajas.rut = Convert.ToInt64(HDRutSupervisor.Value);
                Asignarcajas.idUsuario = User.Identity.Name;

                IAsignarCajasBLL AsignarCajasBLL = new AsignarCajasBLL();

                AsignarCajasTipoPersonaEN tipoPersona = new AsignarCajasTipoPersonaEN();

                tipoPersona = AsignarCajasBLL.tipoPersona(Convert.ToInt64(HDRutSupervisor.Value));

                HDtipoPersona.Value = tipoPersona.tipoPersona.ToString();
                HDNombreSupervisor.Value = tipoPersona.nombre.ToString();             
                
                
                if (HDtipoPersona.Value == "0")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('El rut digitado no pertenece al Grupo de Supervisores o Examinadores');", true);
                    TxtRutExaminador.Focus();
                    return;
                }
                else
                {

                    AsignarCajasPackingListEN packing = new AsignarCajasPackingListEN();

                    packing = AsignarCajasBLL.IngresarDocumentoExaminador(Asignarcajas);

                    HDidMPR.Value = packing.idMPR.ToString();

                    TxtNumDocumento.Text = packing.numeroDocumento.ToString();
                    HDNumeroDocumento.Value = packing.numeroDocumento.ToString();
                    HDEstadoMovimiento.Value = AsignarCajasBLL.estadoMovimiento(Convert.ToInt64(HDidMPR.Value)).ToString();

                    if (HDEstadoMovimiento.Value == "1")
                    {
                        BtnGuardarCaja.Enabled = true;
                        BtnFinalizarMovimiento.Enabled = true;
                        Label15.Text = "Estado Movimiento: En Curso";
                    }
                    else
                    {
                        BtnGuardarCaja.Enabled = false;
                        BtnFinalizarMovimiento.Enabled = false;
                        Label15.Text = "Estado Movimiento: Finalizado";
                    }
                    CargaGrilla();
                    BtnBuscarExaminador.Enabled = false;
                    TxtIdentificadorCaja.Focus();
                }
            }
            else if(tipoMovimiento == 1) //Recepcion
            {
                if (TxtRutExaminador.Text == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar Rut examinador');", true);
                    TxtRutExaminador.Focus();
                    return;

                }


                HDRutSupervisor.Value = TxtRutExaminador.Text + TxtDv.Text;

                AsignarCajasEN Asignarcajas = new AsignarCajasEN();

                Asignarcajas.fechaMPR = DateTime.Now;
                Asignarcajas.idTipoMovimiento = Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value);
                Asignarcajas.idTipoDocumento = Convert.ToInt16(DP_TipoDocumento.Items[DP_TipoDocumento.SelectedIndex].Value);
                Asignarcajas.idTipoEntidadDespacho = Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value);
                Asignarcajas.idEntidadDespacho = Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value);
                Asignarcajas.numeroDocumento = Convert.ToInt64(TxtNumDocumento.Text);
                Asignarcajas.rut = Convert.ToInt64(HDRutSupervisor.Value);
                Asignarcajas.idUsuario = User.Identity.Name;

                IAsignarCajasBLL AsignarCajasBLL = new AsignarCajasBLL();

                AsignarCajasTipoPersonaEN tipoPersona = new AsignarCajasTipoPersonaEN();

                tipoPersona = AsignarCajasBLL.tipoPersona(Convert.ToInt64(HDRutSupervisor.Value));

                HDtipoPersona.Value = tipoPersona.tipoPersona.ToString();
                HDNombreSupervisor.Value = tipoPersona.nombre.ToString();
                

                if (HDtipoPersona.Value == "0")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('El rut digitado no pertenece a personal');", true);
                    TxtRutExaminador.Focus();
                    return;
                }
                else
                {

                    AsignarCajasPackingListEN packing = new AsignarCajasPackingListEN();

                    packing = AsignarCajasBLL.IngresarDocumentoExaminador(Asignarcajas);

                    HDidMPR.Value = packing.idMPR.ToString();

                    TxtNumDocumento.Text = packing.numeroDocumento.ToString();

                    HDNumeroDocumento.Value = packing.numeroDocumento.ToString();

                    HDEstadoMovimiento.Value = AsignarCajasBLL.estadoMovimiento(Convert.ToInt64(HDidMPR.Value)).ToString();

                    if (HDEstadoMovimiento.Value == "2") //Viene cuadrada desde despacho y se debe recepcionar
                    {
                        BtnGuardarCaja.Enabled = true;
                        BtnFinalizarMovimiento.Enabled = true;
                        Label15.Text = "Estado Movimiento: En Curso";
                    }
                    else if (HDEstadoMovimiento.Value == "3") //Esta cuadrada y recepcionada desde despacho
                    {
                        BtnGuardarCaja.Enabled = false;
                        BtnFinalizarMovimiento.Enabled = false;
                        Label15.Text = "Estado Movimiento: Finalizado";
                    }
                    CargaGrillaRecepcion();
                    BtnBuscarExaminador.Enabled = false;
                    TxtIdentificadorCaja.Focus();
                }
            }
        }

        protected void BtnGuardarCaja_Click(object sender, EventArgs e)
        {

            if (TxtNumDocumento.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar numero de Documento');", true);
                TxtNumDocumento.Focus();
                return;
            }

            if (TxtRutExaminador.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar Rut examinador');", true);
                TxtRutExaminador.Focus();
                return;

            }

            if (TxtIdentificadorCaja.Text.Length < 9)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no debe ser menor a 9 dígitos');", true);
                TxtIdentificadorCaja.Focus();
                return;
            }


            int codTipoMaterial = Convert.ToInt32(TxtIdentificadorCaja.Text.Substring(0, 1));
            
            if (codTipoMaterial > 4)
            {
                  ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no corresponde al tipo de material');", true);
                  TxtIdentificadorCaja.Focus();
                  return;
            }

            
            if (TxtIdentificadorCaja.Text == "")
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe Digitar Numero caja');", true);
                TxtIdentificadorCaja.Focus();
                return;                
            }
            
            AsignarCajasExaminadorEN AsignarCajasExaminador = new AsignarCajasExaminadorEN();

            AsignarCajasExaminador.idMPR = Convert.ToInt64(HDidMPR.Value); ;
            AsignarCajasExaminador.rut = Convert.ToInt64(HDRutSupervisor.Value);
            AsignarCajasExaminador.numeroDocumento =Convert.ToInt64(TxtNumDocumento.Text);
            AsignarCajasExaminador.Gs1 = Convert.ToInt64(TxtIdentificadorCaja.Text);
            AsignarCajasExaminador.idUsuario = User.Identity.Name;
            AsignarCajasExaminador.tipoPersona = Convert.ToInt16(HDtipoPersona.Value);
            AsignarCajasExaminador.idEntidadCustodio = Convert.ToInt32(DP_EntidadDespacho.SelectedItem.Value);

            IAsignarCajasExaminadorBLL  AsignarCajasExaminadorBLL = new AsignarCajasExaminadorBLL();

            if (Convert.ToInt32(DP_TipoMovimiento.SelectedItem.Value) == 2)
            {
                AsignarCajasExaminadorBLL.IngresarCajasExaminador(AsignarCajasExaminador);

                CargaGrilla();
                
            }
            else if (Convert.ToInt32(DP_TipoMovimiento.SelectedItem.Value) == 1)
            {
                AsignarCajasExaminadorBLL.RecepcionarCajasExaminador(AsignarCajasExaminador, User.Identity.Name);
                CargaGrillaRecepcion();
            }

            TxtIdentificadorCaja.Text = "";
            TxtIdentificadorCaja.Focus();
        }

        private void CargaGrilla()
        {
            Int64 idMPR = Convert.ToInt64(HDidMPR.Value);
            Int64 rut = Convert.ToInt64(HDRutSupervisor.Value);
            Int64 numeroDocumento = Convert.ToInt64(TxtNumDocumento.Text); 
            
            IAsignarCajasExaminadorBLL AsignarCajasExaminadorBLL = new AsignarCajasExaminadorBLL();
            GrOrdenDespacho.DataSource = AsignarCajasExaminadorBLL.ListarCajasExaminador(idMPR, rut, numeroDocumento);
            GrOrdenDespacho.DataBind();
        
        }

        private void CargaGrillaRecepcion()
        {
            Int64 rut = Convert.ToInt64(HDRutSupervisor.Value);
            Int64 idMPR = Convert.ToInt64(HDidMPR.Value);
            
            IAsignarCajasExaminadorBLL AsignarCajasExaminadorBLL = new AsignarCajasExaminadorBLL();
            GrOrdenDespacho.DataSource = AsignarCajasExaminadorBLL.ListarCajasExaminadorRecepcion(idMPR, rut);
            GrOrdenDespacho.DataBind();

        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            TxtNumDocumento.Text = "";
            TxtRutExaminador.Text = "";
            TxtDv.Text = "";
            TxtIdentificadorCaja.Text = "";
            GrOrdenDespacho.DataBind();
            BtnBuscarExaminador.Enabled = true;
            BtnGuardarCaja.Enabled = false;
            BtnFinalizarMovimiento.Enabled = false;
            HDNumeroDocumento.Value = "";
            HDidMPR.Value = "";
            HDEstadoMovimiento.Value = "";
            HDNombreSupervisor.Value = "";
            Label15.Text = "";
            BtnPacking.Enabled = false;

            
        }

        protected void BtnFinalizarMovimiento_Click(object sender, EventArgs e)
        {
            Int64 idMPR = Convert.ToInt64(HDidMPR.Value);
            IAsignarCajasBLL AsignarCajasBLL = new AsignarCajasBLL();

            int tipoMovimiento = Convert.ToInt16(DP_TipoMovimiento.SelectedItem.Value);

            AsignarCajasBLL.FinalizarMovimiento(idMPR, tipoMovimiento);


            if (tipoMovimiento == 2)
            {
                limpiarDespacho();
            }
            else
            {
                limpiarRecepcion();
            }     
            
        }        
        
       
        protected void DP_TipoMovimiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (Convert.ToInt32(DP_TipoMovimiento.SelectedItem.Value) == 1)
            {
                TxtNumDocumento.Enabled = true;
            }
            else
            {
                TxtNumDocumento.Enabled = false;
            }
        }

        private void DumpExcel()
        {
            List<AsignarCajasPackingEN> lista = LoadLista();
            List<CabeceraEN> cabecera = new List<CabeceraEN>();

            cabecera.Add(new CabeceraEN() { Titulo = "Packing List" });
            cabecera.Add(new CabeceraEN());
            cabecera.Add(new CabeceraEN() { Titulo = "Numero Documento", Valor = this.HDNumeroDocumento.Value });
            cabecera.Add(new CabeceraEN() { Titulo = "Rut Supervisor", Valor = this.HDRutSupervisor.Value });
            cabecera.Add(new CabeceraEN() { Titulo = "Nombre Supervisor", Valor = this.HDNombreSupervisor.Value });
            cabecera.Add(new CabeceraEN() { Titulo = "Firma", Valor = "____________________"});
            


            using (ExcelPackage pck = new ExcelPackage())
            {
                //Create the worksheet
                ExcelWorksheet ws = pck.Workbook.Worksheets.Add("Packing_list" + DateTime.Now.ToString("dd-MM-yyyy"));

                try
                {
                    ws.Cells["A1"].LoadFromCollection(cabecera, false);
                    //ws.Cells["A8"].LoadFromCollection(lista, true);
                    ExcelHelper.LoadFromCollectionWithHeaders<AsignarCajasPackingEN>(ws.Cells["A8"], lista);


                    //adding styles
                    using (ExcelRange rng = ws.Cells["A1:D1"])
                    {
                        rng.Merge = true;
                        rng.Style.Font.Bold = true;
                        rng.Style.Font.Size = 14;
                        rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }

                    using (ExcelRange rngB = ws.Cells["A8:D8"])
                    {
                        //rng.Merge = true;
                        rngB.Style.Font.Bold = true;
                        rngB.Style.Font.Size = 12;
                        rngB.Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                    }

                    using (ExcelRange rngC = ws.Cells["A3:A6"])
                    {
                        //rng.Merge = true;
                        rngC.Style.Font.Bold = true;
                        rngC.Style.Font.Size = 12;
                        //rngC.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                        rngC.Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                    }

                    using (ExcelRange rngD = ws.Cells["A9:D100"])
                    {
                        //rng.Merge = true;
                        //rngC.Style.Font.Bold = true;
                        rngD.Style.Font.Size = 11;
                        rngD.Style.HorizontalAlignment = ExcelHorizontalAlignment.Left;
                        rngD.Style.VerticalAlignment = ExcelVerticalAlignment.Center;
                        //rngD.Style.Border.Top.Color.SetColor(System.Drawing.Color.Black);


                    }



                }
                catch (Exception ex)
                {
                    throw ex;
                }

                //Write it back to the client
                Response.Clear();
                Response.AddHeader("content-disposition", "attachment;  filename=Packing_list_" + DateTime.Now.ToString("dd-MM-yyyy") + ".xlsx");
                Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                Response.BinaryWrite(pck.GetAsByteArray());
                Response.End();
            }
        }

        private List<AsignarCajasPackingEN> LoadLista()
        {
            List<AsignarCajasPackingEN> lista = new List<AsignarCajasPackingEN>();
            IAsignarCajasPackingBLL consulta = new AsignarCajasPackingBLL();


            Int64 numeroDocumento = 0;
            numeroDocumento = Convert.ToInt64(HDNumeroDocumento.Value);
            lista = consulta.GenerarPacking(numeroDocumento);
            return lista;
        }


        private void limpiarDespacho()
        {
            TxtNumDocumento.Text = "";
            TxtRutExaminador.Text = "";
            TxtDv.Text = "";
            TxtIdentificadorCaja.Text = "";
            GrOrdenDespacho.DataBind();
            BtnBuscarExaminador.Enabled = true;
            BtnGuardarCaja.Enabled = false;
            BtnFinalizarMovimiento.Enabled = false;
            Label15.Text = "";
            BtnPacking.Enabled = true;
           
        }

        private void limpiarRecepcion()
        {
            TxtNumDocumento.Text = "";
            TxtRutExaminador.Text = "";
            TxtDv.Text = "";
            TxtIdentificadorCaja.Text = "";
            GrOrdenDespacho.DataBind();
            BtnBuscarExaminador.Enabled = true;
            BtnGuardarCaja.Enabled = false;
            BtnFinalizarMovimiento.Enabled = false;
            Label15.Text = "";
            BtnPacking.Enabled = false;

        }

        protected void BtnPacking_Click(object sender, EventArgs e)
        {
            BtnPacking.Enabled = false;
            DumpExcel();
            
        }
    }
}