﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace Simce_Operaciones.Despacho
{
    public partial class MovimientoCajasSubCentro : System.Web.UI.Page
    {
        string CodigosPorPistoleoOManuales = string.Empty; //1=Pistoleo, 2=Manual
        int tipoDocumento = 1; //Guia Despacho

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                CargarCombos();
                Contexto_Botones(1);
            }
            CodigosPorPistoleoOManuales = RetornaFormaIngresoCodigos();
        }

        protected void DP_TipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void DP_TipoEntidadRecepcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

                DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
                DP_EntidadRecepcion.DataTextField = "descripcion";
                DP_EntidadRecepcion.DataValueField = "codigo";
                DP_EntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);

            }
        }

        protected void BtnBuscarDocumentoDespacho_Click(object sender, EventArgs e)
        {
            try
            {
                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Por Pistoleo, debe ingresar una vez el codigo
                {
                    if (TxtNumGuiaDespacho.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de guia');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }
                else //1=Ingreso Manual, debe ingresar dos veces el codigo
                {
                    if (HDNumeroGuiaDespacho.Value.Trim() == "")
                    {
                        HDNumeroGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroGuiaDespacho.Value) != long.Parse(TxtNumGuiaDespacho.Text))
                    {
                        HDNumeroGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                        TxtNumGuiaDespacho.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto');", true);
                        TxtNumGuiaDespacho.Focus();
                        return;
                    }
                }

                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();
                guiaDespachoEN = guiaDespachoBLL.Buscar(tipoDocumento, Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value), Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumGuiaDespacho.Text));

                if (guiaDespachoEN == null)
                {
                    TxtTotalPalletsEsperado.Text = "";
                    TxtTotalCajasCapacitacionEsperado.Text = "";
                    TxtTotalCajasComplementarioEsperado.Text = "";
                    TxtTotalCajasCursoEsperado.Text = "";
                    TxtTotalCajasPetosEsperado.Text = "";
                    TxtTotalCajasEsperado.Text = "";
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                HDIdGuiaDespacho.Value = guiaDespachoEN.idMCR.ToString();
                TxtTotalPalletsEsperado.Text = guiaDespachoEN.totalPallets.ToString();
                TxtTotalCajasCapacitacionEsperado.Text = guiaDespachoEN.totalContenedorCapacitacion.ToString();
                TxtTotalCajasComplementarioEsperado.Text = guiaDespachoEN.totalContenedorComplementario.ToString();
                TxtTotalCajasCursoEsperado.Text = guiaDespachoEN.totalContenedorCajasCurso.ToString();
                TxtTotalCajasPetosEsperado.Text = guiaDespachoEN.totalContenedorPetos.ToString();
                TxtTotalCajasEsperado.Text = guiaDespachoEN.totalContenedor.ToString();

                LblEstadoGuiaDespacho.Text = guiaDespachoEN.desripcionEstadoGuiaDespacho;
                HDEstadoGuiaDespacho.Value = guiaDespachoEN.estadoGuiaDespacho.ToString();

                if (guiaDespachoEN.estadoGuiaDespacho == 2) //Si el documento esta descuadrado (estado = 2) no se puede modificar
                {
                    Contexto_Botones(1);
                }
                else
                {
                    Contexto_Botones(2);
                }
                CalcularTotales();
                
                TxtIdentificadorPallet.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(ex.Message, ex);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscarPallet_Click(object sender, EventArgs e)
        {
            try
            {
                if (HDIdGuiaDespacho.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar numero de Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorPallet.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de pallet');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }
                else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                {
                    if (HDNumeroPallet.Value.Trim() == "")
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroPallet.Value) != long.Parse(TxtIdentificadorPallet.Text))
                    {
                        HDNumeroPallet.Value = TxtIdentificadorPallet.Text;
                        TxtIdentificadorPallet.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet incorrecto');", true);
                        TxtIdentificadorPallet.Focus();
                        return;
                    }
                }

                int tipoEntidadCustodia = Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value);
                int entidadCustodia = Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value);

                PalletEN palletEN = new PalletEN();
                IPalletBLL palletBLL = new PalletBLL();

                palletEN = palletBLL.Buscar(Convert.ToInt64(TxtIdentificadorPallet.Text), Convert.ToInt16(HDIdGuiaDespacho.Value), tipoEntidadCustodia, entidadCustodia, User.Identity.Name, 3, 3);
                
                if (palletEN == null)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet no existe para esta guía de despacho');", true);
                    TxtIdentificadorPallet.Focus();
                    return;
                }

                HDIdPallet.Value = palletEN.idPallet.ToString();

                CargarListaDespacho();

                CalcularTotales();

                TxtIdentificadorCaja.Focus();

                Contexto_Botones(3);

            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnGuardarCaja_Click(object sender, EventArgs e)
        {
            try
            {
                if (HDIdGuiaDespacho.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar numero de Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (HDIdPallet.Value == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe buscar número de Pallet');", true);
                    TxtIdentificadorPallet.Focus();
                    return;
                }

                if (TxtIdentificadorCaja.Text.Length < 9)
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de caja no debe ser menor a 9 dígitos');", true);
                    TxtIdentificadorCaja.Focus();
                    return;
                }

                if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Por Pistoleo, debe ingresar una vez el codigo
                {
                    if (TxtIdentificadorCaja.Text.Trim() == "")
                    {
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de caja');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }
                else //1=Ingreso Manual, debe ingresar dos veces el codigo
                {
                    if (HDNumeroCaja.Value.Trim() == "")
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                    if (Convert.ToInt64(HDNumeroCaja.Value) != long.Parse(TxtIdentificadorCaja.Text))
                    {
                        HDNumeroCaja.Value = TxtIdentificadorCaja.Text;
                        TxtIdentificadorCaja.Text = "";
                        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de pallet incorrecto');", true);
                        TxtIdentificadorCaja.Focus();
                        return;
                    }
                }

                GuardarCaja();

                Contexto_Botones(3);
                CargarListaDespacho();
                CalcularTotales();

                TxtIdentificadorCaja.Text = "";
                TxtIdentificadorCaja.Focus();

                //if (GrOrdenDespacho.Rows.Count == 0)
                //{
                //    Contexto_Botones(4);
                //}

            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnFinalizarPallet_Click(object sender, EventArgs e)
        {
            try
            {
                
                IPalletBLL palletBLL = new PalletBLL();
                palletBLL.DespachoCerrarPallet(Convert.ToInt64(HDIdGuiaDespacho.Value), Convert.ToInt16(HDIdPallet.Value), User.Identity.Name);


                CalcularTotales();
                GrOrdenDespacho.DataBind();
                TxtIdentificadorPallet.Text = "";
                TxtIdentificadorPallet.Focus();
                
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnFinalizarMovimientoPallet_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt16(HDTotalDiferenciasCuadratura.Value) > 0)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Documento de despacho no está cuadrado, imposible finalizar movimiento de cajas');", true);
                return;
            }

            PalletEN palletEN = new PalletEN();

            IPalletBLL palletBLL = new PalletBLL();
            palletBLL.DespachoCerrarMovimientoPallet(Convert.ToInt16(HDIdGuiaDespacho.Value), Convert.ToInt16(HDIdPallet.Value), User.Identity.Name);

            Contexto_Botones(1);
            LimpiarCuadratura();
            GrOrdenDespacho.DataBind();
            TxtNumGuiaDespacho.Text = "";
            TxtNumGuiaDespacho.Focus();
            
        }

        private void GuardarCaja()
        {
            try
            {
                long tipoMaterial = 0;
                int codTipoMaterial = Convert.ToInt32(TxtIdentificadorCaja.Text.Substring(0, 1));

                if (codTipoMaterial == 3 || codTipoMaterial == 4) //Complementario
                {
                    tipoMaterial = 2;
                }

                if (codTipoMaterial == 1 || codTipoMaterial == 2) //Caja curso
                {
                    tipoMaterial = 3;
                }

                int idTipoEntidadCustodio = Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value);
                int idEntidadCustodio = Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value);

                ContenedorEN contenedorEN = new ContenedorEN();

                IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();

                contenedorEN = movimientoContenedorDetalleBLL.ContenedorActualizaDespachoCaja(TxtIdentificadorCaja.Text, tipoMaterial, Convert.ToInt16(HDIdPallet.Value), User.Identity.Name, idTipoEntidadCustodio, idEntidadCustodio);

                movimientoContenedorDetalleBLL.MovimientoContenedorActualizaDespachoCaja(Convert.ToInt16(HDIdGuiaDespacho.Value), contenedorEN.idContenedor, TxtIdentificadorCaja.Text, tipoMaterial, Convert.ToInt16(HDIdPallet.Value), contenedorEN.estadoBDSimce, User.Identity.Name);

                CargarListaDespacho();

            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void CargarCombos()
        {
            try
            {
                ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();

                DP_TipoMovimiento.DataSource = tipoMovimiento.Listar();
                DP_TipoMovimiento.DataTextField = "descripcion";
                DP_TipoMovimiento.DataValueField = "id";
                DP_TipoMovimiento.DataBind();
                DP_TipoMovimiento.SelectedIndex = 2;
                //DP_TipoMovimiento

                ITipoEntidadDespachoBLL tipoDespacho = new TipoEntidadDespachoBLL();

                DP_TipoEntidadDespacho.DataSource = tipoDespacho.Listar();
                DP_TipoEntidadDespacho.DataTextField = "descripcion";
                DP_TipoEntidadDespacho.DataValueField = "id";
                DP_TipoEntidadDespacho.DataBind();
                DP_TipoEntidadDespacho.SelectedValue = "3";

                ITipoEntidadRecepcionBLL tipoRecepcion = new TipoEntidadRecepcionBLL();

                DP_TipoEntidadRecepcion.DataSource = tipoRecepcion.Listar();
                DP_TipoEntidadRecepcion.DataTextField = "descripcion";
                DP_TipoEntidadRecepcion.DataValueField = "id";
                DP_TipoEntidadRecepcion.DataBind();
                DP_TipoEntidadRecepcion.SelectedValue = "2";

                CargaComboDespacho();
                CargaComboRecepcion();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargaComboDespacho()
        {
            try
            {
                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargaComboRecepcion()
        {
            try
            {
                IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

                DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
                DP_EntidadRecepcion.DataTextField = "descripcion";
                DP_EntidadRecepcion.DataValueField = "codigo";
                DP_EntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        private void CargarListaDespacho()
        {
            try
            {
                IGuiaDespachoBLL OrdenDespacho = new GuiaDespachoBLL();

                GrOrdenDespacho.DataSource = OrdenDespacho.OrdenDespachoListar(Convert.ToInt16(HDIdGuiaDespacho.Value), Convert.ToInt16(HDIdPallet.Value));
                GrOrdenDespacho.DataBind();
                int cantidadFilas = GrOrdenDespacho.Rows.Count;
            }
            catch (Exception ex)
            {
                Log.Instance.Write(ex.Message, LogLevel.Error);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected string RetornaFormaIngresoCodigos()
        {

            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;

        }

        private void CalcularTotales()
        {
            long TotalCapacitacion = 0;
            long DiferenciaCapacitacion = 0;
            long TotalComplementario = 0;
            long DiferenciaComplementario = 0;
            long TotalCajasCurso = 0;
            long DiferenciaCajasCurso = 0;
            long TotalCajasPetos = 0;
            long DiferenciaCajasPetos = 0;
            long TotalPallet = 0;
            long DiferenciaPallet = 0;
            int DiferenciaTotalCajas = 0;

            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();

            List<TotalCuadratura> TotalCuadratura = movimientoContenedorDetalleBLL.RetornaTotalCuadraturaEnDespacho(Convert.ToInt16(HDIdGuiaDespacho.Value));

            foreach (TotalCuadratura elemento in TotalCuadratura)
            {
                switch (elemento.idTipoMaterial)
                {
                    case 1:
                        TotalCapacitacion = elemento.Total;
                        break;

                    case 2:
                        TotalComplementario = elemento.Total;
                        break;

                    case 3:
                        TotalCajasCurso = elemento.Total;
                        break;

                    case 4:
                        TotalCajasPetos = elemento.Total;
                        break;
                }
            }

            //Total Pallet
            TotalPallet = movimientoContenedorDetalleBLL.RetornaCantidadPalletDespachados(Convert.ToInt16(HDIdGuiaDespacho.Value));
            TxtTotalPalletsDespachado.Text = TotalPallet.ToString();
            DiferenciaPallet = Convert.ToInt16(TxtTotalPalletsEsperado.Text) - TotalPallet;
            TxtTotalPalletsDiferencia.Text = DiferenciaPallet.ToString();

            //Total Capacitacion
            TxtTotalCajasCapacitacionDespachado.Text = TotalCapacitacion.ToString();
            DiferenciaCapacitacion = Convert.ToInt16(TxtTotalCajasCapacitacionEsperado.Text) - TotalCapacitacion;
            TxtTotalCajasCapacitacionDiferencia.Text = DiferenciaCapacitacion.ToString();

            //Total Complementario
            TxtTotalCajasComplementarioDespachado.Text = TotalComplementario.ToString();
            DiferenciaComplementario = Convert.ToInt16(TxtTotalCajasComplementarioEsperado.Text) - TotalComplementario;
            TxtTotalCajasComplementarioDiferencia.Text = DiferenciaComplementario.ToString();

            //Total Cajas Curso
            TxtTotalCajasCursoDespachado.Text = TotalCajasCurso.ToString();
            DiferenciaCajasCurso = Convert.ToInt16(TxtTotalCajasCursoEsperado.Text) - TotalCajasCurso;
            TxtTotalCajasCursoDiferencia.Text = DiferenciaCajasCurso.ToString();

            //Total Petos
            TxtTotalCajasPetosDespachado.Text = TotalCajasPetos.ToString();
            DiferenciaCajasPetos = Convert.ToInt16(TxtTotalCajasPetosEsperado.Text) - TotalCajasPetos;
            TxtTotalCajasPetosDiferencia.Text = DiferenciaCajasPetos.ToString();

            HDTotalDiferenciasCuadratura.Value = Convert.ToString(DiferenciaCapacitacion + DiferenciaComplementario + DiferenciaCajasCurso + DiferenciaCajasPetos);

            //Total Cajas
            TxtTotalCajasDespachado.Text = Convert.ToString(TotalCapacitacion + TotalComplementario + TotalCajasCurso + TotalCajasPetos);
            DiferenciaTotalCajas = Convert.ToInt16(TxtTotalCajasEsperado.Text) - Convert.ToInt16(TxtTotalCajasDespachado.Text);
            TxtTotalCajasDiferencia.Text = DiferenciaTotalCajas.ToString();

            if (Convert.ToInt16(TxtTotalCajasDiferencia.Text) == 0)
            {
                Contexto_Botones(5);
            }
            
        }

        private void LimpiarCuadratura()
        {
            //Total Pallet
            TxtTotalPalletsEsperado.Text = "";
            TxtTotalPalletsDespachado.Text = "";
            TxtTotalPalletsDiferencia.Text = "";

            //Total Capacitacion
            TxtTotalCajasCapacitacionEsperado.Text = "";
            TxtTotalCajasCapacitacionDespachado.Text = "";
            TxtTotalCajasCapacitacionDiferencia.Text = "";

            //Total Complementario
            TxtTotalCajasComplementarioEsperado.Text = "";
            TxtTotalCajasComplementarioDespachado.Text = "";
            TxtTotalCajasComplementarioDiferencia.Text = "";

            //Total Cajas Curso
            TxtTotalCajasCursoEsperado.Text = "";
            TxtTotalCajasCursoDespachado.Text = "";
            TxtTotalCajasCursoDiferencia.Text = "";

            //Total Petos
            TxtTotalCajasPetosEsperado.Text = "";
            TxtTotalCajasPetosDespachado.Text = "";
            TxtTotalCajasPetosDiferencia.Text = "";

            //Total Cajas
            TxtTotalCajasEsperado.Text = "";
            TxtTotalCajasDespachado.Text = "";
            TxtTotalCajasDiferencia.Text = "";
        }

        private void Contexto_Botones(int caso)
        {
            switch (caso)
            {
                case 1: //Al inicio de la pagina
                    BtnBuscarDocumentoDespacho.Enabled = true;
                    BtnBuscarPallet.Enabled = false;
                    BtnFinalizarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarMovimientoPallet.Enabled = true;
                    break;

                case 2: //Al guardar Pallet
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = true;
                    BtnFinalizarPallet.Enabled = false;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarMovimientoPallet.Enabled = true;
                    break;

                case 3: //Al guardar caja
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnFinalizarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = true;
                    BtnFinalizarMovimientoPallet.Enabled = true;
                    break;
                case 4: //Al finalizar pallet
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnFinalizarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarMovimientoPallet.Enabled = true;
                    break;
                case 5: //Al finalizar movimiento
                    BtnBuscarDocumentoDespacho.Enabled = false;
                    BtnBuscarPallet.Enabled = false;
                    BtnFinalizarPallet.Enabled = true;
                    BtnGuardarCaja.Enabled = false;
                    BtnFinalizarMovimientoPallet.Enabled = true;
                    break;
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            Contexto_Botones(1);
            TxtNumGuiaDespacho.Text = "";
            TxtIdentificadorPallet.Text = "";
            GrOrdenDespacho.DataBind();
            LimpiarCuadratura();
            HDEstadoGuiaDespacho.Value = "";
            HDIdGuiaDespacho.Value = "";
            HDIdPallet.Value = "";
            HDNumeroCaja.Value = "";
            HDNumeroGuiaDespacho.Value = "";
            HDNumeroPallet.Value = "";
            HDTotalDiferenciasCuadratura.Value = "";
        }
    }
}