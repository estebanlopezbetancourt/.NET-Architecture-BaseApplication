﻿using System;
using System.Web;
using System.Web.UI;
using TCS.Simce.Operaciones.BLL.RecepcionDespacho;
using TCS.Simce.Operaciones.BLL.Usuario;
using TCS.Simce.Operaciones.EN.Logging;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.Usuario;

namespace Simce_Operaciones.Despacho
{
    public partial class GuiaDespacho : Page
    {
        private static string CLASS = "GuiaDespacho";

        int tipoMovimiento = 2;
        int tipoDocumento = 2;
        string CodigosPorPistoleoOManuales = string.Empty; //1=Pistoleo, 2=Manual

        protected void Page_Load(object sender, EventArgs e)
        {
            string METHOD = "Page_Load";

            try
            {
                if (!IsPostBack)
                {
                    CargarCombos();
                    Contexto_Visualizar("Buscar");
                    if (!CargarUsuario())
                    {
                        Context.GetOwinContext().Authentication.SignOut();
                        Response.Redirect("~\\Account\\Login.aspx");
                    }

                    if (tipoMovimiento == 1)
                    {
                        DP_TipoMovimiento.SelectedIndex = 1;
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Origen";
                        LblEntidadOrigen.Text = "Entidad Origen";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Recepción";
                        LblEntidadDestino.Text = "Entidad Recepción";
                    }
                    if (tipoMovimiento == 2)
                    {
                        DP_TipoMovimiento.SelectedIndex = 2;
                        LblTipoEntidadOrigen.Text = "Tipo Entidad Despacho";
                        LblEntidadOrigen.Text = "Entidad Despacho";
                        LblTipoEntidadDestino.Text = "Tipo Entidad Destino";
                        LblEntidadDestino.Text = "Entidad Destino";
                    }
                    HDPasaPorOrdenPreparado.Value = "false";
                }

                CodigosPorPistoleoOManuales = RetornaFormaIngresoCodigos();

            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoMovimiento_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoMovimiento_SelectedIndexChanged";

            try
            {
                EntornoTipoMovimiento(Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value));
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoEntidadDespacho_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadDespacho_SelectedIndexChanged";

            try
            {
                CargaComboDespacho();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void DP_TipoEntidadRecepcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            string METHOD = "DP_TipoEntidadRecepcion_SelectedIndexChanged";

            try
            {
                CargaComboRecepcion();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnGuardar_Click";

            try
            {
                if (TxtNumGuiaDespacho.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Número de Guía de Despacho');", true);
                    TxtNumGuiaDespacho.Focus();
                    return;
                }

                if (TxtTotalPallets.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Pallets');", true);
                    TxtTotalPallets.Focus();
                    return;
                }

                if (TxtTotalContenedorCapacitacion.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Contenedor Capacitacion');", true);
                    TxtTotalContenedorCapacitacion.Focus();
                    return;
                }

                if (TxtTotalContenedorComplementario.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Contenedor Complementario');", true);
                    TxtTotalContenedorComplementario.Focus();
                    return;
                }

                if (TxtTotalContenedorCajasCurso.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Contenedor CajasCurso');", true);
                    TxtTotalContenedorCajasCurso.Focus();
                    return;
                }

                if (TxtTotalContenedorPetos.Text.Trim() == "")
                {
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe ingresar Total Contenedor Petos');", true);
                    TxtTotalContenedorPetos.Focus();
                    return;
                }

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();

                guiaDespachoBLL.AsignarNumeroGuiaDespachoAOrdenPreparado(Convert.ToInt16(HDIdGuiaDespacho.Value), Convert.ToInt64(TxtNumGuiaDespacho.Text), User.Identity.Name);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Guía de despacho modificada correctamente');", true);


                Limpiar();
                TxtNumGuiaDespacho.Text = "";
                TxtNumGuiaDespacho.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnBuscar_Click";

            try
            {
                if (HDPasaPorOrdenPreparado.Value == "false")
                {
                    if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                    {
                        if (TxtNumGuiaDespacho.Text.Trim() == "")
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de guia');", true);
                            TxtNumGuiaDespacho.Focus();
                            return;
                        }
                    }
                    else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                    {
                        if (HDNGuiaDespacho.Value.Trim() == "")
                        {
                            HDNGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                            TxtNumGuiaDespacho.Text = "";
                            TxtNumGuiaDespacho.Focus();
                            return;
                        }
                        if (Convert.ToInt64(HDNGuiaDespacho.Value) != long.Parse(TxtNumGuiaDespacho.Text))
                        {
                            HDNGuiaDespacho.Value = TxtNumGuiaDespacho.Text;
                            TxtNumGuiaDespacho.Text = "";
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto, favor intentelo nuevamente');", true);
                            TxtNumGuiaDespacho.Focus();
                            return;
                        }
                    }

                    HDPasaPorOrdenPreparado.Value = "true";
                    TxtNumeroOrdenPreparado.Focus();
                    return;
                }
                else
                {
                    if (CodigosPorPistoleoOManuales == "2") //2=Ingreso Manual, debe ingresar una vez el codigo
                    {
                        if (TxtNumeroOrdenPreparado.Text.Trim() == "")
                        {
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Debe digitar número de orden de preparado');", true);
                            TxtNumeroOrdenPreparado.Focus();
                            return;
                        }
                    }
                    else //1=Ingreso Por Pistoleo, debe ingresar dos veces el codigo
                    {
                        if (HDNumeroOrdenPreparado.Value.Trim() == "")
                        {
                            HDNumeroOrdenPreparado.Value = TxtNumeroOrdenPreparado.Text;
                            TxtNumeroOrdenPreparado.Text = "";
                            TxtNumeroOrdenPreparado.Focus();
                            return;
                        }
                        if (Convert.ToInt64(HDNumeroOrdenPreparado.Value) != long.Parse(TxtNumeroOrdenPreparado.Text))
                        {
                            HDNumeroOrdenPreparado.Value = TxtNumeroOrdenPreparado.Text;
                            TxtNumeroOrdenPreparado.Text = "";
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Número de guía incorrecto, favor intentelo nuevamente');", true);
                            TxtNumeroOrdenPreparado.Focus();
                            return;
                        }
                    }
                }

                GuiaDespachoEN guiaDespachoEN = new GuiaDespachoEN();

                IGuiaDespachoBLL guiaDespachoBLL = new GuiaDespachoBLL();
                guiaDespachoEN = guiaDespachoBLL.OrdenDespachoBuscar(tipoDocumento, Convert.ToInt16(DP_TipoMovimiento.Items[DP_TipoMovimiento.SelectedIndex].Value), Convert.ToInt16(DP_EntidadDespacho.Items[DP_EntidadDespacho.SelectedIndex].Value), Convert.ToInt16(DP_EntidadRecepcion.Items[DP_EntidadRecepcion.SelectedIndex].Value), Convert.ToInt64(TxtNumeroOrdenPreparado.Text));

                if (guiaDespachoEN == null)
                {
                    Limpiar();
                    Contexto_Visualizar("Ingresar");
                    CargarUsuario();
                    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('No existe número de orden de preparado');", true);
                    TxtNumeroOrdenPreparado.Focus();
                    return;
                }

                HDIdGuiaDespacho.Value = guiaDespachoEN.idMCR.ToString();
                TxtTotalPallets.Text = guiaDespachoEN.totalPallets.ToString();
                TxtTotalContenedorCapacitacion.Text = guiaDespachoEN.totalContenedorCapacitacion.ToString();
                TxtTotalContenedorComplementario.Text = guiaDespachoEN.totalContenedorComplementario.ToString();
                TxtTotalContenedorCajasCurso.Text = guiaDespachoEN.totalContenedorCajasCurso.ToString();
                TxtTotalContenedorPetos.Text = guiaDespachoEN.totalContenedorPetos.ToString();

                TxtTotalContenedor.Text = guiaDespachoEN.totalContenedor.ToString();
                TxtRutRecepcionista_Despachador.Text = guiaDespachoEN.RutUsuarioMovimiento.ToString();
                TxtDvRecepcionista_Despachador.Text = guiaDespachoEN.dvRutUsuarioMovimiento;
                TxtNombreRecepcionista_Despachador.Text = guiaDespachoEN.NombreUsuarioMovimiento;

                LblEstadoGuiaDespacho.Text = guiaDespachoEN.desripcionEstadoGuiaDespacho;

                Contexto_Visualizar("Modificar");

            }
            catch (Exception ex)
            {

                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);

                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
            }
        }

        protected void BtnLimpiar_Click(object sender, EventArgs e)
        {
            string METHOD = "BtnLimpiar_Click";

            try
            {
                Limpiar();
                TxtNumGuiaDespacho.Text = "";
                TxtNumGuiaDespacho.Focus();
            }
            catch (Exception ex)
            {
                Log.Instance.Exception(string.Format("Error en clase: {0}, metodo: {1}", CLASS, METHOD), ex);
            }
        }

        private void CargarCombos()
        {
            try
            {
                ITipoDocumentoBLL tipoDocumento = new TipoDocumentoBLL();

                DP_TipoDocumento.DataSource = tipoDocumento.Listar();
                DP_TipoDocumento.DataTextField = "Descripcion";
                DP_TipoDocumento.DataValueField = "Id";
                DP_TipoDocumento.DataBind();

                ITipoMovimientoBLL tipoMovimiento = new TipoMovimientoBLL();

                DP_TipoMovimiento.DataSource = tipoMovimiento.Listar();
                DP_TipoMovimiento.DataTextField = "descripcion";
                DP_TipoMovimiento.DataValueField = "id";
                DP_TipoMovimiento.DataBind();
                //DP_TipoMovimiento

                ITipoEntidadDespachoBLL tipoDespacho = new TipoEntidadDespachoBLL();

                DP_TipoEntidadDespacho.DataSource = tipoDespacho.Listar();
                DP_TipoEntidadDespacho.DataTextField = "descripcion";
                DP_TipoEntidadDespacho.DataValueField = "id";
                DP_TipoEntidadDespacho.DataBind();
                DP_TipoEntidadDespacho.SelectedIndex = 1;

                ITipoEntidadRecepcionBLL tipoRecepcion = new TipoEntidadRecepcionBLL();

                DP_TipoEntidadRecepcion.DataSource = tipoRecepcion.Listar();
                DP_TipoEntidadRecepcion.DataTextField = "descripcion";
                DP_TipoEntidadRecepcion.DataValueField = "id";
                DP_TipoEntidadRecepcion.DataBind();
                DP_TipoEntidadRecepcion.SelectedIndex = 1;

                CargaComboDespacho();
                CargaComboRecepcion();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void CargaComboDespacho()
        {
            try
            {
                IFuncionesGeneralesBLL entidadDespacho = new FuncionesGeneralesBLL();

                DP_EntidadDespacho.DataSource = entidadDespacho.EntidadDespachoListar(Convert.ToInt16(DP_TipoEntidadDespacho.Items[DP_TipoEntidadDespacho.SelectedIndex].Value));
                DP_EntidadDespacho.DataTextField = "descripcion";
                DP_EntidadDespacho.DataValueField = "codigo";
                DP_EntidadDespacho.DataBind();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);
                throw ex;
            }
        }

        private void CargaComboRecepcion()
        {
            try
            {
                IFuncionesGeneralesBLL entidadRecepcion = new FuncionesGeneralesBLL();

                DP_EntidadRecepcion.DataSource = entidadRecepcion.EntidadRecepcionListar(Convert.ToInt16(DP_TipoEntidadRecepcion.Items[DP_TipoEntidadRecepcion.SelectedIndex].Value));
                DP_EntidadRecepcion.DataTextField = "descripcion";
                DP_EntidadRecepcion.DataValueField = "codigo";
                DP_EntidadRecepcion.DataBind();
            }
            catch (Exception ex)
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "AlertBox_" + DateTime.Now.ToString(), "alert('Se ha producido un problema en la aplicación, favor contactarse con soporte TCS');", true);

                throw ex;
            }
        }

        private void EntornoTipoMovimiento(int tipo)
        {
            switch (tipo)
            {
                case 1: //Recepcion
                    DP_TipoEntidadDespacho.Enabled = true;
                    DP_EntidadDespacho.Enabled = true;
                    DP_TipoEntidadRecepcion.Enabled = false;
                    DP_EntidadRecepcion.Enabled = false;
                    break;
                case 2: //Despacho
                    DP_TipoEntidadDespacho.Enabled = false;
                    DP_EntidadDespacho.Enabled = false;
                    DP_TipoEntidadRecepcion.Enabled = true;
                    DP_EntidadRecepcion.Enabled = true;
                    break;
                default:
                    DP_TipoEntidadDespacho.Enabled = true;
                    DP_EntidadDespacho.Enabled = true;
                    DP_TipoEntidadRecepcion.Enabled = true;
                    DP_EntidadRecepcion.Enabled = true;

                    DP_TipoEntidadRecepcion.ClearSelection();
                    DP_EntidadRecepcion.ClearSelection();
                    DP_TipoEntidadDespacho.ClearSelection();
                    DP_EntidadDespacho.ClearSelection();
                    break;
            }
        }

        private void Contexto_Visualizar(string tipo_accion)
        {
            switch (tipo_accion)
            {
                case ContextoVisual.ACCION_BUSCAR: //Buscar, se carga al inicio de la página
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = false;
                    //BtnModificar.Enabled = false;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "buscar";
                    break;
                case ContextoVisual.ACCION_INGRESAR: //Si el registro no existe habilita opcion de guardar
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = false;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "guardar";
                    break;
                case ContextoVisual.ACCION_MODIFICAR: //Si el registro existe habilita opciones de guardar o eliminar
                    BtnBuscar.Enabled = true;
                    BtnGuardar.Enabled = true;
                    //BtnModificar.Enabled = true;
                    BtnLimpiar.Enabled = true;
                    HDAccion.Value = "modificar";
                    break;
                default:                            // se pone en caso de que ningun case cumpla la evaluación
                    break;
            }
        }

        private int CalculaTotalCajas()
        {
            int TotalCajas = 0;

            TotalCajas = Convert.ToInt16(TxtTotalContenedorCajasCurso.Text) + Convert.ToInt16(TxtTotalContenedorCapacitacion.Text) + Convert.ToInt16(TxtTotalContenedorComplementario.Text) + Convert.ToInt16(TxtTotalContenedorPetos.Text);

            return TotalCajas;
        }

        private void Limpiar()
        {
            TxtTotalPallets.Text = "";
            TxtTotalContenedorCapacitacion.Text = "";
            TxtTotalContenedorComplementario.Text = "";
            TxtTotalContenedorCajasCurso.Text = "";
            TxtTotalContenedorPetos.Text = "";
            TxtNumeroOrdenPreparado.Text = "";

            TxtTotalContenedor.Text = "";
            LblEstadoGuiaDespacho.Text = "";
            HDAccion.Value = "";
            HDIdGuiaDespacho.Value = "";
            HDNGuiaDespacho.Value = "";
            HDPasaPorOrdenPreparado.Value = "false";
            HDNumeroOrdenPreparado.Value = "";

            Contexto_Visualizar("Buscar");
        }

        private Boolean CargarUsuario()
        {
            UsuarioEN usuarioEN = new UsuarioEN();
            IUsuarioBLL usuarioBLL = new UsuarioBLL();

            usuarioEN = usuarioBLL.Buscar(User.Identity.Name);

            if (usuarioEN == null)
            {
                Session["ErrorLogin"] = "Usuario no configurado en sistema";
                return false;
            }

            TxtRutRecepcionista_Despachador.Text = usuarioEN.RutUsuario;
            TxtDvRecepcionista_Despachador.Text = usuarioEN.DvUsuario;
            TxtNombreRecepcionista_Despachador.Text = usuarioEN.NombreUsuario;

            return true;
        }

        protected string RetornaFormaIngresoCodigos()
        {
            IMovimientoContenedorDetalleBLL movimientoContenedorDetalleBLL = new MovimientoContenedorDetalleBLL();
            string FormaIngresoCodigos = movimientoContenedorDetalleBLL.RetornaParametrosGenerales(1);
            return FormaIngresoCodigos;
        }
    }
}