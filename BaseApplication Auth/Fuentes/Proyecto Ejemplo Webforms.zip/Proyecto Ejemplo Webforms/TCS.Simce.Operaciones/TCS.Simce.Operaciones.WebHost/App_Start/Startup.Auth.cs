﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.Membership.OpenAuth;
using Owin;

namespace SimceOperaciones
{
    public partial class Startup : TCS.Simce.Core.Security.Auth.Startup
    {
        // For more information on configuring authentication, please visit http://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            base.ConfigureAuth(app);
        }
    }
}