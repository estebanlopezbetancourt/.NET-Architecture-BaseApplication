﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(SimceOperaciones.Startup))]
namespace SimceOperaciones
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
