﻿using System;

namespace TCS.Simce.Operaciones.EN.Picking
{
    public class SubCentroEN
    {
        public Int64 IdSubCentro { get; set; }
        public string SubCentro { get; set; }
    }
}
