﻿using System;

namespace TCS.Simce.Operaciones.EN.Picking
{
    public class OrdenPreparadoEN
    {
        public Int64 idMCR { get; set; }
        public Int64 estadoGuiaDespacho { get; set; }
    }
}
