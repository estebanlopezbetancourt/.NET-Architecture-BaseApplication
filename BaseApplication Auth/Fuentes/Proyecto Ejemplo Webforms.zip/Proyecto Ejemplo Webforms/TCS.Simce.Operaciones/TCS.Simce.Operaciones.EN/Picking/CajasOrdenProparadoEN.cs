﻿using System;

namespace TCS.Simce.Operaciones.EN.Picking
{
    public class CajasOrdenProparadoEN
    {
        public Int64 IdRegistro { get; set; }
        public Int64 IdTipoMaterial { get; set; }
        public string TipoMaterial { get; set; }
        public Int64 Gs1 { get; set; }
        public Int64 IdEstadoRecepcion { get; set; }
        public string EstadoRecepcion { get; set; }
    }
}
