﻿
namespace TCS.Simce.Operaciones.EN.Logging
{

    public enum LogLevel
    {
        Trace,
        Debug,
        Info,
        Warning,
        Error,
        Fatal
    }
}
