﻿using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class InformeCuadraturaCajasImprentaEN
    {
        [Display(Name = "Imprenta")]
        public string entidadImprenta { get; set; }

        [Display(Name = "Tipo Material")]
        public string tipoMaterial { get; set; }

        [Display(Name = "Nivel")]
        public string nivel { get; set; }

        [Display(Name = "Tipo Prueba")]
        public string tipoPrueba { get; set; }

        [Display(Name = "Centro Operacion")]
        public string COPrincipal { get; set; }

        [Display(Name = "Cantidad Esperada")]
        public string cantidadEsperada { get; set; }

        [Display(Name = "Cantidad Recepcionada")]
        public string cantidadRecepcionada { get; set; }

        [Display(Name = "Diferencia")]
        public string diferencia { get; set; }

        [Display(Name = "% Recepcionado")]
        public string porcentajeRecepcion { get; set; }

       /* [Display(Name = "Estado Cuadratura")]
        public string estadoCuadratura { get; set; }
          public int totalCantidadEsperada { get; set; }
          public int totalCantidadRecepcionada { get; set; }
          public int totalDiferencia { get; set; }
          public float totalPorcentajeRecepcion { get; set; }*/
    }
}
