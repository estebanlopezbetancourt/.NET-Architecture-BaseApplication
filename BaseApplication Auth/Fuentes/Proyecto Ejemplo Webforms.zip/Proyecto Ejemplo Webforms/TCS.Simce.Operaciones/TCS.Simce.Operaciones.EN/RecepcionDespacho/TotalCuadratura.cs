﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TotalCuadratura
    {
        public Int64 Total { get; set; }
        public Int64 idTipoMaterial { get; set; }
    }
}
