﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class CabeceraEN
    {
        public string Titulo { get; set; }
        public string Valor { get; set; }
    }
}