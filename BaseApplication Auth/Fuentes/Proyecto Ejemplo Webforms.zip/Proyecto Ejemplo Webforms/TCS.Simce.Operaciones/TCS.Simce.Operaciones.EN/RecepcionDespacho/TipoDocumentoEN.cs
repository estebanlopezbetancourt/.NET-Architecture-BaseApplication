﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TipoDocumentoEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
