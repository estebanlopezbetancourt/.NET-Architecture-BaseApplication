﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class EntidadImprentaEN
    {

        public Int64 Id { get; set; }
        public string Descripcion { get; set; }
    }
}
