﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class ContenedorEN
    {
        public Int64 idContenedor { get; set; }
        public int idSubCentro { get; set; }
        [Display(Name = "Sub Centro Destino")]
        public string SubcentroDescripcion { get; set; }
        public int idNivel { get; set; }
        [Display(Name = "Nivel")]
        public string NivelDescripcion { get; set; }
        public int idTipoPrueba { get; set; }
        [Display(Name = "Tipo Prueba")]
        public string TipoPruebaDescripcion { get; set; }
        public int? idUbicacionCOPrincipal { get; set; }
        [Display(Name = "Ubicación Física")]
        public string UbicacionDescripcion { get; set; }
        public int idTipoMaterial { get; set; }
        [Display(Name = "Tipo Material")]
        public string TipoMaterialDescripcion { get; set; }

        [Display(Name = "Id Caja")]
        public int identificacionContenedorGs1 { get; set; }
        public Int64 estadoBDSimce { get; set; }
    }

    public class ContenedorENForExcel
    {
        [Display(Name = "Sub Centro Destino")]
        public string SubcentroDescripcion { get; set; }
        [Display(Name = "Nivel")]
        public string NivelDescripcion { get; set; }
        [Display(Name = "Tipo Prueba")]
        public string TipoPruebaDescripcion { get; set; }
        [Display(Name = "Ubicación Física")]
        public string UbicacionDescripcion { get; set; }
        [Display(Name = "Tipo Material")]
        public string TipoMaterialDescripcion { get; set; }

        [Display(Name = "Id Caja")]
        public int identificacionContenedorGs1 { get; set; }
    }
}
