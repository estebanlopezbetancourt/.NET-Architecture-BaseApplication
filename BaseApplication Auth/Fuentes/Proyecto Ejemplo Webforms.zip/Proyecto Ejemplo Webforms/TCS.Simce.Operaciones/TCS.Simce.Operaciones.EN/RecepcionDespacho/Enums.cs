﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class Enums
    {
        public enum TipoDocumentoDespacho
        {
            GuíaDespacho = 1,
            OrdenPreparado = 2,
            PackingDespacho = 3
        }

        public enum EstadoGuiaDespacho
        {
            DocumentoDescuadrado = 1,
            DocumentoCuadrado = 2
        }

        public enum TipoMovimiento
        {
            Recepcion = 1,
            Despacho = 2
        }
    }
}
