﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TipoMovimientoEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
