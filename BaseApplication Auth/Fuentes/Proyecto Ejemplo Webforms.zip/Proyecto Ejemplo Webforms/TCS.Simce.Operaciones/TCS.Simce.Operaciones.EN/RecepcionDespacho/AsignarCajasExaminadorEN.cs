﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class AsignarCajasExaminadorEN
    {
        public Int64 idMPD { get; set; }
        public Int64 idMPR { get; set; }
        public Int64 rut { get; set; }
        public Int64 numeroDocumento { get; set; }
        public Int64 Gs1 { get; set; }
        public string idUsuario { get; set; }
        public int tipoPersona { get; set; }
        public int idEntidadCustodio { get; set; }
    }
}
