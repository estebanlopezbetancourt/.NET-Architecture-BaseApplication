﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class OrdenDespachoEN
    {
        public long numeroPalletTCS { get; set; }
        public Int64 idTipoMaterial { get; set; }
        public string TipoMaterial { get; set; }
        public Int64 identificacionContenedorGs1 { get; set; }
        public Int64 idTipoDistribucion { get; set; }
        public string TipoDistribucion { get; set; }
        public Int64 idNivel { get; set; }
        public string Nivel { get; set; }
        public Int64 idTipoPrueba { get; set; }
        public string TipoPrueba { get; set; }
        public Int64 dia { get; set; }
        public Int64 serieCajaCurso { get; set; }
    }
}
