﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class ReporteRecepcionDespachoSupervisoresDetalleEN
    {     
        
        [Display(Name = "Nivel")]
        public string Nivel { get; set; }

       
        
        [Display(Name = "Tipo Prueba")]
        public string TipoPrueba { get; set; }

        [Display(Name = "Sub Centro")]
        public string SubCentro { get; set; }
        

        [Display(Name = "Supervisor")]
        public string Supervisor { get; set; }

        [Display(Name = "Id Caja")]
        public string idcaja { get; set; }

        [Display(Name = "Enviados")]
        public Int64 cantidadDespachada { get; set; }

        [Display(Name = "Recibidos")]
        public Int64 cantidadRecepcionada { get; set; }

        [Display(Name = "Diferencia")]
        public Int64 Diferencia { get; set; }

        //[Display(Name = "Total Enviados")]
        //public Int64 totalEnviados { get; set; }


        //[Display(Name = "Total Recibidos")]
        //public Int64 totalRecibidos { get; set; }

        //[Display(Name = "Total Diferencia")]
        //public Int64 totalDiferencia { get; set; }       
    }
}
