﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TipoInformeEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
