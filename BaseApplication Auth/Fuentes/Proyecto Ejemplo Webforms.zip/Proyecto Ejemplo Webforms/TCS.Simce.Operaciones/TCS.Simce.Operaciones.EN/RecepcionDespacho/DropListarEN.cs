﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class DropListarEN
    {
        public Int64 Codigo { get; set; }
        public string Descripcion { get; set; }
    }
}
