﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class AsignarCajasEN
    {
        public DateTime fechaMPR { get; set; }
        public Int64 idTipoDocumento { get; set; }
        public Int64 idTipoMovimiento { get; set; }
        public Int64 idTipoEntidadDespacho { get; set; }
        public Int64 idEntidadDespacho { get; set; }
        public Int64 idTipoEntidadRecepcion { get; set; }
        public Int64 idEntidadRecepcion { get; set; }
        public Int64 numeroDocumento { get; set; }
        public Int64 rut { get; set; }
        public string idUsuario { get; set; }
        public int tipoPersona { get; set; }
       
    }
}
