﻿
namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class CargarArchivoMovimientoContenedorDetalleEN
    {
        public int tipoDocumentoDespacho { get; set; }
        public long numeroDocumentoDespacho { get; set; }
        public int tipoMovimiento { get; set; }
        public int idEntidadOrigen { get; set; }
        public int IdEntidadDestino { get; set; }
        public long numeroPalletImprenta { get; set; }
        public int idTipoMaterial { get; set; }
        public long GS1 { get; set; }
        public string idUsuarioCreacionRegistro { get; set; }
    }
}
