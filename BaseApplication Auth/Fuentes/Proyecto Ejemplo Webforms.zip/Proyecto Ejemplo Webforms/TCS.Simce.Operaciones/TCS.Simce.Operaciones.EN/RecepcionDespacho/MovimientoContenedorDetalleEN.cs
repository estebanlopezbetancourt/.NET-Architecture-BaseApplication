﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class MovimientoContenedorDetalleEN
    {
        public Int64 idMCD { get; set; }
        public Int64 idMCR { get; set; }
        public Int64 idPallet { get; set; }
        public Int64 numeroPalletImprenta { get; set; }
        public Int64 idContenedor { get; set; }
        public Int64 idTipoMaterial { get; set; }
        public string descripcionTipoMaterial { get; set; }
        public long identificacionContenedorGs1 { get; set; }
        public int idTipoDistribucion { get; set; }
        public int idNivel { get; set; }
        public int idTipoPrueba { get; set; }
        public int dia { get; set; }
        public long serieCajaCurso { get; set; }
        public Int64 idEstadoRecepcion { get; set; }
        public string descripcionEstadoRecepcion { get; set; }
        public Int64 estadoBDSimce { get; set; }
    }
}
