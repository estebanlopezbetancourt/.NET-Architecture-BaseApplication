﻿using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class ResumenCuadraturaGuiaEN
    {
        [Display(Name = "Fecha Movimiento")]
        public string FechaMovimiento { get; set; }

        [Display(Name = "Tipo Documento")]
        public string TipoDocumento { get; set; }

        [Display(Name = "Tipo Movimiento")]
        public string TipoMovimiento { get; set; }

        [Display(Name = "Tipo Entidad Despacho")]
        public string TipoEntidadDespacho { get; set; }

        [Display(Name = "Entidad Despacho")]
        public string EntidadDespacho { get; set; }

        [Display(Name = "Tipo Entidad Recepcion")]
        public string TipoEntidadRecepcion { get; set; }

        [Display(Name = "Entidad Recepcion")]
        public string EntidadRecepcion { get; set; }

        [Display(Name = "Numero Documento Despacho")]
        public int NumeroDocumentoDespacho { get; set; }

      /*  [Display(Name = "Numero Pallet Imprenta")]
        public int NumeroPalletImprenta { get; set; }*/

        [Display(Name = "Numero Pallet")]
        public int NumeroPalletTCS { get; set; }

        [Display(Name = "Tipo Material")]
        public string TipoMaterial { get; set; }

        [Display(Name = "Id Caja")]
        public int IdentificadorCaja { get; set; }

        [Display(Name = "Estado Recepcion")]
        public string EstadoRecepcion { get; set; }

    }
}
