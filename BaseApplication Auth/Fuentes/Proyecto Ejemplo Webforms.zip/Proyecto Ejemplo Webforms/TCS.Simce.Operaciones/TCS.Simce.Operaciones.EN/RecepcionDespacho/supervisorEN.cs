﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class supervisorEN
    {
        public Int64 Id { get; set; }
        public string nombre { get; set; }
    }
}
