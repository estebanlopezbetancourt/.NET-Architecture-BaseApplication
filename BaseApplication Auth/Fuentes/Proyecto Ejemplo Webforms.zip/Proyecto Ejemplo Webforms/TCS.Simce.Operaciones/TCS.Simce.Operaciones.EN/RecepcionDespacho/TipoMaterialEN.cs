﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TipoMaterialEN
    {
        public Int64 Id { get; set; }
        public string Descripcion { get; set; }
    }
}
