﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class GuiaDespachoEN
    {
        public long idMCR { get; set; }
        public int tipoDocumentoDespacho { get; set; }
        public DateTime fechaMovimientoMCR { get; set; }
        public long numeroGuiaDespacho { get; set; }
        public Int64 totalPallets { get; set; }
        public Int64 totalContenedorCapacitacion { get; set; }
        public Int64 totalContenedorComplementario { get; set; }
        public Int64 totalContenedorCajasCurso { get; set; }
        public Int64 totalContenedorPetos { get; set; }
        public Int64 tipoMovimiento { get; set; }
        public Int64 totalContenedor { get; set; }
        public Int64 RutUsuarioMovimiento { get; set; }
        public string dvRutUsuarioMovimiento { get; set; }
		public string NombreUsuarioMovimiento { get; set; }
        public Int64 tipoEntidadOrigen { get; set; }
        public Int64 idEntidadOrigen { get; set; }
        public Int64 tipoEntidadDestino { get; set; }
        public Int64 IdEntidadDestino { get; set; }
        public Int64 estadoGuiaDespacho { get; set; }
        public string desripcionEstadoGuiaDespacho { get; set; }
        public string idUsuarioCreacionRegistro { get; set; }
        public string idUsuarioModificacionRegistro { get; set; }
    }
}
