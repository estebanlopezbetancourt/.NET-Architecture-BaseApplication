﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class AsignarCajasTipoPersonaEN
    {
        public Int64 tipoPersona { get; set; }

        public String nombre { get; set; }
    }
}
