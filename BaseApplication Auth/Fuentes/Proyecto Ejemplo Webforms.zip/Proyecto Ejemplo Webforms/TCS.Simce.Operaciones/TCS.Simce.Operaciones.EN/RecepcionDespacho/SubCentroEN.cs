﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class SubCentroEN
    {
        public Int64 Id { get; set; }
        public string Descripcion { get; set; }
    }
}
