﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class AsignarCajasPackingListEN
    {
        public Int64 numeroDocumento { get; set; }
        public Int64 idMPR { get; set; }
    }
}
