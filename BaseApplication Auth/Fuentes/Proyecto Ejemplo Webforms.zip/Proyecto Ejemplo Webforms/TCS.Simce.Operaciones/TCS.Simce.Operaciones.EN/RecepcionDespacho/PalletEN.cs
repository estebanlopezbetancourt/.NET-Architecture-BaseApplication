﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class PalletEN
    {
        public Int64 idPallet { get; set; }
        public Int64 numeroPalletTCS { get; set; }
        public Int64 idTipoEntidadCustodio { get; set; }
        public Int64 idEntidadCustodio { get; set; }
        public int idEstadoRecepcionEntidadCustodio { get; set; }
        public DateTime fechaRecepcionEntidadCustodio { get; set; }
        public int idUbicacionCOPrincipal { get; set; }

    }
}
