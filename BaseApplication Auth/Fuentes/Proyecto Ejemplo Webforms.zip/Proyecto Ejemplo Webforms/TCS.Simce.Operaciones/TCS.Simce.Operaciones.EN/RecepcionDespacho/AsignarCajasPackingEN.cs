﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class AsignarCajasPackingEN
    {
       // public DateTime fechaMPR { get; set; }       
        //public Int64 numeroDocumento { get; set; }
       // public Int64 rutSupervisor { get; set; }
       // public String nombreSupervisor { get; set; }
        
        
        
        
        
        
        
        
        
        [Display(Name = "Id Caja")]
        public Int64 idCaja { get; set; }
        
        [Display(Name = "Rut Examinador")]
        public String rutExaminador { get; set; }
        
        [Display(Name = "Nombre Examinador")]
        public String nombreExaminador { get; set; }         
        
         [Display(Name = "Firma Examinador")]
        public String firma { get; set; }
    }
}
