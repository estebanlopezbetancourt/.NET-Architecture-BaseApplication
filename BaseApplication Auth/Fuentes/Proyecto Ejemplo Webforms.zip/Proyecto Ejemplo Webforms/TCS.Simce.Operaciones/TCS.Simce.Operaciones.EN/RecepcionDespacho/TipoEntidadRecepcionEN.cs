﻿using System;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class TipoEntidadRecepcionEN
    {
        public Int64 Id { get; set; }
        public string Descripcion { get; set; }
    }
}
