﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.RecepcionDespacho
{
    public class ReporteRecepcionDespachoResumenEN
    {
        [Display(Name = "Nivel")]
        public string Nivel { get; set;  }

        [Display(Name = "Tipo de Prueba")]
        public string TipoPrueba { get; set; }

        [Display(Name = "Sub Centro")]
        public string SubCentro { get; set; }

        [Display(Name = "Enviado")]
        public Int64 cantidadDespachada { get; set; }

        [Display(Name = "Recibido")]
        public Int64 cantidadRecepcionada { get; set; }

        [Display(Name = "Diferencia")]
        public Int64 Diferencia { get; set; }
    }
}
