﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.Aplicacion
{
    public class CursoContenedoresEN
    {
        public int IdCurso { get; set; }
        public int IdNivel { get; set; }
        public int Rbd { get; set; }
        public int SerieCajaCurso { get; set; }
        public string LetraCurso { get; set; }
        public string DvRbd { get; set; }
    }
}
