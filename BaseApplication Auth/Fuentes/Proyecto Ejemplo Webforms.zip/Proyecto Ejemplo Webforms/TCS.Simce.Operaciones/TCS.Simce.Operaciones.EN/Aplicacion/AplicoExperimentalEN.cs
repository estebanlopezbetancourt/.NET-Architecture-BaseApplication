﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.Aplicacion
{
    public class AplicoExperimentalEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }

    public class AplicoVisitaPreviaEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }

    public class AplicoCensalEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }

    public class AplicoSesionComplementariaEN
    {
        public int Id { get; set; }
        public string Descripcion { get; set; }
    }
}
