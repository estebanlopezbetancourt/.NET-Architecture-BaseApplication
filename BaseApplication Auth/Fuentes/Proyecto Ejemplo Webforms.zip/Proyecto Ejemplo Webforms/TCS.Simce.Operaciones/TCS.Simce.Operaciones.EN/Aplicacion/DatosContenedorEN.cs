﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.Aplicacion
{
    public class DatosContenedorEN
    {
        public int IdContenedor { get; set; }
        public int IdTipoDistribucion { get; set; }
        public int IdTipoMaterial { get; set; }
        public int IdNivel { get; set; }
        public int SerieCajaCurso { get; set; }
        public int Dia { get; set; }
        public int SerieDocumentoDesde { get; set; }
        public int SerieDocumentoHasta { get; set; }
        public string LetraCurso { get; set; }
    }
}
