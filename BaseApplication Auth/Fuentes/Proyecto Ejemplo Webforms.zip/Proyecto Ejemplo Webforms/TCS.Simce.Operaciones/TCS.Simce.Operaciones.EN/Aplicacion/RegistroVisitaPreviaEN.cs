﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.Aplicacion
{
    public class RegistroVisitaPreviaEN
    {
        public int idAplicacionAula { get; set; }
        public int idCurso { get; set; }
        public int Rbd { get; set; }
        public string DvRbd { get; set; }
        public int idNivel { get; set; }
        public string Nivel { get; set; }
        public string LetraCurso { get; set; }
        public int SerieCajaCurso { get; set; }
        public DateTime FechaRealizacion { get; set; }
        public int AplicoVisitaPrevia { get; set; }
        public string Observacion { get; set; }
    }
}
