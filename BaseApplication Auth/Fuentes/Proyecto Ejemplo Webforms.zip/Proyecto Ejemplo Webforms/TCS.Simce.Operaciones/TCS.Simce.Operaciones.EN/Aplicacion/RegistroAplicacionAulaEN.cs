﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCS.Simce.Operaciones.EN.Aplicacion
{
    public class RegistroAplicacionAulaEN
    {
        public int idAplicacionAula { get; set; }
        public int idCurso { get; set; }
        public int idContenedorDia1 { get; set; }
        public int idContenedorDia2 { get; set; }
        public int Rbd { get; set; }
        public string DvRbd { get; set; }
        public int idNivel { get; set; }
        public string Nivel { get; set; }
        public string LetraCurso { get; set; }
        public int SerieCajaCurso { get; set; }
        public int CantidadCuestionariosPAEntregados { get; set; }
        public int CantidadCuestionariosPARecibidos { get; set; }
        public int CantidadCuestionariosDocenteEntregados { get; set; }
        public int CantidadCuestionariosDocenteRecibidos { get; set; }
        public int SerieCajaCursoDia1Contingencia { get; set; }
        public int SerieDocumentoDesdeDia1Contingencia { get; set; }
        public int SerieDocumentoHastaDia1Contingencia { get; set; }
        public int SerieCajaCursoDia2Contingencia { get; set; }
        public int SerieDocumentoDesdeDia2Contingencia { get; set; }
        public int SerieDocumentoHastaDia2Contingencia { get; set; }
        public int SerieCajaCursoDia1Retorno { get; set; }
        public int SerieCajaCursoDia2Retorno { get; set; }
        public int AplicoCensal { get; set; }
        public int AplicoExperimental { get; set; }
        public int AplicoSesionComplementaria { get; set; }
        public string Observacion { get; set; }
    }
}
