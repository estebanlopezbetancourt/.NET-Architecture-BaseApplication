﻿
namespace TCS.Simce.Operaciones.EN.Usuario
{
    public class UsuarioEN
    {
        public string RutUsuario { get; set; }
        public string DvUsuario { get; set; }
        public string NombreUsuario { get; set; }

    }
}
