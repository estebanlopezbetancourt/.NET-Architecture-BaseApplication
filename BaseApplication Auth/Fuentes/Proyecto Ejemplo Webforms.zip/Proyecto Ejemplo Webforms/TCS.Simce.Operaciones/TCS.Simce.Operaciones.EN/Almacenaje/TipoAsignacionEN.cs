﻿using System;

namespace TCS.Simce.Operaciones.EN.Almacenaje
{
    public class TipoAsignacionEN
    {
        public Int64 codigo { get; set; }
        public string descripcion { get; set; }
    }
}
