﻿using System;
using System.ComponentModel.DataAnnotations;

namespace TCS.Simce.Operaciones.EN.Almacenaje
{
    public class ConsultarUbicacionEN
    {
        [Display(Name = "Ubicacion Fisica")]
        public string ubicacion { get; set; }
        [Display(Name = "Calle")]
        public string calle { get; set; }
        [Display(Name = "Nicho")]
        public string nicho { get; set; }
        [Display(Name = "Nivel Nicho")]
        public string nivelNicho { get; set; }
        [Display(Name = "Estado Nivel Nicho")]
        public string estado { get; set; }
        [Display(Name = "Numero pallet")]
        public Int64 palletTcs { get; set; }
        [Display(Name = "Id Caja")]
        public Int64 Gs1 { get; set; }
       
    }
}
