﻿using System;

namespace TCS.Simce.Operaciones.EN.Almacenaje
{
    public class AlmacenajeEN
    {
        public Int64 TipoAccion { get; set; }
        public Int64 NumeroPalletTCS { get; set; }
        public string codigoUbicacion { get; set; }
    }
}
