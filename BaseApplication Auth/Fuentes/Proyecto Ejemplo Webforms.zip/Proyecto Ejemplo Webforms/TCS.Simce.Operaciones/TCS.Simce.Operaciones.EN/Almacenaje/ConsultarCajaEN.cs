﻿
namespace TCS.Simce.Operaciones.EN.Almacenaje
{
    public class ConsultarCajaEN
    {      
        public string nivel { get; set; }
        public string tipoPrueba { get; set; }
        public string tipoEntidad { get; set; }
        public string entidad { get; set; }
        public string estadoCaja { get; set; }             
        public string palletTcs { get; set; }
        public string ubicacionFisica { get; set; }
        public string rbd { get; set; }
        public string establecimiento { get; set; }
       
    }
}
