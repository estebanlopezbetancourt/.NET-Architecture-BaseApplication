﻿using TCS.Simce.Operaciones.DAL.Usuario;
using TCS.Simce.Operaciones.EN.Usuario;

namespace TCS.Simce.Operaciones.BLL.Usuario
{
    public class UsuarioBLL : IUsuarioBLL
    {
        public UsuarioEN Buscar(string idUsuario)
        {
            IUsuarioDAL UsuarioDAL = new UsuarioDAL();
            UsuarioEN usuarioEN = UsuarioDAL.Buscar(idUsuario);
            return usuarioEN;
        }
    }
}
