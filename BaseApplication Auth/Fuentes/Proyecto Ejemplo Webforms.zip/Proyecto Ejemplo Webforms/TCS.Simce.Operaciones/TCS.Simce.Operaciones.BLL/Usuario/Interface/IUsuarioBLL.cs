﻿using TCS.Simce.Operaciones.EN.Usuario;

namespace TCS.Simce.Operaciones.BLL.Usuario
{
    public interface IUsuarioBLL
    {
        UsuarioEN Buscar(string idUsuario);
    }
}
