﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class EntidadImprentaBLL:IEntidadImprentaBLL
    {
        public List<EntidadImprentaEN> Listar()
        {
            List<EntidadImprentaEN> listado = new List<EntidadImprentaEN>();
            IEntidadImprentaDAL EntidadImprentaDAL = new EntidadImprentaDAL();
            listado = EntidadImprentaDAL.Listar();
            return listado;
        }
    }
}
