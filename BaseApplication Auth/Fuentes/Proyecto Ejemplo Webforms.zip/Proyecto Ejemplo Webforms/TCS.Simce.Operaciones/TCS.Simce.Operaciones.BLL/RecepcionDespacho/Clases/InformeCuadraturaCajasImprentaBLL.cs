﻿using System.Collections.Generic;
//MY NAME SPACES
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class InformeCuadraturaCajasImprentaBLL : IInformeCuadraturaCajasImprentaBLL 
    {
        public List<InformeCuadraturaCajasImprentaEN> informeCuadraturaCajasImprentaLista(int imprenta, int tipoMaterial, int tipoPrueba, int nivel)
         {
             List<InformeCuadraturaCajasImprentaEN> listado = new List<InformeCuadraturaCajasImprentaEN>();
             IInformeCuadraturaCajasImprentaDAL informeCuadraturaCajasImprentaDAL = new InformeCuadraturaCajasImprentaDAL();
             listado=informeCuadraturaCajasImprentaDAL.informeCuadraturaCajasImprentaLista(imprenta, tipoMaterial, tipoPrueba, nivel);
             return listado;
         }
    }
}
