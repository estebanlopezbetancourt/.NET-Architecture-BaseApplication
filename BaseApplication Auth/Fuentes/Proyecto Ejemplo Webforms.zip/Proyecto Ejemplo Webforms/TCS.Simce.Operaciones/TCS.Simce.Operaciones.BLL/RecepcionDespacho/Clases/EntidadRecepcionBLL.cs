﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class EntidadRecepcionBLL : IEntidadRecepcionBLL
    {
        public List<EntidadRecepcionEN> Listar(int tipoEntidad)
        {
            IEntidadRecepcionDAL entidadRecepcionDAL = new EntidadRecepcionDAL();
            List<EntidadRecepcionEN> listado = entidadRecepcionDAL.Listar(tipoEntidad);

            return listado;
        }

        public ArrayList Listado(int tipoEntidad)
        {
            IEntidadRecepcionDAL entidadRecepcionDAL = new EntidadRecepcionDAL();
            ArrayList listado = entidadRecepcionDAL.Listado(tipoEntidad);

            return listado;
        }
    }
}
