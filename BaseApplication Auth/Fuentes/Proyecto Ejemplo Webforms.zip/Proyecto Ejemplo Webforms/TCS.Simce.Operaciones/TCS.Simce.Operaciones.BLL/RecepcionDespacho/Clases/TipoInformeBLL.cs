﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class TipoInformeBLL : ITipoInformeBLL
    {
        public List<TipoInformeEN> Listar()
        {

            List<TipoInformeEN> listado = new List<TipoInformeEN>();

            ITipoInformeDAL tipoInformeDAL = new TipoInformeDAL();

            listado = tipoInformeDAL.Listar();

            return listado;

        }
    }
}
