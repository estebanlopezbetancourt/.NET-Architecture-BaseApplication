﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class SupervisorBLL:ISupervisorBLL
    {
        public List<supervisorEN> Listar(int idSubCentro)
        {
            List<supervisorEN> listado = new List<supervisorEN>();
            ISupervisorDAL SupervisorDAL = new SupervisorDAL();
            listado = SupervisorDAL.Listar(idSubCentro);
            return listado;
        }
    }
}
