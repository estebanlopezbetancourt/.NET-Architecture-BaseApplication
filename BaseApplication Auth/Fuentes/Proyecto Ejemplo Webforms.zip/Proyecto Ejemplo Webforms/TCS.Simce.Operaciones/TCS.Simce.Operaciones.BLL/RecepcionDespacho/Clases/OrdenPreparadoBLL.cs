﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class OrdenPreparadoBLL
    {

        public IList<ContenedorEN> BuscarContenedor(int IdTipoMaterial, int IdSubCentro, int IdNivel)
        {
            return new ContenedorDAL().Buscar(IdTipoMaterial, IdSubCentro, IdNivel);
        }

        public int EnviarAPreparar(int IdSubCentroDestino, int IdTipoMaterial, string RutUsuario, int IdNivel)
        {
            return new ContenedorDAL().EnviarAPreparar(IdSubCentroDestino, IdTipoMaterial, RutUsuario, IdNivel);
        }
    }
}
