﻿using System;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class PalletBLL : IPalletBLL
    {
        public PalletEN Buscar(Int64 numeroPalletTCS, Int64 idMCR, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio, string idUsuarioCreacionRegistro, Int64 idEstadoRecepcionEntidadCustodio, Int64 idUbicacionCOPrincipal)
        {
            IPalletDAL PalletDAL = new PalletDAL();

            PalletEN palletEN = PalletDAL.Buscar(numeroPalletTCS, idMCR, idTipoEntidadCustodio, idEntidadCustodio, idUsuarioCreacionRegistro, idEstadoRecepcionEntidadCustodio, idUbicacionCOPrincipal);
            return palletEN;
        }

        public void DespachoCerrarPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            IPalletDAL PalletDAL = new PalletDAL();
            PalletDAL.DespachoCerrarPallet(idMCR, idPallet, idUsuarioCreacionRegistro);
        }

        public void DespachoCerrarMovimientoPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            IPalletDAL PalletDAL = new PalletDAL();
            PalletDAL.DespachoCerrarMovimientoPallet(idMCR, idPallet, idUsuarioCreacionRegistro);
        }

        public PalletEN BuscarParaDespacho(Int64 numeroPalletTCS, Int64 idMCR)
        {
            IPalletDAL PalletDAL = new PalletDAL();

            PalletEN palletEN = PalletDAL.BuscarParaDespacho(numeroPalletTCS, idMCR);
            return palletEN;
        }

        public void CerrarPalletDesdeSubCentro(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            IPalletDAL PalletDAL = new PalletDAL();
            PalletDAL.CerrarPalletDesdeSubCentro(idMCR, idPallet, idUsuarioCreacionRegistro);
        }
    }
}
