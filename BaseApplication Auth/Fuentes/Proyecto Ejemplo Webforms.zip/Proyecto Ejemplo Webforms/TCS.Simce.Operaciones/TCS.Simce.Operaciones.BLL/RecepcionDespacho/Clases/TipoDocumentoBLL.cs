﻿using System;
using System.Collections.Generic;
using System.Linq;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class TipoDocumentoBLL : ITipoDocumentoBLL
    {
        public List<TipoDocumentoEN> Listar()
        {
            List<TipoDocumentoEN> listado = new List<TipoDocumentoEN>();

            //TipoDocumentoEN tipoDocumentoEN0 = new TipoDocumentoEN();
            //tipoDocumentoEN0.Id = 0;
            //tipoDocumentoEN0.Descripcion = "Seleccionar";
            //listado.Add(tipoDocumentoEN0);

            var values = from Enum e in Enum.GetValues(typeof(Enums.TipoDocumentoDespacho))
                         select new { ID = e, Name = e.ToString() };

            foreach (var value in values)
            {
                TipoDocumentoEN tipoDocumento = new TipoDocumentoEN();
                tipoDocumento.Id = Convert.ToInt32(value.ID);
                tipoDocumento.Descripcion = value.Name;

                listado.Add(tipoDocumento);
            }

            return listado;
        }
    }
}
