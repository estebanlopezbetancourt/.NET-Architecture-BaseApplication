﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class MovimientoContenedorDetalleBLL : IMovimientoContenedorDetalleBLL
    {
        public List<MovimientoContenedorDetalleEN> ListarPorIdPallet(Int64 IdPallet)
        {
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            List<MovimientoContenedorDetalleEN> movimientoContenedorDetalleEN = movimientoContenedorDetalleDAL.ListarPorIdPallet(IdPallet);
            return movimientoContenedorDetalleEN;

        }

        public ContenedorEN ContenedorActualizaRecepcionCaja(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            ContenedorEN contenedorEN = new ContenedorEN();

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            contenedorEN = movimientoContenedorDetalleDAL.ContenedorActualizaRecepcionCaja(idTipoDistribucion, Nivel, TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1), idTipoMaterial, IdPallet, IdUsuario, idTipoEntidadCustodio, idEntidadCustodio);

            return contenedorEN;
                 
        }

        public void MovimientoContenedorActualizaRecepcionCaja(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            movimientoContenedorDetalleDAL.MovimientoContenedorActualizaRecepcionCaja(idMCR, idContenedor, idTipoDistribucion, Nivel, 
                                                                                      TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1),
                                                                                      idTipoMaterial, IdPallet, estadoBDSimce, IdUsuario);
        }

        public void MovimientoContenedorActualizaRecepcionCajaSubCentro(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            movimientoContenedorDetalleDAL.MovimientoContenedorActualizaRecepcionCajaSubCentro(idMCR, idContenedor, idTipoDistribucion, Nivel,
                                                                                      TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1),
                                                                                      idTipoMaterial, IdPallet, estadoBDSimce, IdUsuario);
        }

        public void CargaArchivoDocumentoDespacho(List<CargarArchivoMovimientoContenedorDetalleEN> Lista)
        {
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            movimientoContenedorDetalleDAL.CargaArchivoDocumentoDespacho(Lista);
        }

        public void QuitarCajaDePallet(Int64 idMCD, string idUsuario)
        {

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            movimientoContenedorDetalleDAL.QuitarCajaDePallet(idMCD, idUsuario);
        }

        public void FinalizarGuiaDespacho(Int64 idGuia, string idUsuario) 
        {

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            movimientoContenedorDetalleDAL.FinalizarGuiaDespacho(idGuia, idUsuario);
        }

        public void FinalizarPallet(Int64 idPallet, string idUsuario)
        {
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            movimientoContenedorDetalleDAL.FinalizarPallet(idPallet, idUsuario);
        }

        public Int64 RetornaCantidadPalletRecepcionados(Int64 IdGuia)
        {
            Int64 CantidadPalletRecepcionados = 0;

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            CantidadPalletRecepcionados = movimientoContenedorDetalleDAL.RetornaCantidadPalletRecepcionados(IdGuia);
            return CantidadPalletRecepcionados;
        }

        public List<TotalCuadratura> RetornaTotalCuadratura(Int64 idGuia)
        {
            List<TotalCuadratura> TotalCuadratura = new List<TotalCuadratura>();
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            TotalCuadratura = movimientoContenedorDetalleDAL.RetornaTotalCuadratura(idGuia);

            return TotalCuadratura;
        }

        public string RetornaParametrosGenerales(Int64 codigo)
        {
            string valor = string.Empty;

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            valor = movimientoContenedorDetalleDAL.RetornaParametrosGenerales(codigo);
            return valor;
        }

        public void DespachoCerrarCaja(Int64 idMCR, Int64 idPallet, Int64 idContenedorGs1, string idUsuarioCreacionRegistro)
        {
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            movimientoContenedorDetalleDAL.DespachoCerrarCaja(idMCR, idPallet, idContenedorGs1, idUsuarioCreacionRegistro);
        }

        public Boolean DespachoValidaCajaEnPallet(Int64 idMCR, Int64 idPallet, Int64 identificadorContenedorGs1)
        {
            Boolean ValidaCajaEnPallet = false;

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            ValidaCajaEnPallet = movimientoContenedorDetalleDAL.DespachoValidaCajaEnPallet(idMCR, idPallet, identificadorContenedorGs1);
            return ValidaCajaEnPallet;
        }

        public List<TotalCuadratura> RetornaTotalCuadraturaEnDespacho(Int64 idGuia)
        {
            List<TotalCuadratura> TotalCuadratura = new List<TotalCuadratura>();
            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            TotalCuadratura = movimientoContenedorDetalleDAL.RetornaTotalCuadraturaEnDespacho(idGuia);

            return TotalCuadratura;
        }

        public Int64 RetornaCantidadPalletDespachados(Int64 IdGuia)
        {
            Int64 CantidadPalletDespachados = 0;

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();
            CantidadPalletDespachados = movimientoContenedorDetalleDAL.RetornaCantidadPalletDespachados(IdGuia);
            return CantidadPalletDespachados;
        }

        public ContenedorEN ContenedorActualizaDespachoCaja(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            ContenedorEN contenedorEN = new ContenedorEN();

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            contenedorEN = movimientoContenedorDetalleDAL.ContenedorActualizaDespachoCaja(idTipoDistribucion, Nivel, TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1), idTipoMaterial, IdPallet, IdUsuario, idTipoEntidadCustodio, idEntidadCustodio);

            return contenedorEN;

        }

        public void MovimientoContenedorActualizaDespachoCaja(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            movimientoContenedorDetalleDAL.MovimientoContenedorActualizaDespachoCaja(idMCR, idContenedor, idTipoDistribucion, Nivel,
                                                                                      TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1),
                                                                                      idTipoMaterial, IdPallet, estadoBDSimce, IdUsuario);
        }



        public ContenedorEN ContenedorActualizaRecepcionCajaDesdeSubCentro(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            ContenedorEN contenedorEN = new ContenedorEN();

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            contenedorEN = movimientoContenedorDetalleDAL.ContenedorActualizaRecepcionCajaDesdeSubCentro(idTipoDistribucion, Nivel, TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1), idTipoMaterial, IdPallet, IdUsuario, idTipoEntidadCustodio, idEntidadCustodio);

            return contenedorEN;

        }

        public void MovimientoContenedorActualizaRecepcionCajaDesdeSubCentro(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario)
        {
            Int64 idTipoDistribucion = Convert.ToInt64(Gs1.Substring(0, 1));
            Int64 Nivel = Convert.ToInt64(Gs1.Substring(1, 1));
            Int64 TipoPrueba = Convert.ToInt64(Gs1.Substring(2, 1));
            Int64 Dia = Convert.ToInt64(Gs1.Substring(3, 1));
            Int64 SerieCajaCurso = Convert.ToInt64(Gs1.Substring(4, 5));

            IMovimientoContenedorDetalleDAL movimientoContenedorDetalleDAL = new MovimientoContenedorDetalleDAL();

            movimientoContenedorDetalleDAL.MovimientoContenedorActualizaRecepcionCajaDesdeSubCentro(idMCR, idContenedor, idTipoDistribucion, Nivel,
                                                                                      TipoPrueba, Dia, SerieCajaCurso, Convert.ToInt64(Gs1),
                                                                                      idTipoMaterial, IdPallet, estadoBDSimce, IdUsuario);
        }
    }
}
