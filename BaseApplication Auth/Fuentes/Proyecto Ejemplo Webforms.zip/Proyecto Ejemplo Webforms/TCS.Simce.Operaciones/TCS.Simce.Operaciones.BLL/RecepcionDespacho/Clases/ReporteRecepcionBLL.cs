﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class ReporteRecepcionBLL : IReporteRecepcionBLL
    {
        public List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumen(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            List<ReporteRecepcionDespachoResumenEN> listado = new List<ReporteRecepcionDespachoResumenEN>();
            IReporteRecepcionDAL reporteRecepcionBLL = new ReporteRecepcionDAL();

            listado = reporteRecepcionBLL.ReporteRecepcionDespachoCOPrincipalSubcentroResumen(idNivel, TipoPrueba, idTipoEntidadOrigen, idEntidadOrigen, idTipoEntidadDestino, IdEntidadDestino);
            return listado;

        }

        public List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalle(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            List<ReporteRecepcionDespachoDetalleEN> listado = new List<ReporteRecepcionDespachoDetalleEN>();
            IReporteRecepcionDAL reporteRecepcionBLL = new ReporteRecepcionDAL();

            listado = reporteRecepcionBLL.ReporteRecepcionDespachoCOPrincipalSubcentroDetalle(idNivel, TipoPrueba, idTipoEntidadOrigen, idEntidadOrigen, idTipoEntidadDestino, IdEntidadDestino);
            return listado;

        }

        public List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            List<ReporteRecepcionDespachoResumenEN> listado = new List<ReporteRecepcionDespachoResumenEN>();
            IReporteRecepcionDAL reporteRecepcionBLL = new ReporteRecepcionDAL();

            listado = reporteRecepcionBLL.ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados(idNivel, TipoPrueba, idTipoEntidadOrigen, idEntidadOrigen, idTipoEntidadDestino, IdEntidadDestino);
            return listado;

        }

        public List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            List<ReporteRecepcionDespachoDetalleEN> listado = new List<ReporteRecepcionDespachoDetalleEN>();
            IReporteRecepcionDAL reporteRecepcionBLL = new ReporteRecepcionDAL();

            listado = reporteRecepcionBLL.ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados(idNivel, TipoPrueba, idTipoEntidadOrigen, idEntidadOrigen, idTipoEntidadDestino, IdEntidadDestino);
            return listado;

        }
    }
}
