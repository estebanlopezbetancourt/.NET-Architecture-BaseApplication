﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class TipoEntidadDespachoBLL : ITipoEntidadDespachoBLL
    {
        public List<TipoEntidadDespachoEN> Listar()
        {
            ITipoEntidadDespachoDAL tipoEntidadDespachoDAL = new TipoEntidadDespachoDAL();
            List<TipoEntidadDespachoEN> listado = tipoEntidadDespachoDAL.Listar();

            return listado;
        }
    }
}
