﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class AsignarCajasExaminadorBLL:IAsignarCajasExaminadorBLL
    {
        public void IngresarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador)
        {
            IAsignarCajasExaminadorDAL AsignarCajasExaminadorDAL = new AsignarCajasExaminadorDAL();
            AsignarCajasExaminadorDAL.IngresarCajasExaminador(AsignarCajasExaminador);
        }
        public List<AsignarCajasExaminadorEN> ListarCajasExaminador(Int64 idMPR, Int64 rut, Int64 numeroDocumento)
        {
            List<AsignarCajasExaminadorEN> listaCajasExaminador = new List<AsignarCajasExaminadorEN>();
            IAsignarCajasExaminadorDAL AsignarCajasExaminadorDAL = new AsignarCajasExaminadorDAL();
            listaCajasExaminador = AsignarCajasExaminadorDAL.ListarCajasExaminador(idMPR, rut, numeroDocumento);
            return listaCajasExaminador;
        }

        public List<AsignarCajasExaminadorEN> ListarCajasExaminadorRecepcion(Int64 idMPR, Int64 rut)
        {
            List<AsignarCajasExaminadorEN> listaCajasExaminador = new List<AsignarCajasExaminadorEN>();
            IAsignarCajasExaminadorDAL AsignarCajasExaminadorDAL = new AsignarCajasExaminadorDAL();
            listaCajasExaminador = AsignarCajasExaminadorDAL.ListarCajasExaminadorRecepcion(idMPR, rut);
            return listaCajasExaminador;
        }

        public void RecepcionarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador, string idUsuario)
        {
            IAsignarCajasExaminadorDAL AsignarCajasExaminadorDAL = new AsignarCajasExaminadorDAL();
            AsignarCajasExaminadorDAL.RecepcionarCajasExaminador(AsignarCajasExaminador, idUsuario);
        }
    }
}
