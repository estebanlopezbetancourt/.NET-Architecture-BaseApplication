﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class ReporteRecepcionDespachoSupervisoresBLL:IReporteRecepcionDespachoSupervisoresBLL
    {
        //DESPACHO HACIA SUPERVISORES
        public List<ReporteRecepcionDespachoSupervisoresEN> ReporteDespachoSupervisores(int nivel, int tipoPrueba,Int64 idSubCentro)
        {
            List<ReporteRecepcionDespachoSupervisoresEN> listado = new List<ReporteRecepcionDespachoSupervisoresEN>();
            IReporteRecepcionDespachoSupervisoresDAL ReporteRecepcionDespachoSupervisoresDAL = new ReporteRecepcionDespachoSupervisoresDAL();
            listado = ReporteRecepcionDespachoSupervisoresDAL.ReporteDespachoSupervisores(nivel, tipoPrueba,  idSubCentro);
            return listado;
        }

       
        //RECEPCION DESDE SUPERVISORES
        public List<ReporteRecepcionDespachoSupervisoresEN> ReporteRecepcionSupervisores(int nivel, int tipoPrueba, Int64 idSubCentro)
        {
            List<ReporteRecepcionDespachoSupervisoresEN> listado = new List<ReporteRecepcionDespachoSupervisoresEN>();
            IReporteRecepcionDespachoSupervisoresDAL ReporteRecepcionDespachoSupervisoresDAL = new ReporteRecepcionDespachoSupervisoresDAL();
            listado = ReporteRecepcionDespachoSupervisoresDAL.ReporteRecepcionSupervisores(nivel, tipoPrueba, idSubCentro);
            return listado;
        }
    }
}
