﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class AsignarCajasBLL:IAsignarCajasBLL
    {
        public AsignarCajasPackingListEN IngresarDocumentoExaminador(AsignarCajasEN AsignarCajas)
        {
          AsignarCajasPackingListEN packing = new AsignarCajasPackingListEN();
            IAsignarCajasDAL AsignarCajasDAL = new AsignarCajasDAL();
            packing = AsignarCajasDAL.IngresarDocumentoExaminador(AsignarCajas);
            return packing;
        }

        public AsignarCajasTipoPersonaEN tipoPersona(Int64 rut)
        {
            AsignarCajasTipoPersonaEN tipoPersona = new AsignarCajasTipoPersonaEN();
            IAsignarCajasDAL AsignarCajasDAL = new AsignarCajasDAL();
            tipoPersona = AsignarCajasDAL.tipoPersona(rut);
            return tipoPersona;
        }


        public void FinalizarMovimiento(Int64 idMPR, int tipoMovimiento)
        {
            IAsignarCajasDAL AsignarCajasDAL = new AsignarCajasDAL();
            AsignarCajasDAL.FinalizarMovimiento(idMPR, tipoMovimiento);
        }

        public int estadoMovimiento(Int64 idMPR)
        {
            int estadoDocumento;
            IAsignarCajasDAL AsignarCajasDAL = new AsignarCajasDAL();
            estadoDocumento = AsignarCajasDAL.estadoMovimiento(idMPR);
            return estadoDocumento;
        }
    }
}
