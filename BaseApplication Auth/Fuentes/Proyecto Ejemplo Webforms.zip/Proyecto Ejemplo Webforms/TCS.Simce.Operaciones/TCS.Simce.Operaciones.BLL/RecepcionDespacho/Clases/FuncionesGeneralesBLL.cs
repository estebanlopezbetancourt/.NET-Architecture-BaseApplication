﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class FuncionesGeneralesBLL : IFuncionesGeneralesBLL
    {
        public List<DropListarEN> EntidadDespachoListar(Int64 tipoEntidadDespacho)
        {
            IFuncionesGeneralesDAL EntidadDespacho = new FuncionesGeneralesDAL();
            List<DropListarEN> listado = EntidadDespacho.EntidadDespachoListar(tipoEntidadDespacho);

            return listado;
        }

        public List<DropListarEN> EntidadRecepcionListar(Int64 tipoEntidadRecepcion)
        {
            IFuncionesGeneralesDAL EntidadRecepcion = new FuncionesGeneralesDAL();
            List<DropListarEN> listado = EntidadRecepcion.EntidadRecepcionListar(tipoEntidadRecepcion);

            return listado;
        }
    }
}
