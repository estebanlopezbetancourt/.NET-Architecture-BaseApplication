﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class NivelBLL:INivelBLL
    {
        public List<NivelEN> Listar()
        {
            List<NivelEN> listado = new List<NivelEN>();
            INivelDAL NivelDAL = new NivelDAL();
            listado = NivelDAL.Listar();
            return listado;
        }
    }
}
