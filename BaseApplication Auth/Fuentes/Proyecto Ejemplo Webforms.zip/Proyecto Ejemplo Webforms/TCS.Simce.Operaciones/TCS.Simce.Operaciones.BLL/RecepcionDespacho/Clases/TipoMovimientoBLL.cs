﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class TipoMovimientoBLL : ITipoMovimientoBLL
    {
        public List<TipoMovimientoEN> Listar()
        {
            ITipoMovimientoDAL tipoMovimientoDAL = new TipoMovimientoDAL();
            List<TipoMovimientoEN> listado = tipoMovimientoDAL.Listar();

            return listado;
        }

        public List<TipoMovimientoEN> ListarSupervisores()
        {
            ITipoMovimientoDAL tipoMovimientoDAL = new TipoMovimientoDAL();
            List<TipoMovimientoEN> listadoSupervisores = tipoMovimientoDAL.ListarSupervisores();

            return listadoSupervisores;
        }
    }
}
