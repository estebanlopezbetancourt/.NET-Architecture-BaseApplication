﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class SubCentroBLL : ISubCentroBLL
    {
        public List<SubCentroEN> Listar()
        {
            List<SubCentroEN> listado = new List<SubCentroEN>();
            ISubCentroDAL SubCentroDAL = new SubCentroDAL();
            listado = SubCentroDAL.Listar();
            return listado;
        }

        public List<SubCentroEN> ListarOpcionTodos()
        {
            List<SubCentroEN> listado = new List<SubCentroEN>();
            ISubCentroDAL SubCentroDAL = new SubCentroDAL();
            listado = SubCentroDAL.ListarOpcionTodos();
            return listado;
        }
    }
}
