﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class ResumenCuadraturaGuiaBLL : IResumenCuadraturaGuiaBLL
    {
        public List<ResumenCuadraturaGuiaEN> Listar(int idPallet, int codigoPallet)
        {
            IResumenCuadraturaGuiaDAL ResumenCuadraturaGuiaDAL = new ResumenCuadraturaGuiaDAL();
            List<ResumenCuadraturaGuiaEN> listado = ResumenCuadraturaGuiaDAL.Listar(idPallet, codigoPallet);

            return listado;
        }

        public ArrayList ListarDocumentos(int tipoDocumento, int tipoMovimiento,
            int tipoEntidadDespacho, int entidadDespacho, int tipoEntidadRecepcion,
            int entidadRecepcion, string fechaDesde, string fechaHasta)
        {
            IResumenCuadraturaGuiaDAL ResumenCuadraturaGuiaDAL = new ResumenCuadraturaGuiaDAL();
            ArrayList list = ResumenCuadraturaGuiaDAL.ListarDocumentos(tipoDocumento, tipoMovimiento, tipoEntidadDespacho,
                entidadDespacho, tipoEntidadRecepcion, entidadRecepcion, fechaDesde, fechaHasta);

            return list;
        }
    }
}
