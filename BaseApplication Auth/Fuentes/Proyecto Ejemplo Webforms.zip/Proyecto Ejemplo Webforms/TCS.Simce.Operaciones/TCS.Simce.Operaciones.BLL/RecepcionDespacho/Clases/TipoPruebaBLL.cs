﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class TipoPruebaBLL:ITipoPruebaBLL
    {
        public List<TipoPruebaEN> Listar()
        {
            List<TipoPruebaEN> listado = new List<TipoPruebaEN>();
            ITipoPruebaDAL TipoPruebaDAL = new TipoPruebaDAL();
            listado = TipoPruebaDAL.Listar();
            return listado;
        }
    }
}
