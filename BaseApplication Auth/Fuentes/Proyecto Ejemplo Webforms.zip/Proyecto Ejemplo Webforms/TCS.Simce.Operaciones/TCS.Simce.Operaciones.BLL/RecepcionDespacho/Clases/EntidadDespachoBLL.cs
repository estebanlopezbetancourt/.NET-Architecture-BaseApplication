﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class EntidadDespachoBLL : IEntidadDespachoBLL
    {
        public List<EntidadDespachoEN> Listar(int tipoEntidad)
        {
            IEntidadDespachoDAL entidadDespachoDAL = new EntidadDespachoDAL();
            List<EntidadDespachoEN> listado = entidadDespachoDAL.Listar(tipoEntidad);

            return listado;
        }

        public ArrayList Listado(int tipoEntidad)
        {
            IEntidadDespachoDAL entidadDespachoDAL = new EntidadDespachoDAL();
            ArrayList listado = entidadDespachoDAL.Listado(tipoEntidad);

            return listado;
        }
    }
}
