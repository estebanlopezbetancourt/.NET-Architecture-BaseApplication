﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class AsignarCajasPackingBLL:IAsignarCajasPackingBLL
    {
        public List<AsignarCajasPackingEN> GenerarPacking(Int64 numeroDocumento)
        {
            List<AsignarCajasPackingEN> listaPicking = new List<AsignarCajasPackingEN>();
            IAsignarCajasPackingDAL AsignarCajasPackingDAL = new AsignarCajasPackingDAL();
            listaPicking = AsignarCajasPackingDAL.GenerarPacking(numeroDocumento);
            return listaPicking;
        }
    }
}
