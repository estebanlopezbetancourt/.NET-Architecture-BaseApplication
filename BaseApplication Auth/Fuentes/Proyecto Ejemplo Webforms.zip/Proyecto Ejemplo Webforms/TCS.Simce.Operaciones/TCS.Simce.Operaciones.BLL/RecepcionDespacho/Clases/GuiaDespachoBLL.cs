﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public class GuiaDespachoBLL : IGuiaDespachoBLL
    {
        public void Ingresar(GuiaDespachoEN GuiaDespacho)
        {
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            guiaDespachoDAL.Ingresar(GuiaDespacho);
        }

        public void Modificar(GuiaDespachoEN GuiaDespacho)
        {
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            guiaDespachoDAL.Modificar(GuiaDespacho);
        }

        public GuiaDespachoEN Buscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino, Int64 numeroGuiaDespacho)
        {
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            GuiaDespachoEN guiaDespachoEN = guiaDespachoDAL.Buscar(tipoDocumentoDespacho, TipoMovimiento, IdEntidadOrigen, IdEntidadDestino, numeroGuiaDespacho);
            return guiaDespachoEN;
        }

        public List<OrdenDespachoEN> OrdenDespachoListar(Int64 idMCR, Int64 idPallet)
        {
            List<OrdenDespachoEN> ListaOrdenDespacho = new List<OrdenDespachoEN>();
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            ListaOrdenDespacho = guiaDespachoDAL.OrdenDespachoListar(idMCR, idPallet);
            return ListaOrdenDespacho;
        }

        public GuiaDespachoEN OrdenDespachoBuscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino,
                                                        Int64 numeroOrdenPreparado)
        {
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            GuiaDespachoEN guiaDespachoEN = guiaDespachoDAL.OrdenDespachoBuscar(tipoDocumentoDespacho, TipoMovimiento, IdEntidadOrigen, IdEntidadDestino, numeroOrdenPreparado);
            return guiaDespachoEN;
        }

        public void AsignarNumeroGuiaDespachoAOrdenPreparado(Int64 idMCR, Int64 numeroDocumentoDespacho, string idUsuario)
        {
            IGuiaDespachoDAL guiaDespachoDAL = new GuiaDespachoDAL();
            guiaDespachoDAL.AsignarNumeroGuiaDespachoAOrdenPreparado(idMCR, numeroDocumentoDespacho, idUsuario);
        }
    }
}
