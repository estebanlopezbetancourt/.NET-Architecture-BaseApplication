﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface ISubCentroBLL
    {
        List<SubCentroEN> Listar();

        List<SubCentroEN> ListarOpcionTodos();
    }
}
