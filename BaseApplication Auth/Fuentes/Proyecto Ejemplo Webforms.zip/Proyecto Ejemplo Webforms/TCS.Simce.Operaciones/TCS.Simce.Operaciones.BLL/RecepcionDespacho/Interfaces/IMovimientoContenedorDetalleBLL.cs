﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IMovimientoContenedorDetalleBLL
    {
        List<MovimientoContenedorDetalleEN> ListarPorIdPallet(Int64 idPallet);
        ContenedorEN ContenedorActualizaRecepcionCaja(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio);
        void MovimientoContenedorActualizaRecepcionCaja(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario);

        void MovimientoContenedorActualizaRecepcionCajaSubCentro(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario);

        void FinalizarGuiaDespacho(Int64 idGuia, string idUsuario);

        void QuitarCajaDePallet(Int64 idMCD, string idUsuario);

        void CargaArchivoDocumentoDespacho(List<CargarArchivoMovimientoContenedorDetalleEN> Lista);

        void FinalizarPallet(Int64 idPallet, string idUsuario);

        Int64 RetornaCantidadPalletRecepcionados(Int64 IdGuia);

        List<TotalCuadratura> RetornaTotalCuadratura(Int64 idGuia);

        string RetornaParametrosGenerales(Int64 codigo);

        void DespachoCerrarCaja(Int64 idMCR, Int64 idPallet, Int64 idContenedorGs1, string idUsuarioCreacionRegistro);

        Boolean DespachoValidaCajaEnPallet(Int64 idMCR, Int64 idPallet, Int64 identificadorContenedorGs1);

        List<TotalCuadratura> RetornaTotalCuadraturaEnDespacho(Int64 idGuia);

        Int64 RetornaCantidadPalletDespachados(Int64 IdGuia);

        ContenedorEN ContenedorActualizaDespachoCaja(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio);

        void MovimientoContenedorActualizaDespachoCaja(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario);

        ContenedorEN ContenedorActualizaRecepcionCajaDesdeSubCentro(string Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio);

        void MovimientoContenedorActualizaRecepcionCajaDesdeSubCentro(Int64 idMCR, Int64 idContenedor, string Gs1, Int64 idTipoMaterial, Int64 IdPallet,
                                                               Int64 estadoBDSimce, string IdUsuario);
    }
}
