﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface ISupervisorBLL
    {        
        List<supervisorEN> Listar(int idSubCentro);
    }
}
