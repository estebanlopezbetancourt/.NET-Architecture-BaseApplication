﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.DAL.RecepcionDespacho;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IReporteRecepcionDespachoSupervisoresDetalleBLL
    {
        //DESPACHO A SUPERVISORES
        List<ReporteRecepcionDespachoSupervisoresDetalleEN> ReporteDespachoSupervisoresDetalle(int nivel, int tipoPrueba,  Int64 idSubCentro);

        //RECEPCION DESDE SUPERVISORES
        List<ReporteRecepcionDespachoSupervisoresDetalleEN> ReporteRecepcionSupervisoresDetalle(int nivel, int tipoPrueba, Int64 idSubCentro);
    }
}
