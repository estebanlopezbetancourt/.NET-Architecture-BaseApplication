﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IFuncionesGeneralesBLL
    {
        List<DropListarEN> EntidadDespachoListar(Int64 tipoEntidadDespacho);

        List<DropListarEN> EntidadRecepcionListar(Int64 tipoEntidadRecepcion);
    }
}
