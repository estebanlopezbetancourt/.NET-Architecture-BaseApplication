﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IEntidadDespachoBLL
    {
        List<EntidadDespachoEN> Listar(int tipoEntidad);
        ArrayList Listado(int tipoEntidad);
    }
}
