﻿
namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IOrdenPreparadoBLL
    {

    }
}
