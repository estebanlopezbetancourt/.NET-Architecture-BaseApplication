﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IEntidadRecepcionBLL
    {
        List<EntidadRecepcionEN> Listar(int tipoEntidad);
        ArrayList Listado(int tipoEntidad);
    }
}
