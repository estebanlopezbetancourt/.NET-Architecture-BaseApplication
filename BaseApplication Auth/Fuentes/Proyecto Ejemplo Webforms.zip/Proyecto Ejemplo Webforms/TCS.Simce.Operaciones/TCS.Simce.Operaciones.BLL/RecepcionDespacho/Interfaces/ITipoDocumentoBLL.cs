﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface ITipoDocumentoBLL
    {
        List<TipoDocumentoEN> Listar();
    }
}
