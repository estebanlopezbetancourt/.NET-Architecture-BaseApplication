﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IGuiaDespachoBLL
    {
        void Ingresar(GuiaDespachoEN GuiaDespacho);

        void Modificar(GuiaDespachoEN GuiaDespacho);

        GuiaDespachoEN Buscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino, Int64 numeroGuiaDespacho);

        List<OrdenDespachoEN> OrdenDespachoListar(Int64 idMCR, Int64 idPallet);
        GuiaDespachoEN OrdenDespachoBuscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino,
                                           Int64 numeroOrdenPreparado);

        void AsignarNumeroGuiaDespachoAOrdenPreparado(Int64 idMCR, Int64 numeroDocumentoDespacho, string idUsuario);
    }
}
