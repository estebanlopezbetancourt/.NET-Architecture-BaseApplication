﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IResumenCuadraturaGuiaBLL
    {
        List<ResumenCuadraturaGuiaEN> Listar(int idPallet, int codigoPallet);

        ArrayList ListarDocumentos(int tipoDocumento, int tipoMovimiento,
            int tipoEntidadDespacho, int entidadDespacho, int tipoEntidadRecepcion,
            int entidadRecepcion, string fechaDesde, string fechaHasta);
    }
}
