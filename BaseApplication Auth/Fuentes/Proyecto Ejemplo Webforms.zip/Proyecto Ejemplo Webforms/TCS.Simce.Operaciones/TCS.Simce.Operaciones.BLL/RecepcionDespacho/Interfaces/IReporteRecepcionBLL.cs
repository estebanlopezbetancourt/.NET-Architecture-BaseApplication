﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IReporteRecepcionBLL
    {
        List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumen(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalle(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);
    }
}
