﻿using System.Collections.Generic;
//MY NAPE SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.BLL.RecepcionDespacho
{
    public interface IEntidadImprentaBLL
    {
        List<EntidadImprentaEN> Listar();
    }
}
