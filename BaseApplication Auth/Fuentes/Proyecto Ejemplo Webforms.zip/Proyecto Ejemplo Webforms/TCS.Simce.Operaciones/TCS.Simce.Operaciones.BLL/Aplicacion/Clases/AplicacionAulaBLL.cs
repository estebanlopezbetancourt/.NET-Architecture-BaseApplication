﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.DAL.Aplicacion;
using TCS.Simce.Operaciones.EN.Aplicacion;

namespace TCS.Simce.Operaciones.BLL.Aplicacion
{
    public class AplicacionAulaBLL : IAplicacionAulaBLL
    {
        public bool RegistrarAplicacionAula(RegistroAplicacionAulaEN registro)
        {
            bool seRegistro = false;
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            seRegistro = aplicacionAulaDAL.RegistrarAplicacionAula(registro);
            return seRegistro;
        }

        public RegistroAplicacionAulaEN BuscarDatosAplicacionAula(int idNivel, int rbd, string letraCurso)
        {
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            RegistroAplicacionAulaEN registro = aplicacionAulaDAL.BuscarDatosAplicacionAula(idNivel,rbd,letraCurso);
            return registro;
        }

        public DatosContenedorEN BuscarDatosContenedor(DatosContenedorEN contenedor)
        {
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            contenedor = aplicacionAulaDAL.BuscarDatosContenedor(contenedor);
            return contenedor;
        }

        public CursoContenedoresEN BuscarCurso(CursoContenedoresEN curso)
        {
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            CursoContenedoresEN datosCurso = new CursoContenedoresEN();
            datosCurso = aplicacionAulaDAL.BuscarCurso(curso);
            return datosCurso;
        }

        public List<AplicoExperimentalEN> ListarAplicoExp()
        {
            List<AplicoExperimentalEN> lista = new List<AplicoExperimentalEN>();
            lista.Add(new AplicoExperimentalEN { Id = 0, Descripcion = "No" });
            lista.Add(new AplicoExperimentalEN { Id = 1, Descripcion = "Si" });

            return lista;
        }

        public List<AplicoCensalEN> ListarAplicoCensal()
        {
            List<AplicoCensalEN> lista = new List<AplicoCensalEN>();
            lista.Add(new AplicoCensalEN { Id = 1, Descripcion = "Si" });
            lista.Add(new AplicoCensalEN { Id = 0, Descripcion = "No" });

            return lista;
        }

        public List<AplicoSesionComplementariaEN> ListarAplicoComplementaria()
        {
            List<AplicoSesionComplementariaEN> lista = new List<AplicoSesionComplementariaEN>();
            lista.Add(new AplicoSesionComplementariaEN { Id = 0, Descripcion = "No" });
            lista.Add(new AplicoSesionComplementariaEN { Id = 1, Descripcion = "Si" });

            return lista;
        }

        public List<AplicoVisitaPreviaEN> ListarAplicoVisitaPrevia()
        {
            List<AplicoVisitaPreviaEN> lista = new List<AplicoVisitaPreviaEN>();
            lista.Add(new AplicoVisitaPreviaEN { Id = 0, Descripcion = "No" });
            lista.Add(new AplicoVisitaPreviaEN { Id = 1, Descripcion = "Si" });

            return lista;
        }

        public RegistroVisitaPreviaEN BuscarDatosVisitaPrevia(int idNivel, int rbd, string letraCurso)
        {
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            RegistroVisitaPreviaEN registro = aplicacionAulaDAL.BuscarDatosVisitaPrevia(idNivel, rbd, letraCurso);
            return registro;
        }

        public bool RegistrarVisitaPrevia(RegistroVisitaPreviaEN registro)
        {
            bool seRegistro = false;
            IAplicacionAulaDAL aplicacionAulaDAL = new AplicacionAulaDAL();
            seRegistro = aplicacionAulaDAL.RegistrarVisitaPrevia(registro);
            return seRegistro;
        }
    }
}
