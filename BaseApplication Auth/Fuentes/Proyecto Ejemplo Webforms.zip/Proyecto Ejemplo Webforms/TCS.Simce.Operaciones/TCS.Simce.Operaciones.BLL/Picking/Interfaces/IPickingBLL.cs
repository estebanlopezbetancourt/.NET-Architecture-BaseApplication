﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.Picking;

namespace TCS.Simce.Operaciones.BLL.Picking
{
    public interface IPickingBLL
    {
        List<CajasOrdenProparadoEN> ListarOrdenPreparado(Int64 NumeroOrdenPreparado);
        SubCentroEN RetornaSubCentro(Int64 NumeroOrdenPreparado);
        string RetornaNivel(Int64 codigo);
        void AsignarPalletACaja(Int64 idMCR, Int64 idPallet, Int64 identificadorContenedorGs1, string idUsuario);
        void PickearCaja(Int64 idMCR, Int64 identificacionContenedorGs1, string idUsuario);
        OrdenPreparadoEN OrdenPreparadoBuscar(Int64 NumeroOrdenPreparado);
        void CerrarOrdenPreparado(Int64 idMCR, Int64 totalPallet, string idUsuario);
        Int64 PickingValidarCajasEnOrdenPreparado(Int64 idMCR, Int64 identificacionContenedorGs1NumeroOrdenPreparado);
    }
}
