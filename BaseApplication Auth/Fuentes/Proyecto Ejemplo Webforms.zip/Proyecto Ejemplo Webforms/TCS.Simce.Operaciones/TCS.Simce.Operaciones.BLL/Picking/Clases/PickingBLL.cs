﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.Picking;
using TCS.Simce.Operaciones.EN.Picking;

namespace TCS.Simce.Operaciones.BLL.Picking
{
    public class PickingBLL : IPickingBLL
    {
        public List<CajasOrdenProparadoEN> ListarOrdenPreparado(Int64 NumeroOrdenPreparado)
        {
            List<CajasOrdenProparadoEN> cajasOrdenProparadoEN = null;

            IPickingDAL pickingDAL = new PickingDAL();

            cajasOrdenProparadoEN = pickingDAL.ListarOrdenPreparado(NumeroOrdenPreparado);

            return cajasOrdenProparadoEN;            
       }
        public SubCentroEN RetornaSubCentro(Int64 NumeroOrdenPreparado)
        {
            SubCentroEN SubCentro = null;

            IPickingDAL pickingDAL = new PickingDAL();
            SubCentro = pickingDAL.RetornaSubCentro(NumeroOrdenPreparado);

            return SubCentro;
        }

        public string RetornaNivel(Int64 codigo)
        {
            string Nivel = string.Empty;

            IPickingDAL pickingDAL = new PickingDAL();
            Nivel = pickingDAL.RetornaNivel(codigo);

            return Nivel;
        }

        public void AsignarPalletACaja(Int64 idMCR, Int64 idPallet, Int64 identificadorContenedorGs1, string idUsuario)
        {
            IPickingDAL pickingDAL = new PickingDAL();
            pickingDAL.AsignarPalletACaja(idMCR, idPallet, identificadorContenedorGs1, idUsuario);
        }

        public void PickearCaja(Int64 idMCR, Int64 identificacionContenedorGs1, string idUsuario)
        {
            IPickingDAL pickingDAL = new PickingDAL();
            pickingDAL.PickearCaja(idMCR, identificacionContenedorGs1, idUsuario);
        }

        public OrdenPreparadoEN OrdenPreparadoBuscar(Int64 NumeroOrdenPreparado)
        {
            OrdenPreparadoEN ordenPreparadoEN = new OrdenPreparadoEN();

            IPickingDAL pickingDAL = new PickingDAL();
            ordenPreparadoEN = pickingDAL.OrdenPreparadoBuscar(NumeroOrdenPreparado);

            return ordenPreparadoEN;
        }

        public void CerrarOrdenPreparado(Int64 idMCR, Int64 totalPallet, string idUsuario)
        {
            IPickingDAL pickingDAL = new PickingDAL();
            pickingDAL.CerrarOrdenPreparado(idMCR, totalPallet, idUsuario);
        }

        public Int64 PickingValidarCajasEnOrdenPreparado(Int64 idMCR, Int64 identificacionContenedorGs1NumeroOrdenPreparado)
        {
            Int64 idEstadoRecepcion = 0;

            IPickingDAL pickingDAL = new PickingDAL();
            idEstadoRecepcion = pickingDAL.PickingValidarCajasEnOrdenPreparado(idMCR, identificacionContenedorGs1NumeroOrdenPreparado);

            return idEstadoRecepcion;

        }
    }
}
