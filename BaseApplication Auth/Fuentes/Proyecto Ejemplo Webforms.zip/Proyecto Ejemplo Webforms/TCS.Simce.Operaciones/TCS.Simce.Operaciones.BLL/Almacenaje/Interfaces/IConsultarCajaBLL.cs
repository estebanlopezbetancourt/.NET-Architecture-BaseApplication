﻿//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.BLL.Almacenaje
{
    public interface IConsultarCajaBLL
    {
        ConsultarCajaEN ConsultarCajaLista(long gs1);
    }
}
