﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.BLL.Almacenaje
{
    public interface IAlmacenajeBLL
    {
        string Ingresar(AlmacenajeEN Almacenaje, string idUsuario);
        List<TipoAsignacionEN> Listar();
        Boolean PalletBuscarSiExiste(long NumeroPalletTCS);
        Boolean UbicacionBuscarSiExiste(string Codigo);
        Boolean UbicacionOcupada(string Codigo);
    }
}
