﻿//MY NAME SPACES
using TCS.Simce.Operaciones.DAL.Almacenaje;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.BLL.Almacenaje
{
    public class ConsultarCajaBLL: IConsultarCajaBLL
    {
        public ConsultarCajaEN ConsultarCajaLista(long gs1)
        {
            ConsultarCajaEN listado = new ConsultarCajaEN();
            IConsultarCajaDAL ConsultarCajaDAL = new ConsultarCajaDAL();
            listado = ConsultarCajaDAL.ConsultarCajaLista(gs1);
            return listado;
        }
    }
}
