﻿using System;
using System.Collections.Generic;
using TCS.Simce.Operaciones.DAL.Almacenaje;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.BLL.Almacenaje
{
    public class AlmacenajeBLL : IAlmacenajeBLL
    {
        public string Ingresar(AlmacenajeEN Almacenaje, string idUsuario)
        {
            string descricpion = string.Empty;

            IAlmacenajeDAL AlmacenajeDAL = new AlmacenajeDAL();
            descricpion = AlmacenajeDAL.Ingresar(Almacenaje, idUsuario);
            return descricpion;
        }
        public List<TipoAsignacionEN> Listar()
        {
            IAlmacenajeDAL AlmacenajeDAL = new AlmacenajeDAL();
            List<TipoAsignacionEN> listado = AlmacenajeDAL.Listar();

            return listado;
        }
        public Boolean PalletBuscarSiExiste(long NumeroPalletTCS)
        {
            Boolean Existe = false;

            IAlmacenajeDAL AlmacenajeDAL = new AlmacenajeDAL();
            Existe = AlmacenajeDAL.PalletBuscarSiExiste(NumeroPalletTCS);
            return Existe;
        }

        public Boolean UbicacionBuscarSiExiste(string Codigo)
        {
            Boolean Existe = false;

            IAlmacenajeDAL AlmacenajeDAL = new AlmacenajeDAL();
            Existe = AlmacenajeDAL.UbicacionBuscarSiExiste(Codigo);
            return Existe;
        }

        public Boolean UbicacionOcupada(string Codigo)
        {
            Boolean Existe = false;

            IAlmacenajeDAL AlmacenajeDAL = new AlmacenajeDAL();
            Existe = AlmacenajeDAL.UbicacionOcupada(Codigo);
            return Existe;
        }
    }
}
