﻿using System.Collections.Generic;
//MY NAME SPACES
using TCS.Simce.Operaciones.DAL.Almacenaje;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.BLL.Almacenaje
{
    public class ConsultarUbicacionBLL: IConsultarUbicacionBLL
    {
        public List<ConsultarUbicacionEN> ConsultarUbicacionLista(int nivel, int tipoPrueba)
        {
            List<ConsultarUbicacionEN> listado = new List<ConsultarUbicacionEN>();
            IConsultarUbicacionDAL ConsultarUbicacionDAL = new ConsultarUbicacionDAL();
            listado = ConsultarUbicacionDAL.ConsultarUbicacionLista(nivel, tipoPrueba);
            return listado;
        }
    }
}
