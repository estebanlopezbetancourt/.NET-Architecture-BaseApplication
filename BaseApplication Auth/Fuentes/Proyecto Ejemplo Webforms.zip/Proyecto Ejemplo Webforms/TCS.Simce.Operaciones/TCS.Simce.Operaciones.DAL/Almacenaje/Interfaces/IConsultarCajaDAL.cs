﻿//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;


namespace TCS.Simce.Operaciones.DAL.Almacenaje
{
    public interface IConsultarCajaDAL
    {
        ConsultarCajaEN ConsultarCajaLista(long gs1);
    }
}
