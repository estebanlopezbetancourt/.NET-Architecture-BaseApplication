﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;


namespace TCS.Simce.Operaciones.DAL.Almacenaje
{
    public class ConsultarCajaDAL:IConsultarCajaDAL
    {
        public ConsultarCajaEN ConsultarCajaLista(long gs1)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();            

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ConsultarCaja");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@gs1", gs1);

                objReader = objComando.ExecuteReader();
                
                ConsultarCajaEN informe = new ConsultarCajaEN();

                if (objReader.Read())
                {
                    informe.nivel = objReader["nivel"].ToString();
                    informe.tipoPrueba = objReader["tipoPrueba"].ToString();
                    informe.tipoEntidad = objReader["tipoEntidad"].ToString();
                    informe.entidad = objReader["entidad"].ToString();
                    informe.estadoCaja = objReader["estado"].ToString();                 
                    informe.palletTcs = objReader["numeropalletTCS"].ToString();
                    informe.ubicacionFisica = objReader["descripcion"].ToString();
                    informe.rbd = objReader["rbd"].ToString();
                    informe.establecimiento = objReader["nombre"].ToString();
                }
                else
                {
                    informe = null;
                }
                return informe;
            }             
        }
    }
}
