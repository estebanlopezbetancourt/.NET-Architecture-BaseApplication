﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.DAL.Almacenaje
{
    public class ConsultarUbicacionDAL: IConsultarUbicacionDAL
    {
        public List<ConsultarUbicacionEN> ConsultarUbicacionLista(int nivel, int tipoPrueba)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ConsultarUbicacionEN> listado = new List<ConsultarUbicacionEN>();
           
            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ConsultaUbicacion");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@nivel", nivel);
                objComando.Parameters.AddWithValue("@tipoPrueba", tipoPrueba);

                objReader = objComando.ExecuteReader();

                

                while (objReader.Read())
                {
                    ConsultarUbicacionEN informe = new ConsultarUbicacionEN();
                    informe.ubicacion = objReader["ubicacion"].ToString();
                    informe.calle = objReader["calle"].ToString();
                    informe.nicho = objReader["nicho"].ToString();
                    informe.nivelNicho = objReader["nivelNicho"].ToString();
                    //informe.estado = objReader["estado"].ToString();
                    if (objReader["estadoNivelNicho"].ToString() == "1")
                    {
                        informe.estado = "No Disponible";
                    }
                    else
                    {
                        informe.estado = "";
                    }
                    informe.palletTcs =  Convert.ToInt64(objReader["numeroPalletTCS"].ToString());
                    informe.Gs1 = Convert.ToInt64(objReader["identificacionContenedorGs1"].ToString());
                    
                    listado.Add(informe);
                }
                return listado;
            }
        }
    }
}
