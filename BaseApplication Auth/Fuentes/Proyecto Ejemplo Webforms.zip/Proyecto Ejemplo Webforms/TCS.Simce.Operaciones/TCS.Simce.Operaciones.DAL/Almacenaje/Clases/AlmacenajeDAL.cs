﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.Almacenaje;

namespace TCS.Simce.Operaciones.DAL.Almacenaje
{
    public class AlmacenajeDAL : IAlmacenajeDAL
    {
        public string Ingresar(AlmacenajeEN Almacenaje, string idUsuario)
        {
            string descripcion = string.Empty;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                SqlDataReader objReader = null;

                objConexion.Open();

                SqlCommand objComando = new SqlCommand("UbicarPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@TipoAsignacion", Almacenaje.TipoAccion);
                objComando.Parameters.AddWithValue("@NumeroPalletTCS", Almacenaje.NumeroPalletTCS);
                objComando.Parameters.AddWithValue("@codigoUbicacion", Almacenaje.codigoUbicacion);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    descripcion = objReader["Descripcion"].ToString();
                }

                return descripcion;
            }

        }

        public List<TipoAsignacionEN> Listar()
        {
            List<TipoAsignacionEN> listado = new List<TipoAsignacionEN>();

            TipoAsignacionEN tipoAsignacionEN1 = new TipoAsignacionEN();
            tipoAsignacionEN1.codigo = 1;
            tipoAsignacionEN1.descripcion = "Almacenar";
            listado.Add(tipoAsignacionEN1);

            TipoAsignacionEN tipoAsignacionEN2 = new TipoAsignacionEN();
            tipoAsignacionEN2.codigo = 2;
            tipoAsignacionEN2.descripcion = "Temporal";
            listado.Add(tipoAsignacionEN2);
            return listado;
        }

        public Boolean PalletBuscarSiExiste(long NumeroPalletTCS)
        {
            Boolean BuscarSiExiste = false;

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PalletBuscarSiExiste");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@NumeroPalletTCS", NumeroPalletTCS);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    BuscarSiExiste = true;
                }

                return BuscarSiExiste;
            }
        }

        public Boolean UbicacionBuscarSiExiste(string Codigo)
        {
            Boolean BuscarSiExiste = false;

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("UbicacionBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@codigo", Codigo);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    BuscarSiExiste = true;
                }

                return BuscarSiExiste;
            }
        }

        public Boolean UbicacionOcupada(string Codigo)
        {
            Boolean BuscarSiExiste = false;

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PalletBuscarUbicacionOcupada");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@codigo", Codigo);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    BuscarSiExiste = true;
                }

                return BuscarSiExiste;
            }
        }
    }
}
