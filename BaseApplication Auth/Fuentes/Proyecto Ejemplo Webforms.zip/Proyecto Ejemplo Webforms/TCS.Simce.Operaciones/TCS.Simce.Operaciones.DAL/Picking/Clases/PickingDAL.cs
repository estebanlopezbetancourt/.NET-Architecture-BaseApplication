﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.Picking;

namespace TCS.Simce.Operaciones.DAL.Picking
{
    public class PickingDAL : IPickingDAL
    {
        public List<CajasOrdenProparadoEN> ListarOrdenPreparado(Int64 NumeroOrdenPreparado)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                List<CajasOrdenProparadoEN> ListaCajasOrdenProparadoEN = new List<CajasOrdenProparadoEN>();

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PickingListarOrdenPreparado");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@NumeroOrdenPreparado", NumeroOrdenPreparado);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    CajasOrdenProparadoEN cajasOrdenProparadoEN = new CajasOrdenProparadoEN();

                    cajasOrdenProparadoEN.IdRegistro = Convert.ToInt64(objReader["IdRegistro"].ToString());
                    cajasOrdenProparadoEN.IdTipoMaterial = Convert.ToInt64(objReader["IdTipoMaterial"].ToString());
                    cajasOrdenProparadoEN.TipoMaterial = objReader["TipoMaterial"].ToString();
                    cajasOrdenProparadoEN.Gs1 = Convert.ToInt64(objReader["Gs1"]);
                    cajasOrdenProparadoEN.IdEstadoRecepcion = Convert.ToInt64(objReader["IdEstadoRecepcion"]);
                    cajasOrdenProparadoEN.EstadoRecepcion = objReader["EstadoRecepcion"].ToString();

                    ListaCajasOrdenProparadoEN.Add(cajasOrdenProparadoEN);
                }

                return ListaCajasOrdenProparadoEN;
            }
        }

        public SubCentroEN RetornaSubCentro(Int64 NumeroOrdenPreparado)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                SubCentroEN SubCentro = new SubCentroEN();

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PickingRetornaSubCentro");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@NumeroOrdenPreparado", NumeroOrdenPreparado);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    SubCentro.IdSubCentro = Convert.ToInt64(objReader["IdSubCentro"].ToString());
                    SubCentro.SubCentro = objReader["SubCentro"].ToString();
                }

                return SubCentro;
            }
        }

        public string RetornaNivel(Int64 codigo)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                string SubCentro = string.Empty;

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("RetornaNivel");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@codigo", codigo);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    SubCentro = objReader["SubCentro"].ToString();
                }

                return SubCentro;
            }
        }

        public void AsignarPalletACaja(Int64 idMCR, Int64 idPallet, Int64 identificadorContenedorGs1, string idUsuario)
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("PickingAsignarPalletACajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@IdMCR", idMCR);
                objComando.Parameters.AddWithValue("@IdPallet", idPallet);
                objComando.Parameters.AddWithValue("@idContenedorGs1", identificadorContenedorGs1);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }

        public void PickearCaja(Int64 idMCR, Int64 identificacionContenedorGs1, string idUsuario)
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("PickingPickearCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@IdMCR", idMCR);
                objComando.Parameters.AddWithValue("@identificacionContenedorGs1", identificacionContenedorGs1);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }

        public OrdenPreparadoEN OrdenPreparadoBuscar(Int64 NumeroOrdenPreparado)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                OrdenPreparadoEN ordenPreparadoEN = new OrdenPreparadoEN();

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("OrdenPreparadoBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@NumeroOrdenPreparado", NumeroOrdenPreparado);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    ordenPreparadoEN.idMCR = Convert.ToInt64(objReader["idMCR"].ToString());
                    ordenPreparadoEN.estadoGuiaDespacho = Convert.ToInt64(objReader["estadoGuiaDespacho"].ToString());
                }
                else
                {
                    ordenPreparadoEN = null;
                }

                return ordenPreparadoEN;
            }
        }

        public void CerrarOrdenPreparado(Int64 idMCR, Int64 totalPallet, string idUsuario)
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("PickingCerrarOrdenPreparado");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@IdMCR", idMCR);
                objComando.Parameters.AddWithValue("@totalPallet", totalPallet);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }

        public Int64 PickingValidarCajasEnOrdenPreparado(Int64 idMCR, Int64 identificacionContenedorGs1)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                Int64 idEstadoRecepcion = 0;

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PickingValidarCajasEnOrdenPreparado");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@identificacionContenedorGs1", identificacionContenedorGs1);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    idEstadoRecepcion = Convert.ToInt64(objReader["idEstadoRecepcion"].ToString()); ;
                }
                else
                {
                    idEstadoRecepcion = 0;
                }

                return idEstadoRecepcion;
            }
        }
    }
}
