﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface ITipoEntidadDespachoDAL
    {
        List<TipoEntidadDespachoEN> Listar();
    }
}
