﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IResumenCuadraturaGuiaDAL
    {
        List<ResumenCuadraturaGuiaEN> Listar(int idPallet, int codigoPallet);

        ArrayList ListarDocumentos(int tipoDocumento, int tipoMovimiento, int tipoEntidadDespacho, int entidadDespacho,
            int tipoEntidadRecepcion, int entidadRecepcion, string fechaDesde, string fechaHasta);
    }
}
