﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IReporteRecepcionDAL
    {
        List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumen(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalle(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);

        List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino);
    }
}
