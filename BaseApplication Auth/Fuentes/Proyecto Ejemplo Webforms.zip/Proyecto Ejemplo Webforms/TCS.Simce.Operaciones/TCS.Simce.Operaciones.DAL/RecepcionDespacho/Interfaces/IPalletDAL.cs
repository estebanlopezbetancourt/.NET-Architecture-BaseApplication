﻿using System;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IPalletDAL
    {
        PalletEN Buscar(Int64 numeroPalletTCS, Int64 idMCR, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio, string idUsuarioCreacionRegistro, Int64 idEstadoRecepcionEntidadCustodio, Int64 idUbicacionCOPrincipal);
        void DespachoCerrarPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro);
        void DespachoCerrarMovimientoPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro);
        PalletEN BuscarParaDespacho(Int64 numeroPalletTCS, Int64 idMCR);

        void CerrarPalletDesdeSubCentro(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro);
    }
}
