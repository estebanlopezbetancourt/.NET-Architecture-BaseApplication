﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IReporteRecepcionDespachoSupervisoresDAL
    {
        //DESPACHO HACIA SUPERVISORES
        List<ReporteRecepcionDespachoSupervisoresEN> ReporteDespachoSupervisores(int nivel, int tipoPrueba, Int64 idSubCentro);

        // RECEPCION DESDE SUPERVISORES
        List<ReporteRecepcionDespachoSupervisoresEN> ReporteRecepcionSupervisores(int nivel, int tipoPrueba, Int64 idSubCentro);

    }
}
