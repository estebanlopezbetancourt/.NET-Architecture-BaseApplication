﻿using System.Collections.Generic;
//MY NAPE SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface ITipoPruebaDAL
    {
        List<TipoPruebaEN> Listar();
    }
}
