﻿using System.Collections;
using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IEntidadRecepcionDAL
    {
        List<EntidadRecepcionEN> Listar(int tipoEntidad);
        ArrayList Listado(int tipoEntidad);
    }
}
