﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IInformeCuadraturaCajasImprentaDAL
    {
        List<InformeCuadraturaCajasImprentaEN> informeCuadraturaCajasImprentaLista(int imprenta, int tipoPrueba, int tipoMaterial, int nivel);
    }
}
