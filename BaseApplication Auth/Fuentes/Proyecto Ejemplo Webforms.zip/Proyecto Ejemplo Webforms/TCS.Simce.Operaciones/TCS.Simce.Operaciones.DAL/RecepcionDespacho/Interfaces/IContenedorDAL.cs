﻿
namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class IContenedorDAL
    {
    }
}
