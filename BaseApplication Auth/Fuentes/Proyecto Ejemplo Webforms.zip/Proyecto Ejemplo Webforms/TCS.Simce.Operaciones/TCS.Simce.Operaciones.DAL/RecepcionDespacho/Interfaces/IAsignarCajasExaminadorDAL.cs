﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public interface IAsignarCajasExaminadorDAL
    {
        void IngresarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador);

        List<AsignarCajasExaminadorEN> ListarCajasExaminador(Int64 idMPR, Int64 rut, Int64 numeroDocumento);

        List<AsignarCajasExaminadorEN> ListarCajasExaminadorRecepcion(Int64 idMPR, Int64 rut);

        void RecepcionarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador, string idUsuario);
    }
}
