﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoEntidadDespachoDAL : ITipoEntidadDespachoDAL
    {
        public List<TipoEntidadDespachoEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<TipoEntidadDespachoEN> listado = new List<TipoEntidadDespachoEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spTipoEntidadDespachoListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    TipoEntidadDespachoEN tipoEntidadDespachoEN = new TipoEntidadDespachoEN();

                    tipoEntidadDespachoEN.Id = Convert.ToInt64(objReader["Id"].ToString());
                    tipoEntidadDespachoEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(tipoEntidadDespachoEN);
                }
                return listado;
            }
        }
    }
}
