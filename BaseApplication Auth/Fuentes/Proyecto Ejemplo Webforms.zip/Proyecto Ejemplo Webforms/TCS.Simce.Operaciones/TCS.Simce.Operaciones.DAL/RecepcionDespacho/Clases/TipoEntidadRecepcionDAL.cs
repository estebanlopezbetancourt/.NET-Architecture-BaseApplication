﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoEntidadRecepcionDAL : ITipoEntidadRecepcionDAL
    {
        public List<TipoEntidadRecepcionEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<TipoEntidadRecepcionEN> listado = new List<TipoEntidadRecepcionEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spTipoEntidadRecepcionListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    TipoEntidadRecepcionEN tipoEntidadRecepcionEN = new TipoEntidadRecepcionEN();

                    tipoEntidadRecepcionEN.Id = Convert.ToInt64(objReader["Id"].ToString());
                    tipoEntidadRecepcionEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(tipoEntidadRecepcionEN);
                }
                return listado;
            }
        }
    }
}
