﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.DAL.Usuario;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class ContenedorDAL : IContenedorDAL
    {
        public IList<ContenedorEN> Buscar(int IdTipoMaterial, int IdSubCentro, int IdNivel)
        {
            IList<ContenedorEN> ListaContenedor = null;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spContenedorBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@IdTipoMaterial", IdTipoMaterial);
                objComando.Parameters.AddWithValue("@IdSubCentro", IdSubCentro);
                objComando.Parameters.AddWithValue("@IdNivel", IdNivel);

                objReader = objComando.ExecuteReader();

                if (objReader.HasRows)
                {
                    ListaContenedor = new List<ContenedorEN>();

                    while (objReader.Read())
                    {
                        ContenedorEN Contenedor = new ContenedorEN();

                        Contenedor.idContenedor = Convert.ToInt32(objReader["idContenedor"].ToString());
                        Contenedor.idSubCentro = Convert.ToInt32(objReader["idSubCentro"].ToString());
                        Contenedor.idNivel = Convert.ToInt32(objReader["idNivel"].ToString());
                        Contenedor.idTipoPrueba = Convert.ToInt32(objReader["idTipoPrueba"].ToString());
                        Contenedor.idUbicacionCOPrincipal = objReader["idUbicacionCOPrincipal"] == DBNull.Value ? ((int?)null) : Convert.ToInt32(objReader["idUbicacionCOPrincipal"].ToString());
                        Contenedor.idTipoMaterial = Convert.ToInt32(objReader["idTipoMaterial"].ToString());
                        Contenedor.identificacionContenedorGs1 = Convert.ToInt32(objReader["identificacionContenedorGs1"].ToString());

                        //campos enlazados
                        Contenedor.SubcentroDescripcion = objReader["SubcentroDescripcion"].ToString();
                        Contenedor.NivelDescripcion = objReader["NivelDescripcion"].ToString();
                        Contenedor.TipoMaterialDescripcion = objReader["TipoMaterialDescripcion"].ToString();
                        Contenedor.TipoPruebaDescripcion = objReader["TipoPruebaDescripcion"].ToString();
                        Contenedor.UbicacionDescripcion = objReader["UbicacionDescripcion"].ToString();

                        ListaContenedor.Add(Contenedor);
                    }
                }
                return ListaContenedor;
            }
        }

        public int EnviarAPreparar(int IdSubCentroDestino, int IdTipoMaterial, string UsuarioRut, int IdNivel)
        {
            string UsuarioRutDv;
            int NumeroCorrelativo = 0;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            //digito verificador
            UsuarioDAL usuarioDAL = new UsuarioDAL();
            UsuarioRutDv = usuarioDAL.DigitoVerificador(Convert.ToInt64(UsuarioRut));

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEnviarAPreparar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;


                objComando.Parameters.AddWithValue("@IdSubCentroDestino", IdSubCentroDestino);
                objComando.Parameters.AddWithValue("@IdTipoMaterial", IdTipoMaterial);
                objComando.Parameters.AddWithValue("@UsuarioRut", UsuarioRut);
                objComando.Parameters.AddWithValue("@UsuarioRutDv", UsuarioRutDv);
                objComando.Parameters.AddWithValue("@IdNivel", IdNivel);
                
                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {

                    NumeroCorrelativo = Convert.ToInt32(objReader["NumeroOrdenPreparado"].ToString());
                        
                }
                return NumeroCorrelativo;
            }
        }
    }
}
