﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoInformeDAL : ITipoInformeDAL
    {
        public List<TipoInformeEN> Listar()
        {

            List<TipoInformeEN> listado = new List<TipoInformeEN>();

            TipoInformeEN tipoInformeEN1 = new TipoInformeEN();
            tipoInformeEN1.Id = 1;
            tipoInformeEN1.Descripcion = "Resumen";
            listado.Add(tipoInformeEN1);

            TipoInformeEN tipoInformeEN2 = new TipoInformeEN();
            tipoInformeEN2.Id = 2;
            tipoInformeEN2.Descripcion = "Detalle";
            listado.Add(tipoInformeEN2);
            return listado;
            
        }
    }
}
