﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class PalletDAL : IPalletDAL
    {
        public PalletEN Buscar(Int64 numeroPalletTCS, Int64 idMCR, Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio, string idUsuarioCreacionRegistro,
                               Int64 idEstadoRecepcionEntidadCustodio, Int64 idUbicacionCOPrincipal)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PalletBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@numeroPalletTCS", numeroPalletTCS);
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idTipoEntidadCustodio", idTipoEntidadCustodio);
                objComando.Parameters.AddWithValue("@idEntidadCustodio", idEntidadCustodio);
                objComando.Parameters.AddWithValue("@idUsuarioCreacionRegistro", idUsuarioCreacionRegistro);
                objComando.Parameters.AddWithValue("@idEstadoRecepcionEntidadCustodio", idEstadoRecepcionEntidadCustodio);
                objComando.Parameters.AddWithValue("@idUbicacionCOPrincipal", idUbicacionCOPrincipal);

                objReader = objComando.ExecuteReader();

                PalletEN Pallet = new PalletEN();
                if (objReader.Read())
                {
                    Pallet.idPallet = Convert.ToInt64(objReader["idPallet"].ToString());
                    Pallet.numeroPalletTCS = Convert.ToInt64(objReader["numeroPalletTCS"].ToString());
                    Pallet.idTipoEntidadCustodio = Convert.ToInt64(objReader["idTipoEntidadCustodio"].ToString());
                    Pallet.idEntidadCustodio = Convert.ToInt64(objReader["idEntidadCustodio"].ToString());

                }
                else
                {
                    Pallet = null;

                }
                return Pallet;
            }
        }

        public void DespachoCerrarPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoCerrarPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuarioCreacionRegistro);

                objReader = objComando.ExecuteReader();

           }
        }

        public void DespachoCerrarMovimientoPallet(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoCerrarMovimientoPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuarioCreacionRegistro);

                objReader = objComando.ExecuteReader();

            }
        }

        public PalletEN BuscarParaDespacho(Int64 numeroPalletTCS, Int64 idMCR)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("PalletBuscarParaDespacho");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@numeroPalletTCS", numeroPalletTCS);
                objComando.Parameters.AddWithValue("@idMCR", idMCR);

                objReader = objComando.ExecuteReader();

                PalletEN Pallet = new PalletEN();
                if (objReader.Read())
                {
                    Pallet.idPallet = Convert.ToInt64(objReader["idPallet"].ToString());
                    Pallet.numeroPalletTCS = Convert.ToInt64(objReader["numeroPalletTCS"].ToString());
                    Pallet.idTipoEntidadCustodio = Convert.ToInt64(objReader["idTipoEntidadCustodio"].ToString());
                    Pallet.idEntidadCustodio = Convert.ToInt64(objReader["idEntidadCustodio"].ToString());

                }
                else
                {
                    Pallet = null;

                }
                return Pallet;
            }
        }




        public void CerrarPalletDesdeSubCentro(Int64 idMCR, Int64 idPallet, string idUsuarioCreacionRegistro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("CerrarPalletDesdeSubCentro");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuarioCreacionRegistro);

                objReader = objComando.ExecuteReader();

            }
        }
    }
}
