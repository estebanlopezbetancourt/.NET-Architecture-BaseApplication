﻿using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class InformeCuadraturaCajasImprentaDAL : IInformeCuadraturaCajasImprentaDAL
    {
        public List<InformeCuadraturaCajasImprentaEN> informeCuadraturaCajasImprentaLista(int imprenta, int tipoMaterial, int tipoPrueba, int nivel)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            
           List<InformeCuadraturaCajasImprentaEN> listado = new List<InformeCuadraturaCajasImprentaEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spInformeCuadraturaCajasImprentaV2");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@Imprenta", imprenta);               
                objComando.Parameters.AddWithValue("@tipoMaterial", tipoMaterial);
                objComando.Parameters.AddWithValue("@tipoPrueba", tipoPrueba);
                objComando.Parameters.AddWithValue("@nivel", nivel);
                
                
                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    InformeCuadraturaCajasImprentaEN informe = new InformeCuadraturaCajasImprentaEN();
        
                    informe.tipoMaterial = (objReader["tipoMaterial"].ToString());
                    informe.nivel = (objReader["nivel"].ToString());
                    informe.tipoPrueba  = (objReader["tipoPrueba"].ToString());
                    informe.entidadImprenta = (objReader["imprenta"].ToString());
                    informe.COPrincipal = (objReader["nombreCentro"].ToString());
                    informe.cantidadEsperada= objReader["cantidadEsperada"].ToString();
                    informe.cantidadRecepcionada = objReader["cantidadRecepcionada"].ToString();
                    informe.diferencia = objReader["diferencia"].ToString();
                    informe.porcentajeRecepcion= objReader["porcentaje"].ToString();
                    //if (objReader["estadoBDSimce"].ToString() == "1")
                    //{
                    //    informe.estadoCuadratura = "Descuadrada";
                    //}
                    //else
                    //{
                    //    informe.estadoCuadratura = "Cuadrada"; 
                    //}
                    listado.Add(informe);
                }
                return listado;
            }      
        }
    }
}
