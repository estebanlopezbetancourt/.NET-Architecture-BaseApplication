﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class FuncionesGeneralesDAL : IFuncionesGeneralesDAL
    {

        public List<DropListarEN> EntidadDespachoListar(Int64 tipoEntidadDespacho)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<DropListarEN> listado = new List<DropListarEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("EntidadDespachoListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidadDespacho);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    DropListarEN dropListarEN = new DropListarEN();

                    dropListarEN.Codigo = Convert.ToInt64(objReader["codigo"].ToString());
                    dropListarEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(dropListarEN);
                }
                return listado;
            }
        }

        public List<DropListarEN> EntidadRecepcionListar(Int64 tipoEntidadRecepcion)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<DropListarEN> listado = new List<DropListarEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("EntidadRecepcionListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidadRecepcion);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    DropListarEN dropListarEN = new DropListarEN();

                    dropListarEN.Codigo = Convert.ToInt64(objReader["codigo"].ToString());
                    dropListarEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(dropListarEN);
                }
                return listado;
            }
        }
    }
}
