﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;


namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class NivelDAL : INivelDAL
    {
        public List<NivelEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<NivelEN> listado = new List<NivelEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spNivelListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                NivelEN Nivel = new NivelEN();

                Nivel.Id = 0;
                Nivel.Descripcion = "Todos";

                listado.Add(Nivel);

                while (objReader.Read())
                {
                    NivelEN Nivel1 = new NivelEN();

                    Nivel1.Id = Convert.ToInt64(objReader["Id"].ToString());
                    Nivel1.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(Nivel1);
                }
                return listado;
            }
        }
    }
}
