﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class AsignarCajasExaminadorDAL:IAsignarCajasExaminadorDAL
    {
        public void IngresarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroAsignacionCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMPR", AsignarCajasExaminador.idMPR);
                objComando.Parameters.AddWithValue("@rut", AsignarCajasExaminador.rut);
                objComando.Parameters.AddWithValue("@numeroDocumento", AsignarCajasExaminador.numeroDocumento);
                objComando.Parameters.AddWithValue("@Gs1", AsignarCajasExaminador.Gs1);
                objComando.Parameters.AddWithValue("@idUsuarioCreacionRegistro", AsignarCajasExaminador.idUsuario);
                objComando.Parameters.AddWithValue("@tipoPersona", AsignarCajasExaminador.tipoPersona);

                Int64 rows = objComando.ExecuteNonQuery();
            }        
        }

        public List<AsignarCajasExaminadorEN> ListarCajasExaminador(Int64 idMPR, Int64 rut, Int64 numeroDocumento)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            
           List<AsignarCajasExaminadorEN>  listaCajasExaminador= new List<AsignarCajasExaminadorEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroListarCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMPR", idMPR);               
                objComando.Parameters.AddWithValue("@rut", rut);
                objComando.Parameters.AddWithValue("@numeroDocumento", numeroDocumento);              
                
                
                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    AsignarCajasExaminadorEN grillaCajas = new AsignarCajasExaminadorEN();
        
                     grillaCajas.idMPD = Convert.ToInt64(objReader["idMPD"].ToString());
                     grillaCajas.idMPR = Convert.ToInt64(objReader["idMPR"].ToString());
                     grillaCajas.rut = Convert.ToInt64(objReader["rut"].ToString());
                     grillaCajas.numeroDocumento = Convert.ToInt64(objReader["numeroDocumento"].ToString());
                     grillaCajas.Gs1 = Convert.ToInt64(objReader["Gs1"].ToString());                    
                 
                    listaCajasExaminador.Add(grillaCajas);
                }
                return listaCajasExaminador;
            }      
        }

        public List<AsignarCajasExaminadorEN> ListarCajasExaminadorRecepcion(Int64 idMPR, Int64 rut)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<AsignarCajasExaminadorEN> listaCajasExaminador = new List<AsignarCajasExaminadorEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("RecepcionSubcentroListarCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMPR", idMPR);
                objComando.Parameters.AddWithValue("@rut", rut);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    AsignarCajasExaminadorEN grillaCajas = new AsignarCajasExaminadorEN();

                    grillaCajas.idMPD = Convert.ToInt64(objReader["idMPD"].ToString());
                    grillaCajas.idMPR = Convert.ToInt64(objReader["idMPR"].ToString());
                    grillaCajas.rut = Convert.ToInt64(objReader["rut"].ToString());
                    grillaCajas.numeroDocumento = Convert.ToInt64(objReader["numeroDocumento"].ToString());
                    grillaCajas.Gs1 = Convert.ToInt64(objReader["Gs1"].ToString());

                    listaCajasExaminador.Add(grillaCajas);
                }
                return listaCajasExaminador;
            }
        }

        public void RecepcionarCajasExaminador(AsignarCajasExaminadorEN AsignarCajasExaminador, string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("SubcentroRecepcionCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMPR", AsignarCajasExaminador.idMPR);
                objComando.Parameters.AddWithValue("@rut", AsignarCajasExaminador.rut);
                objComando.Parameters.AddWithValue("@numeroDocumento", AsignarCajasExaminador.numeroDocumento);
                objComando.Parameters.AddWithValue("@Gs1", AsignarCajasExaminador.Gs1);
                objComando.Parameters.AddWithValue("@entidadCustodio", AsignarCajasExaminador.idEntidadCustodio);
                objComando.Parameters.AddWithValue("@idUsuarioModificacionRegistro", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();
            }
        }
    }
}
