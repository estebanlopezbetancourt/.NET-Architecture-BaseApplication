﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class AsignarCajasPackingDAL:IAsignarCajasPackingDAL
    {
        public List<AsignarCajasPackingEN> GenerarPacking(Int64 numeroDocumento)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<AsignarCajasPackingEN> listaPicking = new List<AsignarCajasPackingEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroPacking");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@numeroDocumento", numeroDocumento);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    AsignarCajasPackingEN picking = new AsignarCajasPackingEN();

                    //picking.fechaMPR = Convert.ToDateTime(objReader["fechaMPR"].ToString());
                    //picking.numeroDocumento = Convert.ToInt64(objReader["numeroDocumento"].ToString());
                    //picking.rutSupervisor = Convert.ToInt64(objReader["rutSupervisor"].ToString());
                    //picking.nombreSupervisor = (objReader["nombreSupervisor"].ToString());
                    //picking.rutExaminador = Convert.ToInt64(objReader["rutExaminador"].ToString());
                    //picking.nombreExaminador = objReader["nombreExaminador"].ToString();
                    picking.rutExaminador ="";
                    picking.nombreExaminador = "";
                    picking.idCaja = Convert.ToInt64(objReader["idCaja"].ToString());
                    picking.firma = "___________________";
                    listaPicking.Add(picking);
                }
                return listaPicking;
            }
        }
    }
}
