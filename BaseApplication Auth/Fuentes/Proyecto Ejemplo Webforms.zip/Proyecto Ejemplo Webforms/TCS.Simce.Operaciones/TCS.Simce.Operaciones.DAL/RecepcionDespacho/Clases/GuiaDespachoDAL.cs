﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class GuiaDespachoDAL : IGuiaDespachoDAL
    {

        public void Ingresar(GuiaDespachoEN GuiaDespacho)
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("GuiaDespachoIngresar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@tipoDocumentoDespacho", GuiaDespacho.tipoDocumentoDespacho);
                objComando.Parameters.AddWithValue("@fechaMovimientoMCR", GuiaDespacho.fechaMovimientoMCR);
                objComando.Parameters.AddWithValue("@numeroGuiaDespacho", GuiaDespacho.numeroGuiaDespacho);
                objComando.Parameters.AddWithValue("@totalPallets", GuiaDespacho.totalPallets);
                objComando.Parameters.AddWithValue("@totalContenedorCapacitacion", GuiaDespacho.totalContenedorCapacitacion);
                objComando.Parameters.AddWithValue("@totalContenedorComplementario", GuiaDespacho.totalContenedorComplementario);
                objComando.Parameters.AddWithValue("@totalContenedorCajasCurso", GuiaDespacho.totalContenedorCajasCurso);
                objComando.Parameters.AddWithValue("@totalContenedorPetos", GuiaDespacho.totalContenedorPetos);
                objComando.Parameters.AddWithValue("@tipoMovimiento", GuiaDespacho.tipoMovimiento);
                objComando.Parameters.AddWithValue("@totalContenedor", GuiaDespacho.totalContenedor);
                objComando.Parameters.AddWithValue("@RutUsuarioMovimiento", GuiaDespacho.RutUsuarioMovimiento);
                objComando.Parameters.AddWithValue("@dvRutUsuarioMovimiento", GuiaDespacho.dvRutUsuarioMovimiento);
                objComando.Parameters.AddWithValue("@NombreUsuarioMovimiento", GuiaDespacho.NombreUsuarioMovimiento);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", GuiaDespacho.tipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", GuiaDespacho.idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", GuiaDespacho.tipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", GuiaDespacho.IdEntidadDestino);
                objComando.Parameters.AddWithValue("@idUsuarioCreacionRegistro", GuiaDespacho.idUsuarioCreacionRegistro);

                Int64 rows = objComando.ExecuteNonQuery();

                //if (!rows.Equals(1))
                //{
                //    throw new ApplicationException("error al insertar los datos - Guia Despacho");
                //}
            }

        }

        public void Modificar(GuiaDespachoEN GuiaDespacho)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("GuiaDespachoModificar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", GuiaDespacho.idMCR);
                objComando.Parameters.AddWithValue("@totalPallets", GuiaDespacho.totalPallets);
                objComando.Parameters.AddWithValue("@totalContenedorCapacitacion", GuiaDespacho.totalContenedorCapacitacion);
                objComando.Parameters.AddWithValue("@totalContenedorComplementario", GuiaDespacho.totalContenedorComplementario);
                objComando.Parameters.AddWithValue("@totalContenedorCajasCurso", GuiaDespacho.totalContenedorCajasCurso);
                objComando.Parameters.AddWithValue("@totalContenedorPetos", GuiaDespacho.totalContenedorPetos);
                objComando.Parameters.AddWithValue("@totalContenedor", GuiaDespacho.totalContenedor);
                objComando.Parameters.AddWithValue("@NombreUsuarioMovimiento", GuiaDespacho.NombreUsuarioMovimiento);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", GuiaDespacho.tipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", GuiaDespacho.idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", GuiaDespacho.tipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", GuiaDespacho.IdEntidadDestino);
                objComando.Parameters.AddWithValue("@idUsuarioModificacionRegistro", GuiaDespacho.idUsuarioModificacionRegistro);

                //objComando.ExecuteNonQuery();
                Int64 rows = objComando.ExecuteNonQuery();

                //if (!rows.Equals(1))
                //{
                //    throw new ApplicationException("error al insertar los datos - Guia Despacho");
                //}
            }

        }

        public GuiaDespachoEN Buscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino, Int64 numeroGuiaDespacho)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("GuiaDespachoBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoDocumentoDespacho", tipoDocumentoDespacho);
                objComando.Parameters.AddWithValue("@tipoMovimiento", TipoMovimiento);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", IdEntidadOrigen);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);
                objComando.Parameters.AddWithValue("@numeroDocumentoDespacho", numeroGuiaDespacho);

                objReader = objComando.ExecuteReader();

                GuiaDespachoEN GuiaDespacho = new GuiaDespachoEN();
                if (objReader.Read())
                {
                    GuiaDespacho.idMCR = Convert.ToInt64(objReader["idMCR"].ToString());
                    GuiaDespacho.fechaMovimientoMCR = Convert.ToDateTime(objReader["fechaMovimientoMCR"].ToString());
                    GuiaDespacho.numeroGuiaDespacho = Convert.ToInt64(objReader["numeroDocumentoDespacho"]);
                    GuiaDespacho.totalPallets = Convert.ToInt64(objReader["totalPallets"]);
                    GuiaDespacho.totalContenedorCapacitacion = Convert.ToInt64(objReader["totalContenedorCapacitacion"]);
                    GuiaDespacho.totalContenedorComplementario = Convert.ToInt64(objReader["totalContenedorComplementario"]);
                    GuiaDespacho.totalContenedorCajasCurso = Convert.ToInt64(objReader["totalContenedorCajasCurso"]);
                    GuiaDespacho.totalContenedorPetos = Convert.ToInt64(objReader["totalContenedorPetos"]);
                    GuiaDespacho.tipoMovimiento = Convert.ToInt64(objReader["tipoMovimiento"]);
                    GuiaDespacho.totalContenedor = Convert.ToInt64(objReader["totalContenedor"]);
                    GuiaDespacho.RutUsuarioMovimiento = Convert.ToInt64(objReader["RutUsuarioMovimiento"].ToString());
                    GuiaDespacho.dvRutUsuarioMovimiento = objReader["dvRutUsuarioMovimiento"].ToString();
                    GuiaDespacho.NombreUsuarioMovimiento = objReader["NombreUsuarioMovimiento"].ToString();
                    GuiaDespacho.tipoEntidadOrigen = Convert.ToInt64(objReader["idTipoEntidadOrigen"]);
                    GuiaDespacho.idEntidadOrigen = Convert.ToInt64(objReader["idEntidadOrigen"]);
                    GuiaDespacho.tipoEntidadDestino = Convert.ToInt64(objReader["idTipoEntidadDestino"]);
                    GuiaDespacho.estadoGuiaDespacho = Convert.ToInt64(objReader["estadoGuiaDespacho"]);
                    GuiaDespacho.desripcionEstadoGuiaDespacho = objReader["DescripcionEstadoGuiaDespacho"].ToString();
                    GuiaDespacho.IdEntidadDestino = Convert.ToInt64(objReader["IdEntidadDestino"]);
                    GuiaDespacho.idUsuarioCreacionRegistro = objReader["idUsuarioCreacionRegistro"].ToString();

                }
                else
                {
                    GuiaDespacho = null;

                }
                return GuiaDespacho;
            }
        }

        public List<OrdenDespachoEN> OrdenDespachoListar(Int64 idMCR, Int64 idPallet)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                List<OrdenDespachoEN> ListaOrdenDespacho = new List<OrdenDespachoEN>();

                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("OrdenDeDespachoListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    OrdenDespachoEN OrdenDespacho = new OrdenDespachoEN();

                    OrdenDespacho.numeroPalletTCS = Convert.ToInt64(objReader["numeroPalletTCS"].ToString());
                    OrdenDespacho.idTipoMaterial = Convert.ToInt64(objReader["idTipoMaterial"].ToString());
                    OrdenDespacho.TipoMaterial = objReader["TipoMaterial"].ToString();
                    OrdenDespacho.identificacionContenedorGs1 = Convert.ToInt64(objReader["identificacionContenedorGs1"]);
                    OrdenDespacho.idTipoDistribucion = Convert.ToInt64(objReader["idTipoDistribucion"]);
                    OrdenDespacho.TipoDistribucion = objReader["TipoDistribucion"].ToString();
                    OrdenDespacho.idNivel = Convert.ToInt64(objReader["idNivel"]);
                    OrdenDespacho.Nivel = objReader["Nivel"].ToString();
                    OrdenDespacho.idTipoPrueba = Convert.ToInt64(objReader["idTipoPrueba"]);
                    OrdenDespacho.TipoPrueba = objReader["TipoPrueba"].ToString();
                    OrdenDespacho.dia = Convert.ToInt64(objReader["dia"].ToString());
                    OrdenDespacho.serieCajaCurso = Convert.ToInt64(objReader["serieCajaCurso"].ToString());

                    ListaOrdenDespacho.Add(OrdenDespacho);
                }
                return ListaOrdenDespacho;
            }
        }

        public GuiaDespachoEN OrdenDespachoBuscar(Int64 tipoDocumentoDespacho, Int64 TipoMovimiento, Int64 IdEntidadOrigen, Int64 IdEntidadDestino,
                                     Int64 numeroOrdenPreparado)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("GuiaDespachoConOrdenDespachoBuscar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoDocumentoDespacho", tipoDocumentoDespacho);
                objComando.Parameters.AddWithValue("@tipoMovimiento", TipoMovimiento);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", IdEntidadOrigen);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);
                objComando.Parameters.AddWithValue("@numeroOrdenPreparado", numeroOrdenPreparado);

                objReader = objComando.ExecuteReader();

                GuiaDespachoEN GuiaDespacho = new GuiaDespachoEN();
                if (objReader.Read())
                {
                    GuiaDespacho.idMCR = Convert.ToInt64(objReader["idMCR"].ToString());
                    GuiaDespacho.fechaMovimientoMCR = Convert.ToDateTime(objReader["fechaMovimientoMCR"].ToString());
                    //GuiaDespacho.numeroGuiaDespacho = Convert.ToInt64(objReader["numeroDocumentoDespacho"]);
                    GuiaDespacho.totalPallets = Convert.ToInt64(objReader["totalPallets"]);
                    GuiaDespacho.totalContenedorCapacitacion = Convert.ToInt64(objReader["totalContenedorCapacitacion"]);
                    GuiaDespacho.totalContenedorComplementario = Convert.ToInt64(objReader["totalContenedorComplementario"]);
                    GuiaDespacho.totalContenedorCajasCurso = Convert.ToInt64(objReader["totalContenedorCajasCurso"]);
                    GuiaDespacho.totalContenedorPetos = Convert.ToInt64(objReader["totalContenedorPetos"]);
                    GuiaDespacho.tipoMovimiento = Convert.ToInt64(objReader["tipoMovimiento"]);
                    GuiaDespacho.totalContenedor = Convert.ToInt64(objReader["totalContenedor"]);
                    GuiaDespacho.RutUsuarioMovimiento = Convert.ToInt64(objReader["RutUsuarioMovimiento"].ToString());
                    GuiaDespacho.dvRutUsuarioMovimiento = objReader["dvRutUsuarioMovimiento"].ToString();
                    GuiaDespacho.NombreUsuarioMovimiento = objReader["NombreUsuarioMovimiento"].ToString();
                    GuiaDespacho.tipoEntidadOrigen = Convert.ToInt64(objReader["idTipoEntidadOrigen"]);
                    GuiaDespacho.idEntidadOrigen = Convert.ToInt64(objReader["idEntidadOrigen"]);
                    GuiaDespacho.tipoEntidadDestino = Convert.ToInt64(objReader["idTipoEntidadDestino"]);
                    GuiaDespacho.estadoGuiaDespacho = Convert.ToInt64(objReader["estadoGuiaDespacho"]);
                    GuiaDespacho.desripcionEstadoGuiaDespacho = objReader["DescripcionEstadoGuiaDespacho"].ToString();
                    GuiaDespacho.IdEntidadDestino = Convert.ToInt64(objReader["IdEntidadDestino"]);
                    GuiaDespacho.idUsuarioCreacionRegistro = objReader["idUsuarioCreacionRegistro"].ToString();

                }
                else
                {
                    GuiaDespacho = null;

                }
                return GuiaDespacho;
            }
        }

        public void AsignarNumeroGuiaDespachoAOrdenPreparado(Int64 idMCR, Int64 numeroDocumentoDespacho, string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("AsignarNumGuiaDespachoAOrdenPrep");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@numeroDocumentoDespacho", numeroDocumentoDespacho);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }
    }
}
