﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class SubCentroDAL : ISubCentroDAL
    {
        public List<SubCentroEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<SubCentroEN> listado = new List<SubCentroEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spSubCentroListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    SubCentroEN SubCentro = new SubCentroEN();

                    SubCentro.Id = Convert.ToInt64(objReader["Id"].ToString());
                    SubCentro.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(SubCentro);
                }
                return listado;
            }
        }

        public List<SubCentroEN> ListarOpcionTodos()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<SubCentroEN> listado = new List<SubCentroEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spSubCentroListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                SubCentroEN SubCentro = new SubCentroEN();
                SubCentro.Id = 0;
                SubCentro.Descripcion = "Todos";

                listado.Add(SubCentro);

                while (objReader.Read())
                {
                    SubCentroEN SubCentro1 = new SubCentroEN();

                    SubCentro1.Id = Convert.ToInt64(objReader["Id"].ToString());
                    SubCentro1.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(SubCentro1);
                }
                return listado;
            }
        }
    }
}
