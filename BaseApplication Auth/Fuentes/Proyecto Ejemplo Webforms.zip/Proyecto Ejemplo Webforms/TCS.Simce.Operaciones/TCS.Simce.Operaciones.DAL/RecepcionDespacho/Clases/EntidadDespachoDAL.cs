﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class EntidadDespachoDAL : IEntidadDespachoDAL
    {
        public List<EntidadDespachoEN> Listar(int tipoEntidad)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<EntidadDespachoEN> listado = new List<EntidadDespachoEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEntidadDespachoListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidad);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    EntidadDespachoEN entidadDespachoEN = new EntidadDespachoEN();
                    entidadDespachoEN.Id = Convert.ToInt64(objReader["codigo"].ToString());
                    entidadDespachoEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(entidadDespachoEN);
                }
            }
            return listado;
        }

        public ArrayList Listado(int tipoEntidad)
        {
            ArrayList list = new ArrayList();
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();
                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEntidadDespachoListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidad);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    list.Add(new ListItem(
                        objReader["descripcion"].ToString(),
                        objReader["codigo"].ToString()
                    ));
                }
            }
            return list;
        }
    }
}
