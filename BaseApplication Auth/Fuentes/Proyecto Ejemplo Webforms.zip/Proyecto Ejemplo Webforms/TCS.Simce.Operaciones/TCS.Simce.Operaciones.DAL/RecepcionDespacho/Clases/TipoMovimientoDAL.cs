﻿using System.Collections.Generic;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoMovimientoDAL : ITipoMovimientoDAL
    {
        public List<TipoMovimientoEN> Listar()
        {

            List<TipoMovimientoEN> listado = new List<TipoMovimientoEN>();

            TipoMovimientoEN tipoMovimientoEN1 = new TipoMovimientoEN();
            tipoMovimientoEN1.Id = 0;
            tipoMovimientoEN1.Descripcion = "Seleccionar";
            listado.Add(tipoMovimientoEN1);

            TipoMovimientoEN tipoMovimientoEN2 = new TipoMovimientoEN();
            tipoMovimientoEN2.Id = 1;
            tipoMovimientoEN2.Descripcion = "Recepción";
            listado.Add(tipoMovimientoEN2);

            TipoMovimientoEN tipoMovimientoEN3 = new TipoMovimientoEN();
            tipoMovimientoEN3.Id = 2;
            tipoMovimientoEN3.Descripcion = "Despacho";
            listado.Add(tipoMovimientoEN3);
           
            return listado;
            
        }


        public List<TipoMovimientoEN> ListarSupervisores()
        {

            List<TipoMovimientoEN> listadoSupervisores = new List<TipoMovimientoEN>();

            TipoMovimientoEN tipoMovimientoEN1 = new TipoMovimientoEN();
            tipoMovimientoEN1.Id = 0;
            tipoMovimientoEN1.Descripcion = "Seleccionar";
            listadoSupervisores.Add(tipoMovimientoEN1);

            TipoMovimientoEN tipoMovimientoEN2 = new TipoMovimientoEN();
            tipoMovimientoEN2.Id = 1;
            tipoMovimientoEN2.Descripcion = "Recepción Desde Supervisores";
            listadoSupervisores.Add(tipoMovimientoEN2);

            TipoMovimientoEN tipoMovimientoEN3 = new TipoMovimientoEN();
            tipoMovimientoEN3.Id = 2;
            tipoMovimientoEN3.Descripcion = "Despacho Hacia Supervisores";
            listadoSupervisores.Add(tipoMovimientoEN3);
            
            return listadoSupervisores;

        }
    }
}
