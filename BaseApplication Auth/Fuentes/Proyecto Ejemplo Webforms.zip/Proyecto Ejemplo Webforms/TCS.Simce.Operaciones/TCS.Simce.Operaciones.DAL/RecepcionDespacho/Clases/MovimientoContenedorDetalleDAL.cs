﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class MovimientoContenedorDetalleDAL : IMovimientoContenedorDetalleDAL
    {
        public List<MovimientoContenedorDetalleEN> ListarPorIdPallet(Int64 idPallet)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<MovimientoContenedorDetalleEN> listado = new List<MovimientoContenedorDetalleEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spMovimientoContenedorDetalle");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idPallet", idPallet);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    MovimientoContenedorDetalleEN movimientoContenedorDetalleEN = new MovimientoContenedorDetalleEN();

                    movimientoContenedorDetalleEN.idMCD = Convert.ToInt64(objReader["idMCD"].ToString());
                    movimientoContenedorDetalleEN.idMCR = Convert.ToInt64(objReader["idMCR"].ToString());
                    movimientoContenedorDetalleEN.idPallet = Convert.ToInt64(objReader["idPallet"].ToString());
                    //movimientoContenedorDetalleEN.numeroPalletImprenta = Convert.ToInt64(objReader["numeroPalletImprenta"].ToString());
                    //movimientoContenedorDetalleEN.idContenedor = Convert.ToInt64(objReader["idContenedor"].ToString());
                    movimientoContenedorDetalleEN.idTipoMaterial = Convert.ToInt64(objReader["idTipoMaterial"].ToString());
                    movimientoContenedorDetalleEN.descripcionTipoMaterial = objReader["descripcionTipoMaterial"].ToString();
                    movimientoContenedorDetalleEN.identificacionContenedorGs1 = Convert.ToInt64(objReader["identificacionContenedorGs1"].ToString());
                    //movimientoContenedorDetalleEN.idTipoDistribucion = Convert.ToInt64(objReader["idTipoDistribucion"].ToString());
                    //movimientoContenedorDetalleEN.idNivel = Convert.ToInt64(objReader["idNivel"].ToString());
                    //movimientoContenedorDetalleEN.idTipoPrueba = Convert.ToInt64(objReader["idTipoPrueba"].ToString());
                    //movimientoContenedorDetalleEN.dia = Convert.ToInt64(objReader["dia"].ToString());
                    //movimientoContenedorDetalleEN.serieCajaCurso = Convert.ToInt64(objReader["serieCajaCurso"].ToString());
                    movimientoContenedorDetalleEN.idEstadoRecepcion = Convert.ToInt64(objReader["idEstadoRecepcion"].ToString());
                    movimientoContenedorDetalleEN.descripcionEstadoRecepcion = objReader["descripcionEstadoRecepcion"].ToString();
                    movimientoContenedorDetalleEN.estadoBDSimce = Convert.ToInt64(objReader["estadoBDSimce"].ToString());

                    listado.Add(movimientoContenedorDetalleEN);
                }

                return listado;
            }
        }

        public ContenedorEN ContenedorActualizaRecepcionCaja(Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba, Int64 Dia, long SerieCajaCurso,
                                                      long Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario, 
                                                      Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ContenedorActualizaRecepcionCaja");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);
                objComando.Parameters.AddWithValue("@idTipoEntidadCustodio", idTipoEntidadCustodio);
                objComando.Parameters.AddWithValue("@idEntidadCustodio", idEntidadCustodio);



                objReader = objComando.ExecuteReader();

                ContenedorEN contenedorEN = new ContenedorEN();

                if (objReader.Read())
                {
                    
                    contenedorEN.idContenedor = Convert.ToInt64(objReader["idContenedor"].ToString());
                    contenedorEN.estadoBDSimce= Convert.ToInt64(objReader["estadoBDSimce"].ToString());

                }
                else
                {
                    contenedorEN = null;

                }
                return contenedorEN;
            }
        }

        public void MovimientoContenedorActualizaRecepcionCaja(Int64 idMCR, Int64 idContenedor, Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba,
                                                            Int64 Dia, long SerieCajaCurso, long Gs1, Int64 idTipoMaterial, Int64 IdPallet, Int64 estadoBDSimce,
                                                            string IdUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("MovimientoContenedorActualizaRecepcionCaja");

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idContenedor", idContenedor);
                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@estadoBDSimce", estadoBDSimce);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);

                Int64 rows = objComando.ExecuteNonQuery();
            }
        }

        public void MovimientoContenedorActualizaRecepcionCajaSubCentro(Int64 idMCR, Int64 idContenedor, Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba,
                                                                        Int64 Dia, long SerieCajaCurso, long Gs1, Int64 idTipoMaterial, Int64 IdPallet, Int64 estadoBDSimce,
                                                                        string IdUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("MovimientoContenedorActualizaRecepcionCajaSubCentro");

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idContenedor", idContenedor);
                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@estadoBDSimce", estadoBDSimce);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }
        }
        
        public void CargaArchivoDocumentoDespacho(List<CargarArchivoMovimientoContenedorDetalleEN> Lista)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComandoLimpiaTabla = new SqlCommand("MovimientoContenedorDetalleLimpiarTablaParaCargaDesdeArchivo");
                objComandoLimpiaTabla.Connection = objConexion;
                objComandoLimpiaTabla.CommandType = CommandType.StoredProcedure;

                objComandoLimpiaTabla.Parameters.AddWithValue("@tipoDocumentoDespacho", Lista[0].tipoDocumentoDespacho);
                objComandoLimpiaTabla.Parameters.AddWithValue("@numeroDocumentoDespacho", Lista[0].numeroDocumentoDespacho);
                objComandoLimpiaTabla.Parameters.AddWithValue("@tipoMovimiento", Lista[0].tipoMovimiento);
                objComandoLimpiaTabla.Parameters.AddWithValue("@idEntidadOrigen", Lista[0].idEntidadOrigen);
                objComandoLimpiaTabla.Parameters.AddWithValue("@IdEntidadDestino", Lista[0].IdEntidadDestino);

                Int64 rowsAffect = objComandoLimpiaTabla.ExecuteNonQuery();

                foreach (CargarArchivoMovimientoContenedorDetalleEN ElementoLista in Lista)
                {
                    SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleIngresarDesdeArchivo");
                    objComando.Connection = objConexion;
                    objComando.CommandType = CommandType.StoredProcedure;

                    objComando.Parameters.AddWithValue("@tipoDocumentoDespacho", ElementoLista.tipoDocumentoDespacho);
                    objComando.Parameters.AddWithValue("@numeroDocumentoDespacho", ElementoLista.numeroDocumentoDespacho);
                    objComando.Parameters.AddWithValue("@tipoMovimiento", ElementoLista.tipoMovimiento);
                    objComando.Parameters.AddWithValue("@idEntidadOrigen", ElementoLista.idEntidadOrigen);
                    objComando.Parameters.AddWithValue("@IdEntidadDestino", ElementoLista.IdEntidadDestino);
                    objComando.Parameters.AddWithValue("@numeroPalletImprenta", ElementoLista.numeroPalletImprenta);
                    objComando.Parameters.AddWithValue("@idTipoMaterial", ElementoLista.idTipoMaterial);
                    objComando.Parameters.AddWithValue("@identificacionContenedorGs1", ElementoLista.GS1);
                    objComando.Parameters.AddWithValue("@idUsuarioCreacionRegistro", ElementoLista.idUsuarioCreacionRegistro);

                    Int64 rows = objComando.ExecuteNonQuery();
                }

            }
        }

        public void QuitarCajaDePallet(Int64 idMCD, string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();


                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleQuitarCajaDePallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCD", idMCD);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }

        public void FinalizarGuiaDespacho(Int64 idGuia, string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("FinalizarGuiaDespacho");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idGuia", idGuia);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();
                
            }

        }

        public void FinalizarPallet(Int64 idPallet, string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();


                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleFinalizaPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                Int64 rows = objComando.ExecuteNonQuery();

            }

        }

        public Int64 RetornaCantidadPalletRecepcionados(Int64 IdGuia)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleRetornaCantidadPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", IdGuia);


                objReader = objComando.ExecuteReader();

                Int64 CantidadPalletRecepcionados = 0;

                if (objReader.Read())
                {

                    CantidadPalletRecepcionados = Convert.ToInt64(objReader["CantidadPallet"].ToString());

                }
                else
                {
                    CantidadPalletRecepcionados = 0;

                }
                return CantidadPalletRecepcionados;
            }
        }

        public List<TotalCuadratura> RetornaTotalCuadratura(Int64 idGuia)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                List<TotalCuadratura> ListaTotalCuadratura = new List<TotalCuadratura>();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleRetornaCantidadCajas");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idGuia);


                objReader = objComando.ExecuteReader();
                
                while (objReader.Read())
                {
                    TotalCuadratura TotalCuadratura = new TotalCuadratura();

                    TotalCuadratura.idTipoMaterial = Convert.ToInt64(objReader["idTipoMaterial"].ToString());
                    TotalCuadratura.Total = Convert.ToInt64(objReader["Total"].ToString());

                    ListaTotalCuadratura.Add(TotalCuadratura);

                }

                return ListaTotalCuadratura;
            }
        }

        public string RetornaParametrosGenerales(Int64 codigo)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            string valor = string.Empty; //1=Pistolea, 2=Manual

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spRetornaParametrosGenerales");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@codigo", codigo);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    valor = objReader["valor"].ToString();

                }

                return valor;
            }
        }

        public void DespachoCerrarCaja(Int64 idMCR, Int64 idPallet, long idContenedorGs1, string idUsuarioCreacionRegistro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoCerrarCaja");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMCR", @idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@idContenedorGs1", idContenedorGs1);
                objComando.Parameters.AddWithValue("@idUsuario", idUsuarioCreacionRegistro);

                objReader = objComando.ExecuteReader();

            }
        }

        public Boolean DespachoValidaCajaEnPallet(Int64 idMCR, Int64 idPallet, long identificadorContenedorGs1)
        {
            Boolean ValidaCajaEnPallet = false;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("DespachoValidaCajaEnPallet");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idPallet", idPallet);
                objComando.Parameters.AddWithValue("@identificadorContenedorGs1", identificadorContenedorGs1);



                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {

                    ValidaCajaEnPallet = true;

                }

                return ValidaCajaEnPallet;
            }
        }

        public List<TotalCuadratura> RetornaTotalCuadraturaEnDespacho(Int64 idGuia)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                List<TotalCuadratura> ListaTotalCuadratura = new List<TotalCuadratura>();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleCantCajasEnDespacho");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idGuia);


                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    TotalCuadratura TotalCuadratura = new TotalCuadratura();

                    TotalCuadratura.idTipoMaterial = Convert.ToInt64(objReader["idTipoMaterial"].ToString());
                    TotalCuadratura.Total = Convert.ToInt64(objReader["Total"].ToString());

                    ListaTotalCuadratura.Add(TotalCuadratura);

                }

                return ListaTotalCuadratura;
            }
        }

        public Int64 RetornaCantidadPalletDespachados(Int64 IdGuia)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("MovimientoContenedorDetalleCantPalletEnDespacho");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", IdGuia);


                objReader = objComando.ExecuteReader();

                Int64 CantidadPalletRecepcionados = 0;

                if (objReader.Read())
                {

                    CantidadPalletRecepcionados = Convert.ToInt64(objReader["CantidadPallet"].ToString());

                }
                else
                {
                    CantidadPalletRecepcionados = 0;

                }
                return CantidadPalletRecepcionados;
            }
        }

        public ContenedorEN ContenedorActualizaDespachoCaja(Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba, Int64 Dia, long SerieCajaCurso,
                                                      long Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario,
                                                      Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ContenedorActualizaDespachoCaja");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);
                objComando.Parameters.AddWithValue("@idTipoEntidadCustodio", idTipoEntidadCustodio);
                objComando.Parameters.AddWithValue("@idEntidadCustodio", idEntidadCustodio);



                objReader = objComando.ExecuteReader();

                ContenedorEN contenedorEN = new ContenedorEN();

                if (objReader.Read())
                {

                    contenedorEN.idContenedor = Convert.ToInt64(objReader["idContenedor"].ToString());
                    contenedorEN.estadoBDSimce = Convert.ToInt64(objReader["estadoBDSimce"].ToString());

                }
                else
                {
                    contenedorEN = null;

                }
                return contenedorEN;
            }
        }

        public void MovimientoContenedorActualizaDespachoCaja(Int64 idMCR, Int64 idContenedor, Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba,
                                                            Int64 Dia, long SerieCajaCurso, long Gs1, Int64 idTipoMaterial, Int64 IdPallet, Int64 estadoBDSimce,
                                                            string IdUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                
                SqlCommand objComando = new SqlCommand("MovimientoContenedorActualizaDespachoCaja");

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idContenedor", idContenedor);
                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@estadoBDSimce", estadoBDSimce);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);

                Int64 rows = objComando.ExecuteNonQuery();
            }
        }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


        public ContenedorEN ContenedorActualizaRecepcionCajaDesdeSubCentro(Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba, Int64 Dia, long SerieCajaCurso,
                                                      long Gs1, Int64 idTipoMaterial, Int64 IdPallet, string IdUsuario,
                                                      Int64 idTipoEntidadCustodio, Int64 idEntidadCustodio)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ContenedorActualizaRecepcionCajaDesdeSubCentro");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);
                objComando.Parameters.AddWithValue("@idTipoEntidadCustodio", idTipoEntidadCustodio);
                objComando.Parameters.AddWithValue("@idEntidadCustodio", idEntidadCustodio);



                objReader = objComando.ExecuteReader();

                ContenedorEN contenedorEN = new ContenedorEN();

                if (objReader.Read())
                {

                    contenedorEN.idContenedor = Convert.ToInt64(objReader["idContenedor"].ToString());
                    contenedorEN.estadoBDSimce = Convert.ToInt64(objReader["estadoBDSimce"].ToString());

                }
                else
                {
                    contenedorEN = null;

                }
                return contenedorEN;
            }
        }

        public void MovimientoContenedorActualizaRecepcionCajaDesdeSubCentro(Int64 idMCR, Int64 idContenedor, Int64 idTipoDistribucion, Int64 Nivel, Int64 TipoPrueba,
                                                            Int64 Dia, long SerieCajaCurso, long Gs1, Int64 idTipoMaterial, Int64 IdPallet, Int64 estadoBDSimce,
                                                            string IdUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();


                SqlCommand objComando = new SqlCommand("MovimientoContenedorActualizaRecepcionCajaDesdeSubCentro");

                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idMCR", idMCR);
                objComando.Parameters.AddWithValue("@idContenedor", idContenedor);
                objComando.Parameters.AddWithValue("@idTipoDistribucion", idTipoDistribucion);
                objComando.Parameters.AddWithValue("@Nivel", Nivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@Dia", Dia);
                objComando.Parameters.AddWithValue("@SerieCajaCurso", SerieCajaCurso);
                objComando.Parameters.AddWithValue("@Gs1", Gs1);
                objComando.Parameters.AddWithValue("@idTipoMaterial", idTipoMaterial);
                objComando.Parameters.AddWithValue("@IdPallet", IdPallet);
                objComando.Parameters.AddWithValue("@estadoBDSimce", estadoBDSimce);
                objComando.Parameters.AddWithValue("@IdUsuario", IdUsuario);

                Int64 rows = objComando.ExecuteNonQuery();
            }
        }
    }
}
