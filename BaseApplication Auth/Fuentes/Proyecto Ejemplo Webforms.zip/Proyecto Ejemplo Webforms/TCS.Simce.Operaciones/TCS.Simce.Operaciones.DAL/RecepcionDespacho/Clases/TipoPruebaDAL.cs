﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoPruebaDAL: ITipoPruebaDAL
    {
        public List<TipoPruebaEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<TipoPruebaEN> listado = new List<TipoPruebaEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spTipoPruebaListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                TipoPruebaEN TipoPrueba = new TipoPruebaEN();
                
                TipoPrueba.Id = 0;
                TipoPrueba.Descripcion = "Todos";

                listado.Add(TipoPrueba);
                while (objReader.Read())
                {
                    TipoPruebaEN TipoPrueba1 = new TipoPruebaEN();

                    TipoPrueba1.Id = Convert.ToInt64(objReader["Id"].ToString());
                    TipoPrueba1.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(TipoPrueba1);
                }
                return listado;
            }
        }
    }
}
