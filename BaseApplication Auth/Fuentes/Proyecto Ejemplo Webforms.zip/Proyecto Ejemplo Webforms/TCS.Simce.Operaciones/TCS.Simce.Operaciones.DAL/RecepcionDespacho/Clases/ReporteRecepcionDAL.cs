﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class ReporteRecepcionDAL : IReporteRecepcionDAL
    {
        public List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumen(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoResumenEN> listado = new List<ReporteRecepcionDespachoResumenEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDespachoCOPrincipalSubcentroResumen");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", idTipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", idTipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);
                

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoResumenEN reporteRecepcionDespachoEN = new ReporteRecepcionDespachoResumenEN();

                    reporteRecepcionDespachoEN.Nivel = objReader["Nivel"].ToString();
                    reporteRecepcionDespachoEN.TipoPrueba = objReader["TipoPrueba"].ToString();
                    reporteRecepcionDespachoEN.SubCentro = objReader["SubCentro"].ToString();
                    reporteRecepcionDespachoEN.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"]);
                    reporteRecepcionDespachoEN.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"]);
                    reporteRecepcionDespachoEN.Diferencia = Convert.ToInt64(objReader["Diferencia"]);

                    listado.Add(reporteRecepcionDespachoEN);
                }
                return listado;
            }
        }

        public List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalle(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoDetalleEN> listado = new List<ReporteRecepcionDespachoDetalleEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDespachoCOPrincipalSubcentroDetalle");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", idTipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", idTipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);


                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoDetalleEN reporteRecepcionDespachoEN = new ReporteRecepcionDespachoDetalleEN();

                    reporteRecepcionDespachoEN.Nivel = objReader["Nivel"].ToString();
                    reporteRecepcionDespachoEN.TipoPrueba = objReader["TipoPrueba"].ToString();
                    reporteRecepcionDespachoEN.IdCaja = objReader["identificacionContenedorGs1"].ToString();
                    reporteRecepcionDespachoEN.SubCentro = objReader["SubCentro"].ToString();
                    reporteRecepcionDespachoEN.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"]);
                    reporteRecepcionDespachoEN.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"]);
                    reporteRecepcionDespachoEN.Diferencia = Convert.ToInt64(objReader["Diferencia"]);

                    listado.Add(reporteRecepcionDespachoEN);
                }
                return listado;
            }
        }

        public List<ReporteRecepcionDespachoResumenEN> ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoResumenEN> listado = new List<ReporteRecepcionDespachoResumenEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDespachoCOPrincipalSubcentroResumenNoDespachados");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", idTipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", idTipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);


                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoResumenEN reporteRecepcionDespachoEN = new ReporteRecepcionDespachoResumenEN();

                    reporteRecepcionDespachoEN.Nivel = objReader["Nivel"].ToString();
                    reporteRecepcionDespachoEN.TipoPrueba = objReader["TipoPrueba"].ToString();
                    reporteRecepcionDespachoEN.SubCentro = objReader["SubCentro"].ToString();
                    reporteRecepcionDespachoEN.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"]);
                    reporteRecepcionDespachoEN.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"]);
                    reporteRecepcionDespachoEN.Diferencia = Convert.ToInt64(objReader["Diferencia"]);

                    listado.Add(reporteRecepcionDespachoEN);
                }
                return listado;
            }
        }

        public List<ReporteRecepcionDespachoDetalleEN> ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados(int idNivel, int TipoPrueba, int idTipoEntidadOrigen, int idEntidadOrigen, int idTipoEntidadDestino, int IdEntidadDestino)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoDetalleEN> listado = new List<ReporteRecepcionDespachoDetalleEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDespachoCOPrincipalSubcentroDetalleNoDespachados");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@TipoPrueba", TipoPrueba);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", idTipoEntidadOrigen);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idEntidadOrigen);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", idTipoEntidadDestino);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", IdEntidadDestino);


                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoDetalleEN reporteRecepcionDespachoEN = new ReporteRecepcionDespachoDetalleEN();

                    reporteRecepcionDespachoEN.Nivel = objReader["Nivel"].ToString();
                    reporteRecepcionDespachoEN.TipoPrueba = objReader["TipoPrueba"].ToString();
                    reporteRecepcionDespachoEN.IdCaja = objReader["identificacionContenedorGs1"].ToString();
                    reporteRecepcionDespachoEN.SubCentro = objReader["SubCentro"].ToString();
                    reporteRecepcionDespachoEN.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"]);
                    reporteRecepcionDespachoEN.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"]);
                    reporteRecepcionDespachoEN.Diferencia = Convert.ToInt64(objReader["Diferencia"]);

                    listado.Add(reporteRecepcionDespachoEN);
                }
                return listado;
            }
        }
    }
}
