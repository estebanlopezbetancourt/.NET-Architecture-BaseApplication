﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
     public class ResumenCuadraturaGuiaDAL : IResumenCuadraturaGuiaDAL
    {
        public List<ResumenCuadraturaGuiaEN> Listar(int idPallet, int codigoPallet)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ResumenCuadraturaGuiaEN> listado = new List<ResumenCuadraturaGuiaEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spCuadraturaGuiaListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@numeroDocumentoDespacho", codigoPallet);
                objComando.Parameters.AddWithValue("@idMCR", idPallet);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ResumenCuadraturaGuiaEN ResumenCuadraturaGuia = new ResumenCuadraturaGuiaEN();

                    ResumenCuadraturaGuia.FechaMovimiento = Convert.ToDateTime(objReader["fechaMovimiento"]).ToString("dd/MM/yyyy");
                    ResumenCuadraturaGuia.TipoDocumento = objReader["tipoDocumento"].ToString();
                    ResumenCuadraturaGuia.TipoMovimiento = objReader["tipoMovimiento"].ToString();
                    ResumenCuadraturaGuia.TipoEntidadDespacho = objReader["tipoEntidaDespacho"].ToString();
                    ResumenCuadraturaGuia.EntidadDespacho = objReader["entidadDespacho"].ToString();
                    ResumenCuadraturaGuia.TipoEntidadRecepcion = objReader["tipoEntidadRecepcion"].ToString();
                    ResumenCuadraturaGuia.EntidadRecepcion = objReader["entidadRecepcion"].ToString();
                    ResumenCuadraturaGuia.NumeroDocumentoDespacho = Convert.ToInt32(objReader["numeroGuia"]);
                    //ResumenCuadraturaGuia.NumeroPalletImprenta = Convert.ToInt32(objReader["numeroPalletImprenta"]);
                    ResumenCuadraturaGuia.NumeroPalletTCS = Convert.ToInt32(objReader["numeroPalletTCS"]);
                    ResumenCuadraturaGuia.TipoMaterial = objReader["tipoMaterial"].ToString();
                    ResumenCuadraturaGuia.IdentificadorCaja = Convert.ToInt32(objReader["identificadorCaja"]);
                    ResumenCuadraturaGuia.EstadoRecepcion = objReader["estadoRecepcion"].ToString();

                    listado.Add(ResumenCuadraturaGuia);
                }
                return listado;
            }
        }

        public ArrayList ListarDocumentos(int tipoDocumento, int tipoMovimiento,
            int tipoEntidadDespacho, int entidadDespacho, int tipoEntidadRecepcion,
            int entidadRecepcion, string fechaDesde, string fechaHasta)
        {
            ArrayList list = new ArrayList();

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spDocumentoDespachoConsultar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoDocumentoDespacho", tipoDocumento);
                objComando.Parameters.AddWithValue("@tipoMovimiento", tipoMovimiento);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen", tipoEntidadDespacho);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", entidadDespacho);
                objComando.Parameters.AddWithValue("@IdTipoEntidadDestino", tipoEntidadRecepcion);
                objComando.Parameters.AddWithValue("@IdEntidadDestino", entidadRecepcion);
                objComando.Parameters.AddWithValue("@fechaDesde", fechaDesde);
                objComando.Parameters.AddWithValue("@fechaHasta", fechaHasta);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    list.Add(new ListItem(
                        objReader["codigo"].ToString(),
                        objReader["id"].ToString()
                    ));
                }
            }
            return list;
        }
    }
}
