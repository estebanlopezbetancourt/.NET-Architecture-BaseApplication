﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class AsignarCajasDAL : IAsignarCajasDAL
    {
        //METODO QUE INGRESA DOCUMENTO DESPACHO (CABECERA)
        public AsignarCajasPackingListEN IngresarDocumentoExaminador(AsignarCajasEN AsignarCajas)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            AsignarCajasPackingListEN packing = new AsignarCajasPackingListEN();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();
                SqlDataReader objReader = null;
                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentro");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@fechaMPR", AsignarCajas.fechaMPR);
                objComando.Parameters.AddWithValue("@tipoDocumento", AsignarCajas.idTipoDocumento);
                objComando.Parameters.AddWithValue("@tipoMovimiento", AsignarCajas.idTipoMovimiento);
                objComando.Parameters.AddWithValue("@idTipoEntidadDespacho", AsignarCajas.idTipoEntidadDespacho);
                objComando.Parameters.AddWithValue("@entidadDespacho", AsignarCajas.idEntidadDespacho);                
                objComando.Parameters.AddWithValue("@numeroDocumento", AsignarCajas.numeroDocumento);
                objComando.Parameters.AddWithValue("@rut", AsignarCajas.rut);
                objComando.Parameters.AddWithValue("@idUsuarioCreacionRegistro", AsignarCajas.idUsuario);

                objReader = objComando.ExecuteReader();


                if (objReader.Read())
                {                   
                    packing.numeroDocumento = Convert.ToInt64(objReader["numeroDocumento"].ToString());                    
                    packing.idMPR= Convert.ToInt64(objReader["idMPR"].ToString());                                        
                }
                return packing;
            }
        }

        
        //METODO QUE RETORNA TIPO DE PERSONA 
        public AsignarCajasTipoPersonaEN tipoPersona(Int64 rut)
        {
            AsignarCajasTipoPersonaEN tipoPersona = new AsignarCajasTipoPersonaEN();
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();
                SqlDataReader objReader = null;
                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroBuscarRut");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@rut", rut);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    tipoPersona.tipoPersona = Convert.ToInt16(objReader["TipoPersona"].ToString());
                    tipoPersona.nombre = (objReader["nombre"].ToString());
                }
                return  tipoPersona;
            }
        }


        //METODO QUE FINALIZA MOVIMIENTO
        public void FinalizarMovimiento(Int64 idMPR, int tipoMovimiento)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();           
                SqlDataReader objReader = null;
                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroFinalizar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMPR", idMPR);
                objComando.Parameters.AddWithValue("@tipoMovimiento", tipoMovimiento);

                Int64 rows = objComando.ExecuteNonQuery();
            }
        }

        //METODO QUE RETORNA ESTADO DOCUMENTO
        public int estadoMovimiento(Int64 idMPR)
        {
            int estadoDocumento = 0;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();
                SqlDataReader objReader = null;
                SqlCommand objComando = new SqlCommand("DespachoDesdeSubcentroVerEstado");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idMPR", idMPR);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    estadoDocumento = Convert.ToInt16(objReader["estadoDocumento"].ToString());
                }
                return estadoDocumento;
            }
        }
    }
}
