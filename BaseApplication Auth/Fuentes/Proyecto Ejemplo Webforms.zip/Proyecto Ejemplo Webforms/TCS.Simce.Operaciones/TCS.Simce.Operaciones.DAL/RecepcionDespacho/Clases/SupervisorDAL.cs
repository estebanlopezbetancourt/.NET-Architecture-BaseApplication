﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class SupervisorDAL:ISupervisorDAL
    {
        public List<supervisorEN> Listar( int idSubCentro)
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<supervisorEN> listado = new List<supervisorEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ListarSupervisores");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idSubCentro", idSubCentro);
                objReader = objComando.ExecuteReader();

                supervisorEN supervisor = new supervisorEN();

                supervisor.Id = 0;
                supervisor.nombre = "Todos";

                listado.Add(supervisor);

                while (objReader.Read())
                {
                    supervisorEN supervisor1 = new supervisorEN();

                    supervisor1.Id = Convert.ToInt64(objReader["idPersona"].ToString());
                    supervisor1.nombre = objReader["nombre"].ToString();

                    listado.Add(supervisor1);
                }
                return listado;
            }
        }
    }
}
