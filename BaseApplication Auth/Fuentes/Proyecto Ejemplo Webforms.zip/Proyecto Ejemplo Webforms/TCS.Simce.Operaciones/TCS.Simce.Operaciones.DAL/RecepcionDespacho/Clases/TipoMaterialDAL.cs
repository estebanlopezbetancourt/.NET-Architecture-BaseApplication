﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class TipoMaterialDAL : ITipoMaterialDAL
    {
        public List<TipoMaterialEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<TipoMaterialEN> listado = new List<TipoMaterialEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spTipoMaterialListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    TipoMaterialEN TipoMaterial = new TipoMaterialEN();

                    TipoMaterial.Id = Convert.ToInt64(objReader["Id"].ToString());
                    TipoMaterial.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(TipoMaterial);
                }
                return listado;
            }
        }
    } 
}
