﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class EntidadRecepcionDAL : IEntidadRecepcionDAL
    {
        public List<EntidadRecepcionEN> Listar(int tipoEntidad)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<EntidadRecepcionEN> listado = new List<EntidadRecepcionEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEntidadRecepcionListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidad);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    EntidadRecepcionEN entidadRecepcionEN = new EntidadRecepcionEN();

                    entidadRecepcionEN.Id = Convert.ToInt64(objReader["codigo"].ToString());
                    entidadRecepcionEN.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(entidadRecepcionEN);
                }
            }
            return listado;
        }

        public ArrayList Listado(int tipoEntidad)
        {
            ArrayList list = new ArrayList();
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();
                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEntidadRecepcionListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@tipoEntidad", tipoEntidad);

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    list.Add(new ListItem(
                        objReader["descripcion"].ToString(),
                        objReader["codigo"].ToString()
                    ));
                }
            }
            return list;
        }
    }
}
