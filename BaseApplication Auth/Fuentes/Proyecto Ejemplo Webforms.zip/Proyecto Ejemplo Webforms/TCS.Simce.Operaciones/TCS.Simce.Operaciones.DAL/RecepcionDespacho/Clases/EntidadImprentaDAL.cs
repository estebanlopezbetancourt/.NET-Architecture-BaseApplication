﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class EntidadImprentaDAL : IEntidadImprentaDAL
    {
        public List<EntidadImprentaEN> Listar()
        {

            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<EntidadImprentaEN> listado = new List<EntidadImprentaEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spEntidadImprentaListar");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    EntidadImprentaEN EntidadImprenta = new EntidadImprentaEN();

                    EntidadImprenta.Id = Convert.ToInt64(objReader["Id"].ToString());
                    EntidadImprenta.Descripcion = objReader["descripcion"].ToString();

                    listado.Add(EntidadImprenta);
                }
                return listado;
            }
        }
    }
}
