﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//MY NAME SPACES
using TCS.Simce.Operaciones.EN.RecepcionDespacho;

namespace TCS.Simce.Operaciones.DAL.RecepcionDespacho
{
    public class ReporteRecepcionDespachoSupervisoresDAL:IReporteRecepcionDespachoSupervisoresDAL
    {
        //DESPACHO HACIA SUPERVISORES
        public List<ReporteRecepcionDespachoSupervisoresEN> ReporteDespachoSupervisores(int nivel, int tipoPrueba, Int64 idSubCentro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoSupervisoresEN> listado = new List<ReporteRecepcionDespachoSupervisoresEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDespachoSupervisores");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@nivel", nivel);
                objComando.Parameters.AddWithValue("@tipoPrueba", tipoPrueba);                
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen ", 3);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idSubCentro);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", 4);
                

                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoSupervisoresEN informe = new ReporteRecepcionDespachoSupervisoresEN();


                    informe.Nivel = (objReader["Nivel"].ToString());
                    informe.SubCentro = objReader["SubCentro"].ToString();
                    informe.Supervisor = objReader["Supervisor"].ToString();
                    informe.TipoPrueba = (objReader["TipoPrueba"].ToString());
                    informe.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"].ToString());
                    informe.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"].ToString());
                    informe.Diferencia = Convert.ToInt64(objReader["Diferencia"].ToString());                  
                    
                    listado.Add(informe);
                }
                return listado;
            }
        }



        //RECEPCION DESDE SUPERVISORES
        public List<ReporteRecepcionDespachoSupervisoresEN> ReporteRecepcionSupervisores(int nivel, int tipoPrueba, Int64 idSubCentro)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            List<ReporteRecepcionDespachoSupervisoresEN> listado = new List<ReporteRecepcionDespachoSupervisoresEN>();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("ReporteRecepcionDesdeSupervisores");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@nivel", nivel);
                objComando.Parameters.AddWithValue("@tipoPrueba", tipoPrueba);
                objComando.Parameters.AddWithValue("@idTipoEntidadOrigen ", 3);
                objComando.Parameters.AddWithValue("@idEntidadOrigen", idSubCentro);
                objComando.Parameters.AddWithValue("@idTipoEntidadDestino", 4);


                objReader = objComando.ExecuteReader();

                while (objReader.Read())
                {
                    ReporteRecepcionDespachoSupervisoresEN informe = new ReporteRecepcionDespachoSupervisoresEN();


                    informe.Nivel = (objReader["Nivel"].ToString());
                    informe.SubCentro = objReader["SubCentro"].ToString();
                    informe.Supervisor = objReader["Supervisor"].ToString();
                    informe.TipoPrueba = (objReader["TipoPrueba"].ToString());
                    informe.cantidadDespachada = Convert.ToInt64(objReader["cantidadDespachada"].ToString());
                    informe.cantidadRecepcionada = Convert.ToInt64(objReader["cantidadRecepcionada"].ToString());
                    informe.Diferencia = Convert.ToInt64(objReader["Diferencia"].ToString());

                    listado.Add(informe);
                }
                return listado;
            }
        }
    
    
    }
}
