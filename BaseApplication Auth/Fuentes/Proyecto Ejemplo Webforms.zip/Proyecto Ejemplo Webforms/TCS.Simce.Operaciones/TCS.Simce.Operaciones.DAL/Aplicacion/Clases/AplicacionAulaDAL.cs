﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.EN.Aplicacion;

namespace TCS.Simce.Operaciones.DAL.Aplicacion
{
    public class AplicacionAulaDAL : IAplicacionAulaDAL
    {
        public bool RegistrarAplicacionAula(RegistroAplicacionAulaEN registro)
        {
            bool seRegistro = false;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("spRegistrarAplicacionAula");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idAplicacionAula", registro.idAplicacionAula);
                objComando.Parameters.AddWithValue("@idCurso", registro.idCurso);
                objComando.Parameters.AddWithValue("@idNivel", registro.idNivel);
                objComando.Parameters.AddWithValue("@rbd", registro.Rbd);
                objComando.Parameters.AddWithValue("@dvRbd", registro.DvRbd);
                objComando.Parameters.AddWithValue("@idContenedorDia1", registro.idContenedorDia1);
                objComando.Parameters.AddWithValue("@idContenedorDia2", registro.idContenedorDia2);
                objComando.Parameters.AddWithValue("@letraCurso", registro.LetraCurso);
                objComando.Parameters.AddWithValue("@CantidadCuestionariosPAEntregados", registro.CantidadCuestionariosPAEntregados);
                objComando.Parameters.AddWithValue("@CantidadCuestionariosPARecibidos", registro.CantidadCuestionariosPARecibidos);
                objComando.Parameters.AddWithValue("@CantidadCuestionariosDocenteEntregados", registro.CantidadCuestionariosDocenteEntregados);
                objComando.Parameters.AddWithValue("@CantidadCuestionariosDocenteRecibidos", registro.CantidadCuestionariosDocenteRecibidos);
                objComando.Parameters.AddWithValue("@SerieCajaCursoDia1Contingencia", registro.SerieCajaCursoDia1Contingencia);
                objComando.Parameters.AddWithValue("@SerieDocumentoDesdeDia1Contingencia", registro.SerieDocumentoDesdeDia1Contingencia);
                objComando.Parameters.AddWithValue("@SerieDocumentoHastaDia1Contingencia", registro.SerieDocumentoHastaDia1Contingencia);
                objComando.Parameters.AddWithValue("@SerieCajaCursoDia2Contingencia", registro.SerieCajaCursoDia2Contingencia);
                objComando.Parameters.AddWithValue("@SerieDocumentoDesdeDia2Contingencia", registro.SerieDocumentoDesdeDia2Contingencia);
                objComando.Parameters.AddWithValue("@SerieDocumentoHastaDia2Contingencia", registro.SerieDocumentoHastaDia2Contingencia);
                objComando.Parameters.AddWithValue("@SerieCajaCursoDia1Retorno", registro.SerieCajaCursoDia1Retorno);
                objComando.Parameters.AddWithValue("@SerieCajaCursoDia2Retorno", registro.SerieCajaCursoDia2Retorno);
                objComando.Parameters.AddWithValue("@aplicoExperimental", registro.AplicoExperimental);
                objComando.Parameters.AddWithValue("@aplicoCurso", registro.AplicoCensal);
                objComando.Parameters.AddWithValue("@aplicoSesionComplementaria", registro.AplicoSesionComplementaria);
                objComando.Parameters.AddWithValue("@observacion", registro.Observacion);

                int rows = objComando.ExecuteNonQuery();
                if (rows >= 1)
                    seRegistro = true;
            }
            return seRegistro;
        }

        public RegistroAplicacionAulaEN BuscarDatosAplicacionAula(int idNivel, int rbd, string letraCurso)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            RegistroAplicacionAulaEN registro = new RegistroAplicacionAulaEN();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spBuscarDatosAplicacionAula");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@rbd", rbd);
                objComando.Parameters.AddWithValue("@letraCurso", letraCurso);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    if (objReader["idAplicacionAula"].ToString() != "")
                    {
                        registro.idAplicacionAula = Convert.ToInt32(objReader["idAplicacionAula"].ToString());
                    }
                    if (objReader["idCurso"].ToString() != "")
                    {
                        registro.idCurso = Convert.ToInt32(objReader["idCurso"].ToString());
                    }
                    if (objReader["rbd"].ToString() != "")
                    {
                        registro.Rbd = Convert.ToInt32(objReader["rbd"].ToString());
                    }
                    if (objReader["idNivel"].ToString() != "")
                    {
                        registro.idNivel = Convert.ToInt32(objReader["idNivel"].ToString());
                    }
                    if (objReader["idContenedorDia1"].ToString() != "")
                    {
                        registro.idContenedorDia1 = Convert.ToInt32(objReader["idContenedorDia1"].ToString());
                    }
                    if (objReader["idContenedorDia2"].ToString() != "")
                    {
                        registro.idContenedorDia2 = Convert.ToInt32(objReader["idContenedorDia2"].ToString());
                    }
                    registro.DvRbd = objReader["dvRbd"].ToString();
                    registro.LetraCurso = objReader["letraCurso"].ToString();
                    if (objReader["CantidadCuestionariosPAEntregados"].ToString() != "")
                    {
                        registro.CantidadCuestionariosPAEntregados = Convert.ToInt32(objReader["CantidadCuestionariosPAEntregados"].ToString());
                    }
                    if (objReader["CantidadCuestionariosPARecibidos"].ToString() != "")
                    {
                        registro.CantidadCuestionariosPARecibidos = Convert.ToInt32(objReader["CantidadCuestionariosPARecibidos"].ToString());
                    }
                    if (objReader["CantidadCuestionariosDocenteEntregados"].ToString() != "")
                    {
                        registro.CantidadCuestionariosDocenteEntregados = Convert.ToInt32(objReader["CantidadCuestionariosDocenteEntregados"].ToString());
                    }
                    if (objReader["CantidadCuestionariosDocenteRecibidos"].ToString() != "")
                    {
                        registro.CantidadCuestionariosDocenteRecibidos = Convert.ToInt32(objReader["CantidadCuestionariosDocenteRecibidos"].ToString());
                    }
                    if (objReader["dia1serieCajaCursoContingencia"].ToString() != "")
                    {
                        registro.SerieCajaCursoDia1Contingencia = Convert.ToInt32(objReader["dia1serieCajaCursoContingencia"].ToString());
                    }
                    if (objReader["dia1serieDocumentoDesdeContingencia"].ToString() != "")
                    {
                        registro.SerieDocumentoDesdeDia1Contingencia = Convert.ToInt32(objReader["dia1serieDocumentoDesdeContingencia"].ToString());
                    }
                    if (objReader["dia1serieDocumentoHastaContingencia"].ToString() != "")
                    {
                        registro.SerieDocumentoHastaDia1Contingencia = Convert.ToInt32(objReader["dia1serieDocumentoHastaContingencia"].ToString());
                    }
                    if (objReader["dia2serieCajaCursoContingencia"].ToString() != "")
                    {
                        registro.SerieCajaCursoDia2Contingencia = Convert.ToInt32(objReader["dia2serieCajaCursoContingencia"].ToString());
                    }
                    if (objReader["dia2serieDocumentoDesdeContingencia"].ToString() != "")
                    {
                        registro.SerieDocumentoDesdeDia2Contingencia = Convert.ToInt32(objReader["dia2serieDocumentoDesdeContingencia"].ToString());
                    }
                    if (objReader["dia2serieDocumentoHastaContingencia"].ToString() != "")
                    {
                        registro.SerieDocumentoHastaDia2Contingencia = Convert.ToInt32(objReader["dia2serieDocumentoHastaContingencia"].ToString());
                    }
                    if (objReader["dia1serieCajaCursoRetorno"].ToString() != "")
                    {
                        registro.SerieCajaCursoDia1Retorno = Convert.ToInt32(objReader["dia1serieCajaCursoRetorno"].ToString());
                    }
                    if (objReader["dia2serieCajaCursoRetorno"].ToString() != "")
                    {
                        registro.SerieCajaCursoDia2Retorno = Convert.ToInt32(objReader["dia2serieCajaCursoRetorno"].ToString());
                    }
                    if (objReader["aplicoExperimental"].ToString() != "")
                    {
                        registro.AplicoExperimental = Convert.ToInt32(objReader["aplicoExperimental"].ToString());
                    }
                    if (objReader["aplicoCurso"].ToString() != "")
                    {
                        registro.AplicoCensal = Convert.ToInt32(objReader["aplicoCurso"].ToString());
                    }
                    if (objReader["aplicoSesionComplementaria"].ToString() != "")
                    {
                        registro.AplicoSesionComplementaria = Convert.ToInt32(objReader["aplicoSesionComplementaria"].ToString());
                    }
                    registro.Observacion = objReader["observacion"].ToString();
                }
            }
            return registro;
        }

        public CursoContenedoresEN BuscarCurso(CursoContenedoresEN curso)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            CursoContenedoresEN cursoEncontrado = new CursoContenedoresEN();
            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spBuscarCurso");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idNivel", curso.IdNivel);
                objComando.Parameters.AddWithValue("@rbd", curso.Rbd);
                objComando.Parameters.AddWithValue("@letraCurso", curso.LetraCurso);
                objComando.Parameters.AddWithValue("@serieCajaCursoBusqueda", curso.SerieCajaCurso);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    cursoEncontrado.IdNivel = curso.IdNivel;
                    cursoEncontrado.Rbd = curso.Rbd;
                    cursoEncontrado.LetraCurso = curso.LetraCurso;
                    cursoEncontrado.SerieCajaCurso = curso.SerieCajaCurso;

                    if (objReader["IdCurso"].ToString() != "")
                    {
                        cursoEncontrado.IdCurso = Convert.ToInt32(objReader["IdCurso"].ToString());
                    }
                    if (objReader["serieCajaCurso"].ToString() != "")
                    {
                        cursoEncontrado.SerieCajaCurso = Convert.ToInt32(objReader["serieCajaCurso"].ToString());
                    }
                    cursoEncontrado.DvRbd = objReader["dvRbd"].ToString();
                }
            }
            return cursoEncontrado;
        }

        public DatosContenedorEN BuscarDatosContenedor(DatosContenedorEN contenedor)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            DatosContenedorEN contenedorEncontrado = new DatosContenedorEN();
            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spBuscarDatosContenedor");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idNivel", contenedor.IdNivel);
                objComando.Parameters.AddWithValue("@idTipoDistribucion", contenedor.IdTipoDistribucion);
                objComando.Parameters.AddWithValue("@idTipoMaterial", contenedor.IdTipoMaterial);
                objComando.Parameters.AddWithValue("@dia", contenedor.Dia);
                objComando.Parameters.AddWithValue("@serieCajaCursoBusqueda", contenedor.SerieCajaCurso);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    contenedorEncontrado.IdNivel = contenedor.IdNivel;
                    contenedorEncontrado.IdTipoDistribucion = contenedor.IdTipoDistribucion;
                    contenedorEncontrado.IdTipoMaterial = contenedor.IdTipoMaterial;
                    contenedorEncontrado.Dia = contenedor.Dia;
                    contenedorEncontrado.SerieCajaCurso = contenedor.SerieCajaCurso;

                    if (objReader["idContenedor"].ToString() != "")
                    {
                        contenedorEncontrado.IdContenedor = Convert.ToInt32(objReader["idContenedor"].ToString());
                    }
                    if (objReader["serieDocumentoDesde"].ToString() != "")
                    {
                        contenedorEncontrado.SerieDocumentoDesde = Convert.ToInt32(objReader["serieDocumentoDesde"].ToString());
                    }
                    if (objReader["serieDocumentoHasta"].ToString() != "")
                    {
                        contenedorEncontrado.SerieDocumentoHasta = Convert.ToInt32(objReader["serieDocumentoHasta"].ToString());
                    }
                }
            }
            return contenedorEncontrado;
        }

        public RegistroVisitaPreviaEN BuscarDatosVisitaPrevia(int idNivel, int rbd, string letraCurso)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();
            RegistroVisitaPreviaEN registro = new RegistroVisitaPreviaEN();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("spBuscarDatosVisitaPrevia");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idNivel", idNivel);
                objComando.Parameters.AddWithValue("@rbd", rbd);
                objComando.Parameters.AddWithValue("@letraCurso", letraCurso);

                objReader = objComando.ExecuteReader();

                if (objReader.Read())
                {
                    if (objReader["idAplicacionAula"].ToString() != "")
                    {
                        registro.idAplicacionAula = Convert.ToInt32(objReader["idAplicacionAula"].ToString());
                    }
                    if (objReader["idCurso"].ToString() != "")
                    {
                        registro.idCurso = Convert.ToInt32(objReader["idCurso"].ToString());
                    }
                    if (objReader["rbd"].ToString() != "")
                    {
                        registro.Rbd = Convert.ToInt32(objReader["rbd"].ToString());
                    }
                    if (objReader["idNivel"].ToString() != "")
                    {
                        registro.idNivel = Convert.ToInt32(objReader["idNivel"].ToString());
                    }
                    registro.DvRbd = objReader["dvRbd"].ToString();
                    registro.LetraCurso = objReader["letraCurso"].ToString();
                    if (objReader["visitaPreviaFechaRealizacion"].ToString() != "")
                    {
                        registro.FechaRealizacion = Convert.ToDateTime(objReader["visitaPreviaFechaRealizacion"].ToString());
                    }

                    if (objReader["visitaPreviaResultadoFinal"].ToString() == "S")
                    {
                        registro.AplicoVisitaPrevia = 1;
                    }
                    else
                    {
                        registro.AplicoVisitaPrevia = 0;
                    }
                    registro.Observacion = objReader["observacion"].ToString();
                }
            }
            return registro;
        }


        public bool RegistrarVisitaPrevia(RegistroVisitaPreviaEN registro)
        {
            bool seRegistro = false;
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlCommand objComando = new SqlCommand("spRegistrarVisitaPrevia");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;

                objComando.Parameters.AddWithValue("@idAplicacionAula", registro.idAplicacionAula);
                objComando.Parameters.AddWithValue("@idCurso", registro.idCurso);
                objComando.Parameters.AddWithValue("@idNivel", registro.idNivel);
                objComando.Parameters.AddWithValue("@rbd", registro.Rbd);
                objComando.Parameters.AddWithValue("@dvRbd", registro.DvRbd);
                objComando.Parameters.AddWithValue("@letraCurso", registro.LetraCurso);
                objComando.Parameters.AddWithValue("@visitaPreviaFechaRealizacion", registro.FechaRealizacion);

                if(registro.AplicoVisitaPrevia == 1)
                {
                    objComando.Parameters.AddWithValue("@visitaPreviaResultadoFinal", "S");                
                }
                else
                {
                    objComando.Parameters.AddWithValue("@visitaPreviaResultadoFinal", "N");                
                }

                objComando.Parameters.AddWithValue("@observacion", registro.Observacion);

                int rows = objComando.ExecuteNonQuery();
                if (rows >= 1)
                    seRegistro = true;
            }
            return seRegistro;
        }
    }
}
