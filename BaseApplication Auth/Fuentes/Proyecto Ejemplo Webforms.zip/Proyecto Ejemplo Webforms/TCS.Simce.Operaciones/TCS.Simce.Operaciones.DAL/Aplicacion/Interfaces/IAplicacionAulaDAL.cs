﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCS.Simce.Operaciones.EN.Aplicacion;

namespace TCS.Simce.Operaciones.DAL.Aplicacion
{
    public interface IAplicacionAulaDAL
    {
        bool RegistrarAplicacionAula(RegistroAplicacionAulaEN registro);
        RegistroAplicacionAulaEN BuscarDatosAplicacionAula(int idNivel, int rbd, string letraCurso);
        DatosContenedorEN BuscarDatosContenedor(DatosContenedorEN contenedor);
        CursoContenedoresEN BuscarCurso(CursoContenedoresEN curso);
        RegistroVisitaPreviaEN BuscarDatosVisitaPrevia(int idNivel, int rbd, string letraCurso);
        bool RegistrarVisitaPrevia(RegistroVisitaPreviaEN registro);
    }
}
