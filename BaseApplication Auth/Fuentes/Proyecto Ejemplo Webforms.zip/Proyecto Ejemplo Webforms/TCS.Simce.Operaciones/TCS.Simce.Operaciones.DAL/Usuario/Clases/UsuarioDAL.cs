﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using TCS.Simce.Operaciones.EN.Usuario;

namespace TCS.Simce.Operaciones.DAL.Usuario
{
    public class UsuarioDAL : IUsuarioDAL
    {
        public UsuarioEN Buscar(string idUsuario)
        {
            string conn = ConfigurationManager.ConnectionStrings["StrConnection"].ToString();

            using (SqlConnection objConexion = new SqlConnection(conn))
            {
                objConexion.Open();

                SqlDataReader objReader = null;

                SqlCommand objComando = new SqlCommand("UsuarioRetornaNombre");
                objComando.Connection = objConexion;
                objComando.CommandType = CommandType.StoredProcedure;
                objComando.Parameters.AddWithValue("@idUsuario", idUsuario);

                objReader = objComando.ExecuteReader();

                UsuarioEN Usuario = new UsuarioEN();
                
                if (objReader.Read())
                {
                    Usuario.NombreUsuario = objReader["NombreUsuario"].ToString();
                    Usuario.RutUsuario = idUsuario;
                    Usuario.DvUsuario = DigitoVerificador(Convert.ToInt64(idUsuario));
                    
                }
                else
                {
                    Usuario = null;

                }
                return Usuario;
            }
        }

        public string DigitoVerificador(long rut)
        {
            long Digito;
            long Contador;
            long Multiplo;
            long Acumulador;
            string RutDigito;

            Contador = 2;
            Acumulador = 0;

            while (rut != 0)
            {
                Multiplo = (rut % 10) * Contador;
                Acumulador = Acumulador + Multiplo;
                rut = rut / 10;
                Contador = Contador + 1;
                if (Contador == 8)
                {
                    Contador = 2;
                }

            }

            Digito = 11 - (Acumulador % 11);
            RutDigito = Digito.ToString().Trim();
            if (Digito == 10)
            {
                RutDigito = "K";
            }
            if (Digito == 11)
            {
                RutDigito = "0";
            }
            return (RutDigito);
        }
    }
}
