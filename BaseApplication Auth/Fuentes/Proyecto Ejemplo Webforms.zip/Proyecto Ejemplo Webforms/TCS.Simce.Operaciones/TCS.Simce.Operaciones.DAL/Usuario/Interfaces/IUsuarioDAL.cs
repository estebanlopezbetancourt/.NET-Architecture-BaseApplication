﻿using TCS.Simce.Operaciones.EN.Usuario;

namespace TCS.Simce.Operaciones.DAL.Usuario
{
    public interface IUsuarioDAL
    {
        UsuarioEN Buscar(string idUsuario);

    }
}
