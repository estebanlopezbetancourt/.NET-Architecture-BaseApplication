﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BaseApplication.MvcWebHost.Areas.Error.Controllers
{
    public class ErrorHandlerController : Controller
    {
        public ActionResult Default()
        {
            return this.View();
        }
        public ActionResult NotFound()
        {
            return this.View();
        }
        public ActionResult AccessDenied()
        {
            return this.View();
        }
	}
}