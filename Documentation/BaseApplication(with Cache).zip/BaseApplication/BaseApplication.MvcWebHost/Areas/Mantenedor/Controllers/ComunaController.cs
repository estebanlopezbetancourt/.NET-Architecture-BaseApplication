﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BaseApplication.MvcWebHost.Areas.Mantenedor.Controllers
{
    public class ComunaController : Controller
    {
        private SL.Services.IRegionComunaManager regionComunaMgr;

        public ComunaController()
        {
            this.regionComunaMgr = BLL.ServiceAgent.GetRegionComunaManager();
        }
        //
        // GET: /Finanzas/MyTest/
        public ActionResult Index()
        {
            var comunaCollection = this.regionComunaMgr.GetComunaCollection();
            return View(comunaCollection);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(SL.DTO.ComunaDTO model)
        {
            if (!this.ModelState.IsValid)
            {
                return View();
            }

            this.regionComunaMgr.CreateComuna(model);
            
            return RedirectToAction("Index");

        }

        public ActionResult Edit(int id)
        {
            var model = regionComunaMgr.GetComunaById(id);

            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(SL.DTO.ComunaDTO model)
        {
            if (!this.ModelState.IsValid)
            {
                return View();
            }

            this.regionComunaMgr.UpdateComuna(model);

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            var model = this.regionComunaMgr.GetComunaById(id);

            return View(model);
        }

        [HttpPost]
        public ActionResult ConfirmDelete(int id)
        {
            this.regionComunaMgr.RemoveComuna(id);
            return RedirectToAction("Index");
        }

        public ActionResult CreateSessionVar()
        {
            //vamos a crear una variable de sesión aquí; internamente será guardada en los cluster de Cache de AppFabric
            HttpContext.Session["mySession"] = "Hola Mundo";
            return RedirectToAction("Index");
        }

        public ActionResult CheckSessionVar()
        {
            //recuperamos desde Session, internamente desde el cluster de mem AppFabric Cache
            String holaMundo = (String)HttpContext.Session["mySession"];
            return RedirectToAction("Index");
        }
	}
}