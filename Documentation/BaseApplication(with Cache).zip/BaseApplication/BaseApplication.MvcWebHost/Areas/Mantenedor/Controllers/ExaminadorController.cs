﻿using BaseApplication.MvcWebHost.Areas.Mantenedor.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PagedList;
using iTextSharp.text.pdf;
using iTextSharp.text;
using System.IO;

namespace BaseApplication.MvcWebHost.Areas.Mantenedor.Controllers
{
    public class ExaminadorController : Controller
    {
        BaseApplication.SL.Services.IExaminadorManager examinadorMgr;
        BaseApplication.SL.Services.IRegionComunaManager regionComunaMgr;
        public ExaminadorController()
        {
            this.examinadorMgr = BaseApplication.BLL.ServiceAgent.GetExaminadorManager();
            this.regionComunaMgr = BaseApplication.BLL.ServiceAgent.GetRegionComunaManager();
        }

        //
        // GET: /Mantenedor/Examinador/
        /// <summary>
        /// Devuelve una vista cargada con el listado de examinadores y filtro de búsqueda sobre la misma
        /// </summary>
        /// <returns></returns>
        public ActionResult Index(OperationMessageId? message,
                                    SL.DTO.ExaminadorFilterDTO filterDto,
                                    string sortOrder, int? page)
        {
            //estrategia para desplegar el resultado de las operaciones a lo largo de las acciones de este controlador
            ViewBag.StatusMessage =
                message == OperationMessageId.InsertSuccess ? "El examinador ha sido creado con éxito."
                : message == OperationMessageId.DeleteSuccess ? "El examinador ha sido eliminado con éxito."
                : message == OperationMessageId.UpdateSuccess ? "El examinador ha sido actualizado con éxito."
                : message == OperationMessageId.Error ? "No fue posible realizar la operación."
                : "";

            //modelo de la vista
            IEnumerable<SL.DTO.ExaminadorDTO> examinadorCollection = new List<SL.DTO.ExaminadorDTO>();

            //filtering
            if (filterDto == null) 
                filterDto = new SL.DTO.ExaminadorFilterDTO();

            ViewBag.ExaminadorFilter = filterDto;
            examinadorCollection = this.examinadorMgr.GetExaminadoresByFilter(filterDto);

            //sorting
            sortOrder = String.IsNullOrEmpty(sortOrder) ? "Rut" : sortOrder;
            ViewBag.CurrentSort = sortOrder;

            ViewBag.RutSortParm = sortOrder == "Rut" ? "Rut_desc" : "Rut";
            ViewBag.NameSortParm = sortOrder == "Name" ? "Name_desc" : "Name";
            ViewBag.LastNameSortParm = sortOrder == "LastName" ? "LastName_desc" : "LastName";
            ViewBag.SexSortParm = sortOrder == "Sex" ? "Sex_desc" : "Sex";
            ViewBag.BirthdateSortParm = sortOrder == "Birthdate" ? "Birthdate_desc" : "Birthdate";
            ViewBag.PaymentAmountSortParm = sortOrder == "PaymentAmount" ? "PaymentAmount_desc" : "PaymentAmount";
            ViewBag.ComunaDescriptionSortParm = sortOrder == "ComunaDescription" ? "ComunaDescription_desc" : "ComunaDescription";

            switch (sortOrder)
            {
                case "Rut":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.Rut);
                    break;
                case "Rut_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.Rut);
                    break;

                case "Name":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.Name);
                    break;
                case "Name_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.Name);
                    break;

                case "LastName":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.LastName);
                    break;
                case "LastName_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.LastName);
                    break;

                case "Sex":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.Sex);
                    break;
                case "Sex_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.Sex);
                    break;

                case "Birthdate":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.Birthdate);
                    break;
                case "Birthdate_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.Birthdate);
                    break;

                case "PaymentAmount":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.PaymentAmount);
                    break;
                case "PaymentAmount_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.PaymentAmount);
                    break;

                case "ComunaDescription":
                    examinadorCollection = examinadorCollection.OrderBy(m => m.ComunaDescription);
                    break;
                case "ComunaDescription_desc":
                    examinadorCollection = examinadorCollection.OrderByDescending(m => m.ComunaDescription);
                    break;

                default:
                    examinadorCollection = examinadorCollection.OrderBy(m => m.Rut);
                    break;
            }

            int pageSize = 3;
            int pageNumber = (page ?? 1);
            return View(examinadorCollection.ToPagedList(pageNumber, pageSize)); //using PagedList;

            //return View(examinadorCollection);
        }

        //
        // GET: /Mantenedor/Examinador/Create
        /// <summary>
        /// Acción GET que devuelve la vista con el formulario
        /// </summary>
        /// <returns></returns>
        public ActionResult Create()
        {
            ViewBag.regionCollection = this.regionComunaMgr.GetRegionCollection().Select(x => new SelectListItem
                                    {
                                        Text = x.RegionDescription,
                                        Value = x.Id.ToString()
                                    });

            return View();
        }

        /// <summary>
        /// Acción POST que envía formlario con datos (viewModel) para la creación del Examinador
        /// </summary>
        /// <param name="model">modelo que representa al formulario</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Create(SL.DTO.ExaminadorDTO model)
        {
            if (!BaseApplication.Crosscutting.Security.RutHelper.IsRutOk(model.Rut, model.RutDv))
            {
                this.ModelState.AddModelError("RutDv", "El rut ingresado es inválido.");
            }

            if (!this.ModelState.IsValid)
            {
                ViewBag.regionCollection = this.regionComunaMgr.GetRegionCollection().Select(x => new SelectListItem
                {
                    Text = x.RegionDescription,
                    Value = x.Id.ToString()
                });
                return View(model);
            }


            this.examinadorMgr.AddExaminador(model);

            return RedirectToAction("Index", new { Message = OperationMessageId.InsertSuccess });
        }

        //
        // GET: /Mantenedor/Examinador/Details/{id}
        /// <summary>
        /// Acción GET que muestra los detalles de un examinador, recibe el id como parámetro
        /// </summary>
        /// <param name="id">Id del Examinador a revisar</param>
        /// <returns></returns>
        public ActionResult Details(int id)
        {
            var model = this.examinadorMgr.GetExaminadorById(id);
            var comuna = this.regionComunaMgr.GetComunaCollection().First(x => x.Id == model.ComunaId);
            ViewBag.regionCollection = this.regionComunaMgr.GetRegionCollection().Select(x => new SelectListItem
            {
                Text = x.RegionDescription,
                Value = x.Id.ToString(),
                Selected = x.Id == comuna.RegionId
            });

            ViewBag.comunaCollection = this.regionComunaMgr.GetComunasByRegionId(comuna.RegionId).Select(x => new SelectListItem
            {
                Text = x.ComunaDescription,
                Value = x.Id.ToString(),
                Selected = x.Id == model.ComunaId
            });

            return View(model);
        }

        /// <summary>
        /// Acción POST que envía formulario con datos (viewModel) para la edición del Examinador
        /// </summary>
        /// <param name="model">modelo que representa al formulario</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult Details(SL.DTO.ExaminadorDTO model)
        {
            if (!BaseApplication.Crosscutting.Security.RutHelper.IsRutOk(model.Rut, model.RutDv))
            {
                this.ModelState.AddModelError("RutDv", "El rut ingresado es inválido.");
            }

            if (!this.ModelState.IsValid)
            {
                ViewBag.regionCollection = this.regionComunaMgr.GetRegionCollection().Select(x => new SelectListItem
                {
                    Text = x.RegionDescription,
                    Value = x.Id.ToString()
                });

                var defaultComunaItem = new SelectListItem() { Text = "Seleccione una Comuna", Value = string.Empty };
                ViewBag.comunaCollection = new SelectList(new[] { defaultComunaItem });

                return View(model);
            }


            this.examinadorMgr.UpdateExaminador(model);

            return RedirectToAction("Index", new { Message = OperationMessageId.UpdateSuccess });
        }

        //
        // GET: /Mantenedor/Examinador/Delete/{id}
        /// <summary>
        /// Acción GET que muestra la pantalla de confirmación para la eliminación del Examinador
        /// </summary>
        /// <param name="id">Id del Examinador a eliminar</param>
        /// <returns></returns>
        public ActionResult Delete(int id)
        {
            var model = this.examinadorMgr.GetExaminadorById(id);

            return View(model);
        }

        /// <summary>
        /// Acción POST que elimina al examinador
        /// </summary>
        /// <param name="id">Id del Examinador a eliminar</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult ConfirmDelete(int id)
        {
            this.examinadorMgr.RemoveExaminador(id);

            return RedirectToAction("Index", new { Message = OperationMessageId.DeleteSuccess });
        }

        public JsonResult GetComunasByRegion(int idRegion)
        {
            var comunaCollection = this.regionComunaMgr.GetComunasByRegionId(idRegion);
            return Json(comunaCollection, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ExportDataXLS(SL.DTO.ExaminadorFilterDTO filterDto)
        {
            IEnumerable<SL.DTO.ExaminadorDTO> dataCollection = new List<SL.DTO.ExaminadorDTO>();

            if (filterDto != null)
                dataCollection = this.examinadorMgr.GetExaminadoresByFilter(filterDto);
            else
                dataCollection = this.examinadorMgr.GetExaminadoresCollection();

            System.Web.UI.WebControls.GridView gv = new System.Web.UI.WebControls.GridView();
            gv.DataSource = dataCollection;
            gv.DataBind();
            Response.ClearContent();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment; filename=Marklist.xls");
            Response.ContentType = "application/ms-excel";
            Response.Charset = "";
            System.IO.StringWriter sw = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter htw = new System.Web.UI.HtmlTextWriter(sw);
            gv.RenderControl(htw);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();

            return RedirectToAction("Index");
        }

        /// <summary>
        /// Este es un ejemplo para crear un archivo que se pueda abrir en Excel, 
        /// con la misma información que se despliega en la tabla html generada en la vista Index
        /// </summary>
        /// <param name="filterDto"> el Filtro de búsqueda que se debe considerar para la exportación de datos</param>
        public void ExportDataCSV(SL.DTO.ExaminadorFilterDTO filterDto)
        {
            IEnumerable<SL.DTO.ExaminadorDTO> dataCollection = new List<SL.DTO.ExaminadorDTO>();

            if (filterDto != null)
                dataCollection = this.examinadorMgr.GetExaminadoresByFilter(filterDto);
            else
                dataCollection = this.examinadorMgr.GetExaminadoresCollection();

            System.IO.StringWriter sw = new System.IO.StringWriter();

            //http://kb.paessler.com/en/topic/2293-i-have-trouble-opening-csv-files-with-microsoft-excel-is-there-a-quick-way-to-fix-this
            //Add an extra line to your CSV file to tell Excel what the seperator is. Add the folowing line to the top of your CSV file:
            sw.WriteLine("sep=,");

            //First line for column names
            sw.WriteLine("\"Rut\",\"Nombre\",\"Apellido\",\"Dirección\",\"Sexo\",\"Fecha Nacimiento\",\"Telefono Celular\",\"Correo electrónico\",\"Monto Pago\",\"Comuna\"");

            foreach (SL.DTO.ExaminadorDTO item in dataCollection)
            {
                sw.WriteLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\"",
                                           item.Rut + "-" + item.RutDv,
                                           item.Name,
                                           item.LastName,
                                           item.Address,
                                           item.Sex,
                                           item.Birthdate.ToShortDateString(),
                                           item.Cellphone,
                                           item.Email,
                                           item.PaymentAmount,
                                           item.ComunaDescription));
            }

            //we prepare output
            Response.AddHeader("Content-Disposition", "attachment; filename=test.csv");
            Response.ContentType = "text/csv";
            Response.Charset = "utf-8";
            Response.ContentEncoding = System.Text.Encoding.Unicode;
            Response.Write(sw);
            Response.End();
        }

        public ActionResult ExportDataPDF(SL.DTO.ExaminadorFilterDTO filterDto)
        {
            IEnumerable<SL.DTO.ExaminadorDTO> dataCollection = new List<SL.DTO.ExaminadorDTO>();

            if (filterDto != null)
                dataCollection = this.examinadorMgr.GetExaminadoresByFilter(filterDto);
            else
                dataCollection = this.examinadorMgr.GetExaminadoresCollection();

            //Preparing PDF Table
            int numberColumns = 10;
            PdfPTable table = new PdfPTable(numberColumns);
            table.DefaultCell.Border = 1;
            table.WidthPercentage = 95;

            //Preparing Table Header

            string imageURL = Server.MapPath("/Content/logo_simce_medium.png");
            iTextSharp.text.Image logo = iTextSharp.text.Image.GetInstance(imageURL);
            PdfPCell imageTitleCell = new PdfPCell(logo);
            imageTitleCell.Colspan = 3;
            imageTitleCell.HorizontalAlignment = Element.ALIGN_CENTER;
            imageTitleCell.VerticalAlignment = Element.ALIGN_MIDDLE;
            table.AddCell(imageTitleCell);

            var titleFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 16);
            PdfPCell titleCell = new PdfPCell(new Phrase("Reporte Examinadores", titleFont));
            titleCell.Colspan = 7;
            titleCell.HorizontalAlignment = Element.ALIGN_CENTER;
            titleCell.VerticalAlignment = Element.ALIGN_MIDDLE;
            titleCell.BackgroundColor = BaseColor.LIGHT_GRAY;
            table.AddCell(titleCell);

            PdfPCell spaceBetweenCell = new PdfPCell(new Phrase(" "));
            spaceBetweenCell.Colspan = 10;
            spaceBetweenCell.Border = 0;
            table.AddCell(spaceBetweenCell);


            var normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);
            var boldFont = FontFactory.GetFont(FontFactory.HELVETICA_BOLD, 10);

            //Preparing table column header

            table.AddCell(new Phrase("Rut", boldFont));
            table.AddCell(new Phrase("Nombre", boldFont));
            table.AddCell(new Phrase("Apellido", boldFont));
            table.AddCell(new Phrase("Dirección", boldFont));
            table.AddCell(new Phrase("Sexo", boldFont));
            table.AddCell(new Phrase("Fecha Nacimiento", boldFont));
            table.AddCell(new Phrase("Telefono Celular", boldFont));
            table.AddCell(new Phrase("Correo electrónico", boldFont));
            table.AddCell(new Phrase("Monto Pago", boldFont));
            table.AddCell(new Phrase("Comuna", boldFont));

            //Filling table with data
            foreach (var data in dataCollection)
            {
                table.AddCell(new Phrase(string.Format("{0}-{1}", data.Rut, data.RutDv), normalFont));
                table.AddCell(new Phrase(data.Name, normalFont));
                table.AddCell(new Phrase(data.LastName, normalFont));
                table.AddCell(new Phrase(data.Address, normalFont));
                table.AddCell(new Phrase(data.Sex, normalFont));
                table.AddCell(new Phrase(data.Birthdate.ToShortDateString(), normalFont));
                table.AddCell(new Phrase(data.Cellphone.ToString(), normalFont));
                table.AddCell(new Phrase(data.Email, normalFont));
                table.AddCell(new Phrase(data.PaymentAmount.ToString(), normalFont));
                table.AddCell(new Phrase(data.ComunaDescription, normalFont));
            }

            byte[] byteResult;
            var doc = new Document();
            doc.SetPageSize(iTextSharp.text.PageSize.A4.Rotate()); //rotate to horizontal landscape

            using (var stream = new MemoryStream())
            {
                var writer = PdfWriter.GetInstance(doc, stream);
                doc.Open();
                doc.Add(table);
                doc.Close();
                byteResult = stream.ToArray();
            }

            return File(byteResult, "application/pdf", "test.pdf");
        }
    }
}