﻿using System.Web.Mvc;

namespace BaseApplication.MvcWebHost.Areas.Mantenedor
{
    public class MantenedorAreaRegistration : AreaRegistration 
    {
        public override string AreaName 
        {
            get 
            {
                return "Mantenedor";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context) 
        {
            context.MapRoute(
                "Mantenedor_default",
                "Mantenedor/{controller}/{action}/{id}",
                new { action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}