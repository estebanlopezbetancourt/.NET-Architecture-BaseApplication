﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BaseApplication.MvcWebHost
{
    /// <summary>
    /// A custom Auth Attrib that overrides the ASP.NET MVC one, adding  a change to distinguish between
    /// Non-authenticated and/or Non-authorized
    /// </summary>
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class AuthorizeAttribute : System.Web.Mvc.AuthorizeAttribute
    {
        protected override void HandleUnauthorizedRequest(System.Web.Mvc.AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.IsAuthenticated)
            {
                //filterContext.Result = new System.Web.Mvc.HttpStatusCodeResult((int)System.Net.HttpStatusCode.Forbidden);
                //http://stackoverflow.com/questions/23565098/asp-net-mvc-5-custom-error-page
                throw new HttpException((int)System.Net.HttpStatusCode.Forbidden, "Forbidden");
            }
            else
            {
                base.HandleUnauthorizedRequest(filterContext);
            }
        }
    }
}