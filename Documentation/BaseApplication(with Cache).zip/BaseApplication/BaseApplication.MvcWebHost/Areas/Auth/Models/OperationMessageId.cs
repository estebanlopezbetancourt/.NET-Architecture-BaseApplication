﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BaseApplication.MvcWebHost.Areas.Auth.Models
{
    public enum OperationMessageId
    {
        InsertSuccess,
        UpdateSuccess,
        DeleteSuccess,
        Error
    }
}