﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BaseApplication.MvcWebHost.Areas.Auth.Models
{
    public class RoleViewModel
    {
        public string Id { get; set; }
        [Required(AllowEmptyStrings = false)]
        [Display(Name = "Nombre Rol")]
        public string Name { get; set; }
    }

    public class EditUserViewModel
    {
        public string Id { get; set; }

        [Required]
        [StringLength(8, ErrorMessage = "El {0} debe tener al menos {2} dígitos.", MinimumLength = 8)]
        [RegularExpression("^[0-9]+$")]
        [Display(Name = "Rut")]
        public string UserName { get; set; }

        [Required(AllowEmptyStrings = false, ErrorMessage = "El Dígito Verificador es requerido.")]
        public string VerificationDigit { get; set; }

        [Required(AllowEmptyStrings = false)]
        [Display(Name = "Email")]
        [EmailAddress]
        public string Email { get; set; }

        public IEnumerable<SelectListItem> RolesList { get; set; }
    }
}