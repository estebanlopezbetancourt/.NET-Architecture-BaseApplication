﻿using System.Web;
using System.Web.Mvc;

namespace BaseApplication.MvcWebHost
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            //filters.Add(new HandleErrorAttribute());
            filters.Add(new BaseApplication.MvcWebHost.Models.CustomHandleErrorAttribute());
        }
    }
}
