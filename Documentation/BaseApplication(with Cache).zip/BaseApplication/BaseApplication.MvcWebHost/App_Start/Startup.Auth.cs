﻿using Microsoft.AspNet.Identity;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Owin;

namespace BaseApplication.MvcWebHost
{
    public partial class Startup : BaseApplication.Crosscutting.Security.Auth.Startup
    {
        // For more information on configuring authentication, please visit http://go.microsoft.com/fwlink/?LinkId=301864
        public void ConfigureAuth(IAppBuilder app)
        {
            base.ConfigureAuth(app);
        }
    }
}