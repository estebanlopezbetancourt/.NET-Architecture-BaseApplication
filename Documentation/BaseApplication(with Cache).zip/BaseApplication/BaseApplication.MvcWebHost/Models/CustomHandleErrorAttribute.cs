﻿using Elmah;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace BaseApplication.MvcWebHost.Models
{
    public class CustomHandleErrorAttribute : HandleErrorAttribute
    {
        public override void OnException(ExceptionContext filterContext)
        {
            BaseApplication.Crosscutting.Logging.Log.Instance.Write("CustomHandleError", BaseApplication.Crosscutting.Logging.LogLevel.Error);
            BaseApplication.Crosscutting.Logging.Log.Instance.Exception(filterContext.Exception.Message, filterContext.Exception);

            if (!filterContext.HttpContext.Request.IsAjaxRequest())
            {
                string area = "Error";
                string controller = "ErrorHandler";
                string action = "Default";

                if (filterContext.Exception is System.Web.HttpException
                    && ((System.Web.HttpException)filterContext.Exception).GetHttpCode() == (int)System.Net.HttpStatusCode.Forbidden)
                {
                    action = "AccessDenied";
                }

                if (filterContext.Exception is System.Web.HttpException
                    && ((System.Web.HttpException)filterContext.Exception).GetHttpCode() == (int)System.Net.HttpStatusCode.NotFound)
                {
                    action = "NotFound";
                }

                //prepare redirect
                var routeValueDict = new RouteValueDictionary(
                    new { controller = controller, action = action });
                routeValueDict.Add("area", area);

                //redirect to error handler
                filterContext.Result = new RedirectToRouteResult(routeValueDict);

                // Stop any other exception handlers from running
                filterContext.ExceptionHandled = true;

                // CLear out anything already in the response
                filterContext.HttpContext.Response.Clear();
            } 
  

        }

        
    }
}