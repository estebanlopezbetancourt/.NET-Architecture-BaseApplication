﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseApplication.DAL.Implementations.EntityFramework
{
    /// <summary>
    /// Clase que implementa la interfaz IRolDAO usando EntityFramework
    /// </summary>
    internal class ComunaDAO : BaseDAO, Core.IDao.IComunaDAO
    {
        /// <summary>
        /// Constructor pasa arg por parametro a constructor de la clase Base
        /// </summary>
        /// <param name="context"></param>
        public ComunaDAO(Entities.SimceSampleDbConnection context) 
            : base(context) { }

        public IEnumerable<Entities.Comuna> GetAll()
        {
            return this.Context.Comuna;
        }

        public IEnumerable<Entities.Comuna> GetByRegionId(int regionId)
        {
            return this.Context.Comuna.Where(x => x.RegionId == regionId);
        }


        public void Create(Entities.Comuna comuna)
        {
            this.Context.Comuna.Add(comuna);
            this.Context.SaveChanges();
        }


        public void Update(Entities.Comuna comuna)
        {
            var entityFromDb = this.Context.Comuna.First(x => x.Id == comuna.Id);
            entityFromDb.ComunaDescription = comuna.ComunaDescription;
            entityFromDb.RegionId = comuna.RegionId;

            this.Context.SaveChanges();

        }

        public void Remove(int id)
        {
            var entityToRemove = this.Context.Comuna.First(x => x.Id == id);
            this.Context.Comuna.Remove(entityToRemove);
            this.Context.SaveChanges();
        }
    }
}
