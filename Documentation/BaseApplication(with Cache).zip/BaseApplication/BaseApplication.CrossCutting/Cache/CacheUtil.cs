﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.ApplicationServer.Caching;
using System.Threading;


namespace BaseApplication.Crosscutting.Cache
{
    /// <summary>
    /// Class that provide Cache managing, wrapping and implementing with AppFabric Cache
    /// </summary>
    public class CacheUtil
    {
        private string _cacheName = System.Configuration.ConfigurationManager.AppSettings["Core.Cache.Name"];
        private static DataCacheFactory _dataCacheFactory;
        private static DataCache _dataCache;
        private DataCache DataCache
        {
            get
            {
                if (_dataCache == null)
                {
                    InitDataCache();
                }
                return _dataCache;
            }
            set
            {
                _dataCache = value;
            }
        }

        private bool InitDataCache()
        {
            try
            {
                // We try to avoid creating many DataCacheFactory-ies
                if (_dataCacheFactory == null)
                {
                    // Disable tracing to avoid informational/verbose messages
                    DataCacheClientLogManager.ChangeLogLevel(System.Diagnostics.TraceLevel.Off);
                    // Use configuration from the application configuration file
                    _dataCacheFactory = new DataCacheFactory();
                }

                
                this.DataCache = _dataCacheFactory.GetCache(_cacheName);

                return true;
            }
            catch (DataCacheException)
            {
                _dataCache = null;
                throw;
            }
        }

        private object ReTryDataCacheOperation(Func<object> dataCacheOperation, DataCacheException prevException)
        {
            try
            {
                // We add retry, as it may happen,
                // that AppFabric cache is temporary unavailable:
                // See: http://msdn.microsoft.com/en-us/library/ff637716.aspx
                // Maybe adding more checks like: prevException.ErrorCode == DataCacheErrorCode.RetryLater

                // This ensures that once we access prop DataCache, new client will be generated
                _dataCache = null;

                Thread.Sleep(100);
                var result = dataCacheOperation.Invoke();

                //We can add some logging here, notifying that retry succeeded
                return result;
            }
            catch (DataCacheException)
            {
                _dataCache = null;
                throw;
            }
        }

        public void Put(string key, object value)
        {
            try
            {
                this.DataCache.Put(key, value);
            }
            catch (DataCacheException ex)
            {
                ReTryDataCacheOperation(() => this.DataCache.Put(key, value), ex);
            }
        }

        public void Add(string key, object value)
        {
            this.Put(key, value);
        }

        public object Get(string key)
        {
            return this.DataCache.Get(key);
        }
    }
}
