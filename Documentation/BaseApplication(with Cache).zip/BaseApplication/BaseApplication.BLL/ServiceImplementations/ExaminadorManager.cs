﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseApplication.BLL.ServiceImplementations
{
    internal class ExaminadorManager : SL.Services.IExaminadorManager
    {
        private DAL.Core.DataAccess dataAccess;
        private SL.Services.IRegionComunaManager regionComunaMgr;

        public ExaminadorManager()
        {
            //instanciamos nuestro dataAccess que será compartido en esta llamada por este mgr
            this.dataAccess = new DAL.Core.DataAccess();
            regionComunaMgr = ServiceAgent.GetRegionComunaManager();
        }

        public IEnumerable<SL.DTO.ExaminadorDTO> GetExaminadoresCollection()
        {
            IList<SL.DTO.ExaminadorDTO> examinadorCollection = new List<SL.DTO.ExaminadorDTO>();

            //primero manejamos una colección que representa a todos los elementos de la bd para Examinador
            var examinadores = this.dataAccess.ExaminadorDAO.GetAll();
            //obtenemos y cargamos descripcion Comuna a partir de Mgr RegionComuna (que maneja cache)
            var comunas = regionComunaMgr.GetComunaCollection();

            //mapeamos los elementos de entidad a dto
            foreach (var entity in examinadores)
            {
                var dto = ModelMapper.ExaminadorMapper.EntityToDto(entity);

                //obtenemos y cargamos descripcion Comuna a partir de Mgr RegionComuna (que maneja cache)
                dto.ComunaDescription = comunas.First(x => x.Id == entity.ComunaId).ComunaDescription;

                examinadorCollection.Add(dto);
            }

            //retornamos la colección
            return examinadorCollection;
        }

        public SL.DTO.ExaminadorDTO GetExaminadorById(int id)
        {
            var entity = this.dataAccess.ExaminadorDAO.GetById(id);
            var dto = ModelMapper.ExaminadorMapper.EntityToDto(entity);

            //obtenemos y cargamos descripcion Comuna a partir de Mgr RegionComuna (que maneja cache)
            dto.ComunaDescription = regionComunaMgr.GetComunaById(entity.ComunaId).ComunaDescription;

            return dto;
        }
        public IEnumerable<SL.DTO.ExaminadorDTO> GetExaminadoresByFilter(SL.DTO.ExaminadorFilterDTO filterDto)
        {
            IList<SL.DTO.ExaminadorDTO> examinadorCollection = new List<SL.DTO.ExaminadorDTO>();

            //primero manejamos una colección que representa a todos los elementos de la bd para Examinador
            var examinadores = this.dataAccess.ExaminadorDAO.GetAll();


            //aplicamos los filtros
            if (filterDto.Rut.GetValueOrDefault() != 0)
                examinadores = examinadores.Where(x => x.Rut == filterDto.Rut);

            if (!string.IsNullOrEmpty(filterDto.Name))
                examinadores = examinadores.Where(x => x.Name.ToLower().Contains(filterDto.Name.ToLower()));

            if (!string.IsNullOrEmpty(filterDto.LastName))
                examinadores = examinadores.Where(x => x.LastName.ToLower().Contains(filterDto.LastName.ToLower()));

            if (examinadores != null && examinadores.Any())
            {
                //obtenemos y cargamos descripcion Comuna a partir de Mgr RegionComuna (que maneja cache)
                var comunas = regionComunaMgr.GetComunaCollection();

                //mapeamos los elementos de entidad a dto
                foreach (var entity in examinadores)
                {
                    var dto = ModelMapper.ExaminadorMapper.EntityToDto(entity);
                    //obtenemos y cargamos descripcion Comuna a partir de Mgr RegionComuna (que maneja cache)
                    dto.ComunaDescription = comunas.First(x => x.Id == entity.ComunaId).ComunaDescription;

                    examinadorCollection.Add(dto);
                }
            }

            //retornamos la colección
            return examinadorCollection;
        }

        public void RemoveExaminador(int examinadorId)
        {
            //eliminamos a través de la DAL
            this.dataAccess.ExaminadorDAO.Remove(examinadorId);
        }

        public void AddExaminador(SL.DTO.ExaminadorDTO examinadorDto)
        {
            //mapeamos
            var entity = ModelMapper.ExaminadorMapper.DtoToEntity(examinadorDto);

            //creamos a través de la DAL
            this.dataAccess.ExaminadorDAO.Create(entity);

        }

        public void UpdateExaminador(SL.DTO.ExaminadorDTO examinadorDto)
        {
            //mapeamos
            var entity = ModelMapper.ExaminadorMapper.DtoToEntity(examinadorDto);

            //actualizamos a través de la DAL
            this.dataAccess.ExaminadorDAO.Update(entity);
        }




    }
}
