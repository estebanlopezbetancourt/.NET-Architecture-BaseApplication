﻿using BaseApplication.Crosscutting.Cache;
using Microsoft.ApplicationServer.Caching;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseApplication.BLL.ServiceImplementations
{
    internal class RegionComunaManager : SL.Services.IRegionComunaManager
    {
        private DAL.Core.DataAccess dataAccess;

        private CacheUtil cacheMgr;
        private const string regionCollectionKey = "regionCollection";
        private const string comunaCollectionKey = "comunaCollection";
        
        public RegionComunaManager()
        {
            this.cacheMgr = new CacheUtil();
            this.dataAccess = new DAL.Core.DataAccess();
        }

        public IEnumerable<SL.DTO.RegionDTO> GetRegionCollection()
        {
            //Get data from the cache
            List<SL.DTO.RegionDTO> cachedRegionCollection = (List<SL.DTO.RegionDTO>)cacheMgr.Get(regionCollectionKey);
            if (cachedRegionCollection == null)
            {
                cachedRegionCollection = new List<SL.DTO.RegionDTO>();

                var regiones = this.dataAccess.RegionDAO.GetAll();
                foreach (var entity in regiones)
                {
                    var dto = ModelMapper.RegionMapper.EntityToDto(entity);
                    cachedRegionCollection.Add(dto);
                }
                BaseApplication.Crosscutting.Logging.Log.Instance.Write("GetRegionCollection cacheMgrAdd ", Crosscutting.Logging.LogLevel.Info);
                cacheMgr.Add(regionCollectionKey, cachedRegionCollection);
            }

            //retornamos la colección
            return cachedRegionCollection;
        }


        public IEnumerable<SL.DTO.ComunaDTO> GetComunaCollection()
        {
            //Get data from the cache
            List<SL.DTO.ComunaDTO> cachedComunaCollection = (List<SL.DTO.ComunaDTO>)cacheMgr.Get(comunaCollectionKey);
            if (cachedComunaCollection == null)
            {
                cachedComunaCollection = new List<SL.DTO.ComunaDTO>();

                var comunas = this.dataAccess.ComunaDAO.GetAll();
                foreach (var entity in comunas)
                {
                    var dto = ModelMapper.ComunaMapper.EntityToDto(entity);
                    cachedComunaCollection.Add(dto);
                }

                BaseApplication.Crosscutting.Logging.Log.Instance.Write("GetComunaCollection cacheMgrAdd ", Crosscutting.Logging.LogLevel.Info);
                cacheMgr.Add(comunaCollectionKey, cachedComunaCollection);
            }

            //retornamos la colección
            return cachedComunaCollection;
        }

        public IEnumerable<SL.DTO.ComunaDTO> GetComunasByRegionId(int regionId)
        {
            IList<SL.DTO.ComunaDTO> comunaCollection = new List<SL.DTO.ComunaDTO>();

            comunaCollection = this.GetComunaCollection().Where(x => x.RegionId == regionId).ToList();

            //retornamos la colección
            return comunaCollection;
        }

        public void CreateComuna(SL.DTO.ComunaDTO comunaDto)
        {
            //changes to store data
            var entity = ModelMapper.ComunaMapper.DtoToEntity(comunaDto);
            this.dataAccess.ComunaDAO.Create(entity);

            //update cache
            comunaDto.Id = entity.Id;
            List<SL.DTO.ComunaDTO> cachedComunaCollection = (List<SL.DTO.ComunaDTO>)cacheMgr.Get(comunaCollectionKey);
            if (cachedComunaCollection != null)
            {
                if (!cachedComunaCollection.Any(x => x.Id == comunaDto.Id))
                {
                    cachedComunaCollection.Add(comunaDto);
                    cacheMgr.Put(comunaCollectionKey, cachedComunaCollection);
                }
            }
        }


        public void UpdateComuna(SL.DTO.ComunaDTO comunaDto)
        {
            //changes to store data
            var entity = ModelMapper.ComunaMapper.DtoToEntity(comunaDto);
            this.dataAccess.ComunaDAO.Update(entity);

            //update cache
            List<SL.DTO.ComunaDTO> cachedComunaCollection = (List<SL.DTO.ComunaDTO>)cacheMgr.Get(comunaCollectionKey);
            if (cachedComunaCollection != null)
            {
                if (cachedComunaCollection.Any(x => x.Id == comunaDto.Id))
                {
                    // -http://stackoverflow.com/questions/17188966/how-to-replace-list-item-in-best-way
                    var cachedComunaOld = cachedComunaCollection.FirstOrDefault(x => x.Id == comunaDto.Id);
                    if (cachedComunaOld != null)
                    {
                        int index = cachedComunaCollection.IndexOf(cachedComunaOld);
                        if (index != -1)
                            cachedComunaCollection[index] = comunaDto;
                    }

                    //then we add the updated list
                    cacheMgr.Put(comunaCollectionKey, cachedComunaCollection);
                }
            }
        }

        public void RemoveComuna(int comunaId)
        {
            //changes to store data
            this.dataAccess.ComunaDAO.Remove(comunaId);

            //update cache
            List<SL.DTO.ComunaDTO> cachedComunaCollection = (List<SL.DTO.ComunaDTO>)cacheMgr.Get(comunaCollectionKey);
            if (cachedComunaCollection != null)
            {
                cachedComunaCollection.RemoveAll(x => x.Id == comunaId);
                cacheMgr.Put(comunaCollectionKey, cachedComunaCollection);
            }
        }


        public SL.DTO.ComunaDTO GetComunaById(int id)
        {
            return this.GetComunaCollection().First(x => x.Id == id);
        }
    }
}
