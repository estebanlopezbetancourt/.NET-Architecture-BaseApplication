﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BaseApplication.BLL.ServiceImplementations
{
    internal class RegionComunaManager : SL.Services.IRegionComunaManager
    {
        private DAL.Core.DataAccess dataAccess;

        //cache strategy: "Small Lists of Data That Rarely Change"   
        //https://ntotten.com/2011/04/29/caching-data-in-asp-net-applications/
        private static List<SL.DTO.ComunaDTO> cachedComunaCollection;
        private static List<SL.DTO.RegionDTO> cachedRegionCollection;

        private static DateTime comunaExpireTime = DateTime.UtcNow;
        private static DateTime regionExpireTime = DateTime.UtcNow;
        private const int minutesBeforeSyncAgain = 30;
        private static object syncLock = new object();

        public RegionComunaManager()
        {
            this.dataAccess = new DAL.Core.DataAccess();
        }

        public IEnumerable<SL.DTO.RegionDTO> GetRegionCollection()
        {
            if (cachedRegionCollection == null)
            {
                UpdateRegionCache();
                if (cachedRegionCollection == null)
                {
                    throw new InvalidOperationException("Hubo un error cargando desde la base de datos. La cache es actualente nula.");
                }
            }
            else
            {
                // Run this async so that the user thread can continue
                var task = new Task(() => { UpdateRegionCache(); });
                task.Start();
            }

            //retornamos la colección
            return cachedRegionCollection;
        }

        private void UpdateRegionCache()
        {
            //first, lock for concurrency
            lock (syncLock)
            {
                //check if the regionExpireTime has expired
                if (DateTime.UtcNow >= regionExpireTime)
                {
                    List<SL.DTO.RegionDTO> newCachedRegionCollection = new List<SL.DTO.RegionDTO>();
                    try
                    {
                        var regiones = this.dataAccess.RegionDAO.GetAll();
                        foreach (var entity in regiones)
                        {
                            var dto = ModelMapper.RegionMapper.EntityToDto(entity);
                            newCachedRegionCollection.Add(dto);
                        }
                    }
                    catch (Exception ex)
                    {
                        // The backing store failed, probably do some logging or something
                        BaseApplication.Crosscutting.Logging.Log.Instance.Exception(ex.Message, ex);
                        newCachedRegionCollection = null;
                    }
                    //check if we have something before update
                    if (newCachedRegionCollection != null)
                    {
                        cachedRegionCollection = newCachedRegionCollection;
                        // This is how long your cache lasts before it is updated
                        regionExpireTime = DateTime.UtcNow.AddMinutes(minutesBeforeSyncAgain);
                    }
                }
            }
        }

        public IEnumerable<SL.DTO.ComunaDTO> GetComunaCollection()
        {
            if (cachedComunaCollection == null)
            {
                UpdateComunaCache();
                if (cachedComunaCollection == null)
                {
                    throw new InvalidOperationException("Hubo un error cargando desde la base de datos. La cache es actualente nula.");
                }
            }
            else
            {
                // Run this async so that the user thread can continue
                var task = new Task(() => { UpdateComunaCache(); });
                task.Start();
            }

            //retornamos la colección
            return cachedComunaCollection;
        }

        private void UpdateComunaCache()
        {
            //check if the regionExpireTime has expired
            if (DateTime.UtcNow >= comunaExpireTime)
            {
                //first, lock for concurrency
                lock (syncLock)
                {
                    //check if the regionExpireTime has expired
                    if (DateTime.UtcNow >= comunaExpireTime)
                    {
                        List<SL.DTO.ComunaDTO> newCachedComunaCollection = new List<SL.DTO.ComunaDTO>();
                        try
                        {
                            var comunas = this.dataAccess.ComunaDAO.GetAll();
                            foreach (var entity in comunas)
                            {
                                var dto = ModelMapper.ComunaMapper.EntityToDto(entity);
                                newCachedComunaCollection.Add(dto);
                            }
                        }
                        catch (Exception ex)
                        {
                            // The backing store failed, probably do some logging or something
                            BaseApplication.Crosscutting.Logging.Log.Instance.Exception(ex.Message, ex);
                            newCachedComunaCollection = null;
                        }
                        //check if we have something before update
                        if (newCachedComunaCollection != null)
                        {
                            cachedComunaCollection = newCachedComunaCollection;
                            // This is how long your cache lasts before it is updated
                            comunaExpireTime = DateTime.UtcNow.AddMinutes(minutesBeforeSyncAgain);
                        }
                    }
                }
            }
        }

        public IEnumerable<SL.DTO.ComunaDTO> GetComunasByRegionId(int regionId)
        {
            IList<SL.DTO.ComunaDTO> comunaCollection = new List<SL.DTO.ComunaDTO>();

            comunaCollection = this.GetComunaCollection().Where(x => x.RegionId == regionId).ToList();

            //retornamos la colección
            return comunaCollection;
        }

        public void CreateComuna(SL.DTO.ComunaDTO comunaDto)
        {
            //changes to store data
            var entity = ModelMapper.ComunaMapper.DtoToEntity(comunaDto);
            this.dataAccess.ComunaDAO.Create(entity);

            //update cache
            comunaDto.Id = entity.Id;
            if (cachedComunaCollection != null)
            {
                cachedComunaCollection.Add(comunaDto);
            }
        }

        public void UpdateComuna(SL.DTO.ComunaDTO comunaDto)
        {
            //changes to store data
            var entity = ModelMapper.ComunaMapper.DtoToEntity(comunaDto);
            this.dataAccess.ComunaDAO.Update(entity);

            //update cache
            if (cachedComunaCollection != null)
            {
                var cachedComuna = cachedComunaCollection.FirstOrDefault(x => x.Id == comunaDto.Id);
                int index = cachedComunaCollection.IndexOf(cachedComuna);

                if (index != -1)
                    cachedComunaCollection[index] = comunaDto;
            }
        }

        public void RemoveComuna(int comunaId)
        {
            //changes to store data
            this.dataAccess.ComunaDAO.Remove(comunaId);

            //update cache
            if (cachedComunaCollection != null)
            {
                cachedComunaCollection.RemoveAll(x => x.Id == comunaId);
            }
        }

        public SL.DTO.ComunaDTO GetComunaById(int id)
        {
            return this.GetComunaCollection().First(x => x.Id == id);
        }
    }
}
